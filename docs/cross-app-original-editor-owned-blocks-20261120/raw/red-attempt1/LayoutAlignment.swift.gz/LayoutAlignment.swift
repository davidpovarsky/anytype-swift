public typealias LayoutAlignment = Anytype_Model_Block.Align
