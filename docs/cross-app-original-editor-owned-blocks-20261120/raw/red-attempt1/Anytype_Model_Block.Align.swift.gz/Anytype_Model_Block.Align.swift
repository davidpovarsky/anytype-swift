extension Anytype_Model_Block {

  public enum Align: SwiftProtobuf.Enum, Swift.CaseIterable {
    public typealias RawValue = Int
    case left // = 0
    case center // = 1
    case right // = 2
    case justify // = 3
    case UNRECOGNIZED(Int)

    public init() {
      self = .left
    }

    public init?(rawValue: Int) {
      switch rawValue {
      case 0: self = .left
      case 1: self = .center
      case 2: self = .right
      case 3: self = .justify
      default: self = .UNRECOGNIZED(rawValue)
      }
    }

    public var rawValue: Int {
      switch self {
      case .left: return 0
      case .center: return 1
      case .right: return 2
      case .justify: return 3
      case .UNRECOGNIZED(let i): return i
      }
    }

    // The compiler won't synthesize support with the UNRECOGNIZED case.
    public static let allCases: [Anytype_Model_Block.Align] = [
      .left,
      .center,
      .right,
      .justify,
    ]

  }}
