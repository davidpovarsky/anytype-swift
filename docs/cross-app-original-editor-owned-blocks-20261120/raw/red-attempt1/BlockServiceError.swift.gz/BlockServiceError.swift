public enum BlockServiceError: Error {
    case lastBlockIdNotFound
}
