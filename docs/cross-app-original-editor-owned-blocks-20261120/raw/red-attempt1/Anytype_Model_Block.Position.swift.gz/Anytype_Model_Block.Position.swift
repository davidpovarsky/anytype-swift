extension Anytype_Model_Block {

  public enum Position: SwiftProtobuf.Enum, Swift.CaseIterable {
    public typealias RawValue = Int
    case none // = 0

    /// above target block
    case top // = 1

    /// under target block
    case bottom // = 2

    /// to left of target block
    case left // = 3

    /// to right of target block
    case right // = 4

    /// inside target block, as last block
    case inner // = 5

    /// replace target block
    case replace // = 6

    /// inside target block, as first block
    case innerFirst // = 7
    case UNRECOGNIZED(Int)

    public init() {
      self = .none
    }

    public init?(rawValue: Int) {
      switch rawValue {
      case 0: self = .none
      case 1: self = .top
      case 2: self = .bottom
      case 3: self = .left
      case 4: self = .right
      case 5: self = .inner
      case 6: self = .replace
      case 7: self = .innerFirst
      default: self = .UNRECOGNIZED(rawValue)
      }
    }

    public var rawValue: Int {
      switch self {
      case .none: return 0
      case .top: return 1
      case .bottom: return 2
      case .left: return 3
      case .right: return 4
      case .inner: return 5
      case .replace: return 6
      case .innerFirst: return 7
      case .UNRECOGNIZED(let i): return i
      }
    }

    // The compiler won't synthesize support with the UNRECOGNIZED case.
    public static let allCases: [Anytype_Model_Block.Position] = [
      .none,
      .top,
      .bottom,
      .left,
      .right,
      .inner,
      .replace,
      .innerFirst,
    ]

  }}
