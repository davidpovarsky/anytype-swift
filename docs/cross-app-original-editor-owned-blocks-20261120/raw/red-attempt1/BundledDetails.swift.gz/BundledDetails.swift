import Foundation
public enum BundledDetails: Sendable {
    case name(String)
    case pluralName(String)
    case iconEmoji(String)
    case iconObjectId(String)
    case iconName(String)
    case iconOption(Int)
    case coverId(String)
    case coverType(CoverType)
    case done(Bool)
    case description(String)
    case recommendedLayout(Int)
    case lastUsedDate(Date)
    case templateNamePrefillType(Int)
    case isHidden(Bool)
    case isDraft(Bool)
}
