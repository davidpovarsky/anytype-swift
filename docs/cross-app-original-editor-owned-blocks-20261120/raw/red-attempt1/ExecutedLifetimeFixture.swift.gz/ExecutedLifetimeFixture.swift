import Foundation

@MainActor
private func lifetimeData(_ document: LifetimeDocumentProbe) -> EditorPageObject {
    .init(objectId: document.objectId, spaceId: document.spaceId, mode: document.mode)
}

@MainActor
private func lifetimeFailure(_ operation: () async throws -> Void) async -> EditorDocumentWriteError? {
    do { try await operation(); return nil }
    catch { return error as? EditorDocumentWriteError }
}

actor LifetimeCloseService {
    private(set) var calls: [String] = []
    var fails = false
    var closeGate: OwnershipGate?
    func setFailure(_ value: Bool) { fails = value }
    func holdOn(_ gate: OwnershipGate) { closeGate = gate }
    func close(contextId: String, spaceId: String) async throws {
        calls.append(contextId + ":" + spaceId)
        await closeGate?.hold()
        if fails { throw TextProbeFailure.deliberate }
    }
}

struct ObjectViewModel: Sendable {}
struct LifetimeViewModelSetter: Sendable { func objectViewUpdate(_ model: ObjectViewModel) {} }

struct LifetimeUserInfo: Sendable { let usersId: String }
struct LifetimeRestrictions: Sendable { var objectRestriction: [ObjectRestriction] = [] }

final class LifetimeDocumentProbe: BaseDocumentProtocol, EditorDocumentWriteLifetimeProviding, @unchecked Sendable {
    private struct State {
        var opened = true
        var permissions = ObjectPermissions()
        var participantEditor = true
        var locked = false
        var lifetime = EditorDocumentWriteLifetime()
    }
    private let lock = NSLock()
    private var state: State
    let objectId: String
    let spaceId = "owned-space"
    let mode: DocumentMode
    let objectLifecycleService = LifetimeCloseService()
    let viewModelSetter = LifetimeViewModelSetter()
    let basicUserInfoStorage: LifetimeUserInfo
    let infoContainer: any InfoContainerProtocol = FixtureInfo()
    let detailsStorage = ObjectDetailsStorage()
    let objectRestrictions = LifetimeRestrictions()
    let lifecycle = DocumentLifecycleProbe()
    init(object: String = "owned", mode: DocumentMode = .handling, users: String = "fixture") {
        objectId = object; self.mode = mode
        basicUserInfoStorage = .init(usersId: users)
        var initial = State()
        initial.permissions = ObjectPermissions(details: ObjectDetails(id: object), isLocked: false,
            participantCanEdit: true, isVersionMode: mode.isVersion, objectRestrictions: [])
        state = initial
    }
    private func read<T>(_ body: (State) -> T) -> T {
        lock.lock(); defer { lock.unlock() }; return body(state)
    }
    private func write(_ body: (inout State) -> Void) {
        lock.lock(); defer { lock.unlock() }; body(&state)
    }
    var editorWriteLifetime: EditorDocumentWriteLifetime { read { $0.lifetime } }
    var isOpened: Bool {
        get { read { $0.opened } }
        set { write { $0.opened = newValue } }
    }
    var permissions: ObjectPermissions {
        get { read { $0.permissions } }
        set { write { $0.permissions = newValue } }
    }
    var participantIsEditor: Bool {
        get { read { $0.participantEditor } }
        set { write { $0.participantEditor = newValue } }
    }
    var isLocked: Bool {
        get { read { $0.locked } }
        set { write { $0.locked = newValue } }
    }
    var children: [BlockInformation] { [] }
    var parsedProperties: ParsedProperties { ParsedProperties() }
    var isEmpty: Bool { false }
    var details: ObjectDetails? { ObjectDetails(id: objectId) }
    var syncStatus: SpaceSyncStatus? { nil }
    var syncPublisher: AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    func subscibeFor(update: [BaseDocumentUpdate]) -> AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    @MainActor func open() async throws { await lifecycle.record("open") }
    @MainActor func update() async throws { await lifecycle.record("update") }
    @MainActor func reopenForFixture() { setupView(ObjectViewModel()) }
    @MainActor private func setupSubscriptions() {}
    private func triggerSync(updates: [DocumentUpdate]) { _ = triggerUpdatePermissions(updates: updates) }
    @MainActor func replaceLifetimeForFixture() { write { $0.lifetime = EditorDocumentWriteLifetime() } }
    @MainActor func applyPermissionForFixture(_ canEdit: Bool) -> [BaseDocumentUpdate] {
        participantIsEditor = canEdit
        return triggerUpdatePermissions(updates: [.restrictions])
    }
    @MainActor func irrelevantUpdateForFixture() -> [BaseDocumentUpdate] {
        triggerUpdatePermissions(updates: [.syncStatus])
    }
    // Exact source methods/close-event branch are appended by the driver below.
    @MainActor
    func close() async throws {
        guard mode.isHandling, isOpened, basicUserInfoStorage.usersId.isNotEmpty else { return }
        let closeLease = editorWriteLifetime.beginClosing()
        defer { closeLease.cancel() }
        try await objectLifecycleService.close(contextId: objectId, spaceId: spaceId)
        isOpened = false
    }
    @MainActor
    private func setupView(_ model: ObjectViewModel) {
        viewModelSetter.objectViewUpdate(model)
        // Start subscription before document is marked as opened
        setupSubscriptions()
        isOpened = true
        triggerSync(updates: [.general])
        editorWriteLifetime.confirmOpened()
    }
    private func triggerUpdatePermissions(updates: [DocumentUpdate]) -> [BaseDocumentUpdate] {
        let updatesForPermissions: [DocumentUpdate] = [.general, .details(id: objectId), .block(blockId: objectId), .restrictions]
        guard updates.contains(where: { updatesForPermissions.contains($0) }) else { return [] }
        
        let newPermissios = ObjectPermissions(
            details: details ?? ObjectDetails(id: ""),
            isLocked: isLocked,
            participantCanEdit: participantIsEditor, 
            isVersionMode: mode.isVersion,
            objectRestrictions: objectRestrictions.objectRestriction
        )
        
        if permissions != newPermissios {
            if permissions.canEditBlocks && !newPermissios.canEditBlocks {
                editorWriteLifetime.invalidate()
            }
            permissions = newPermissios
            return [.permissions]
        }
        
        return []
    }
    @MainActor func emitCloseEventForFixture() {
        let updates: [DocumentUpdate] = [.close]
        if updates.contains(.close) {
            editorWriteLifetime.markUnavailable()
            isOpened = false
        }
    }

}

@MainActor
private func session(
    _ document: LifetimeDocumentProbe,
    text: any TextServiceProtocol = TextProbe(),
    events: any EditorLocalEventPublishing = LocalPublisherProbe()
) throws -> PreparedEditorPageSession {
    try PreparedEditorPageSession(data: lifetimeData(document), document: document,
        textService: text, services: fixtureServices(events: events))
}

@main
struct OriginalEditorLifetimeFixture {
    @MainActor static func main() async throws {
        let checks = BoundaryChecks()
        let body = MiddlewareString(text: "שלום English 👩🏽‍💻")

        let source = EditorDocumentWriteLifetime()
        let token = source.token()!
        let observer = CallbackRecorder()
        let subscription = source.observe(token) { observer.add() }
        source.invalidate(); source.invalidate()
        checks.expect(!source.isCurrent(token) && observer.value == 1, "source_invalidation_is_synchronous_and_observer_is_one_use")
        subscription.cancel()
        let late = source.observe(token) { observer.add() }
        checks.expect(observer.value == 2, "registration_after_invalidation_cannot_lose_revocation")
        late.cancel()
        let current = source.token()!
        let cancelled = source.observe(current) { observer.add() }
        cancelled.cancel(); source.invalidate()
        checks.expect(observer.value == 2, "cancelled_observation_does_not_deliver")
        let reentrant = source.observe(source.token()!) { _ = source.token(); observer.add() }
        source.invalidate()
        checks.expect(observer.value == 3, "invalidation_callbacks_run_outside_the_state_lock")
        reentrant.cancel()

        let unavailable = EditorDocumentWriteLifetime(isAvailable: false)
        let initiallyRefused = unavailable.token() == nil
        unavailable.confirmOpened()
        checks.expect(initiallyRefused && unavailable.token() != nil,
            "unopened_lifetime_requires_explicit_open_confirmation")

        let leaseLifetime = EditorDocumentWriteLifetime()
        let priorLeaseToken = leaseLifetime.token()!
        let firstCloseLease = leaseLifetime.beginClosing()
        let secondCloseLease = leaseLifetime.beginClosing()
        leaseLifetime.confirmOpened()
        checks.expect(leaseLifetime.token() == nil && !leaseLifetime.isCurrent(priorLeaseToken),
            "overlapping_closes_refuse_open_confirmation")
        firstCloseLease.cancel(); firstCloseLease.cancel()
        leaseLifetime.confirmOpened()
        checks.expect(leaseLifetime.token() == nil,
            "one_close_lease_or_duplicate_release_cannot_end_another_close")
        secondCloseLease.cancel()
        let stillUnavailable = leaseLifetime.token() == nil
        leaseLifetime.confirmOpened()
        checks.expect(stillUnavailable && leaseLifetime.token() != nil,
            "close_completion_requires_a_later_explicit_open_confirmation")

        for mode in ["close", "permission"] {
            let document = LifetimeDocumentProbe()
            var drains = 0
            let owner = try EditorDocumentWriteOwner(data: lifetimeData(document), lifetimeDocument: document,
                onDrained: { drains += 1 })
            let gate = OwnershipGate(), destination = TextProbe()
            let writer = DocumentOwnedTextService(owner: owner,
                service: HeldOwnershipTextService(gate: gate, target: destination))
            let operation = Task { try await writer.setText(contextId: "owned", blockId: "a", middlewareString: body) }
            await gate.waitForEntry()
            if mode == "close" {
                try await document.close()
                document.reopenForFixture()
            } else {
                _ = document.applyPermissionForFixture(false)
                _ = document.applyPermissionForFixture(true)
            }
            checks.expect(owner.isRetired && document.isOpened && document.permissions.canEditBlocks,
                mode + "_restore_does_not_renew_retained_authority")
            let denied = await lifetimeFailure {
                try await writer.checked(contextId: "owned", blockId: "a", newValue: true)
            }
            checks.expect(denied == .rejected(.retired) && owner.pendingOperationCount == 1,
                mode + "_aba_refuses_new_dispatch_while_old_write_is_held")
            await gate.release()
            let completed = await lifetimeFailure { try await operation.value }
            let actual = await destination.snapshot()
            checks.expect(completed == .completedWithoutOwnership(.retired) && actual.count == 1
                          && owner.isDrained && drains == 1,
                mode + "_aba_preserves_actual_admitted_write_and_drains_once")
            let fresh = try EditorDocumentWriteOwner(data: lifetimeData(document), lifetimeDocument: document)
            let freshWriter = DocumentOwnedTextService(owner: fresh, service: destination)
            try await freshWriter.checked(contextId: "owned", blockId: "a", newValue: true)
            let renewed = await destination.snapshot()
            checks.expect(renewed.count == 2 && !fresh.isRetired, mode + "_recovery_requires_an_explicit_fresh_owner")
        }

        for mode in ["close", "permission"] {
            let document = LifetimeDocumentProbe()
            var drains = 0
            let owner = try EditorDocumentWriteOwner(data: lifetimeData(document), lifetimeDocument: document,
                onDrained: { drains += 1 })
            let gate = OwnershipGate(), destination = LocalPublisherProbe()
            let publisher = DocumentOwnedLocalEventPublisher(owner: owner,
                publisher: HeldOwnershipPublication(gate: gate, target: destination))
            let operation = Task { await publisher.setStyle(contextId: "owned", blockId: "a") }
            await gate.waitForEntry()
            if mode == "close" {
                try await document.close(); document.reopenForFixture()
            } else {
                _ = document.applyPermissionForFixture(false); _ = document.applyPermissionForFixture(true)
            }
            checks.expect(owner.isRetired && owner.pendingOperationCount == 1 && drains == 0,
                mode + "_aba_invalidates_publication_authority_before_actor_notification")
            await gate.release(); await operation.value
            await publisher.setText(contextId: "owned", blockId: "a", text: body)
            let events = await destination.snapshot()
            checks.expect(events.count == 1 && owner.isRetired && owner.isDrained && drains == 1,
                mode + "_aba_records_prior_delivery_but_refuses_new_publication")
        }

        let closingDocument = LifetimeDocumentProbe()
        let closingGate = OwnershipGate()
        await closingDocument.objectLifecycleService.holdOn(closingGate)
        let closing = Task { try await closingDocument.close() }
        await closingGate.waitForEntry()
        let attemptedTarget = TextProbe()
        var admittedDuringClose = false
        do {
            let attempted = try session(closingDocument, text: attemptedTarget)
            try await attempted.services.blockActionService.textServiceHandler.checked(
                contextId: "owned", blockId: "a", newValue: true)
            admittedDuringClose = true
        } catch {}
        let attemptedCalls = await attemptedTarget.snapshot()
        checks.expect(!admittedDuringClose && attemptedCalls.isEmpty && closingDocument.isOpened,
            "fresh_prepared_session_cannot_dispatch_while_original_close_is_awaiting")
        closingDocument.reopenForFixture()
        checks.expect(closingDocument.isOpened && closingDocument.editorWriteLifetime.token() == nil,
            "original_setup_view_cannot_admit_while_a_close_is_pending")
        await closingGate.release()
        try await closing.value
        checks.expect(!closingDocument.isOpened && closingDocument.editorWriteLifetime.token() == nil,
            "original_close_completion_does_not_replay_an_earlier_open_confirmation")
        closingDocument.reopenForFixture()
        let recoveredSession = try session(closingDocument, text: attemptedTarget)
        try await recoveredSession.services.blockActionService.textServiceHandler.checked(
            contextId: "owned", blockId: "a", newValue: true)
        let recoveredCalls = await attemptedTarget.snapshot()
        checks.expect(closingDocument.isOpened && recoveredCalls.count == 1,
            "a_later_original_setup_view_admits_only_a_fresh_prepared_session")

        let eventDocument = LifetimeDocumentProbe()
        let eventOwner = try EditorDocumentWriteOwner(data: lifetimeData(eventDocument), lifetimeDocument: eventDocument)
        eventDocument.emitCloseEventForFixture()
        eventDocument.reopenForFixture()
        checks.expect(eventOwner.isRetired, "original_close_event_invalidates_without_relying_on_sync_publisher")

        let failedDocument = LifetimeDocumentProbe()
        let failedOwner = try EditorDocumentWriteOwner(data: lifetimeData(failedDocument), lifetimeDocument: failedDocument)
        await failedDocument.objectLifecycleService.setFailure(true)
        var closeError = false
        do { try await failedDocument.close() } catch { closeError = error as? TextProbeFailure == .deliberate }
        checks.expect(closeError && failedDocument.isOpened && failedOwner.isRetired,
            "failed_original_close_propagates_error_and_does_not_renew_old_owner")
        let freshAfterFailure = await lifetimeFailure { _ = try session(failedDocument) }
        let failedCloseCalls = await failedDocument.objectLifecycleService.calls
        checks.expect(freshAfterFailure == .rejected(.retired) && failedCloseCalls.count == 1,
            "failed_close_does_not_infer_new_authority_or_retry_the_original_rpc")

        let noop = LifetimeDocumentProbe(mode: .preview)
        let noopToken = noop.editorWriteLifetime.token()!
        try await noop.close()
        let noopCalls = await noop.objectLifecycleService.calls
        checks.expect(noopCalls.isEmpty && noop.editorWriteLifetime.isCurrent(noopToken),
            "original_preview_close_guard_has_no_new_lifetime_effect")

        let irrelevant = LifetimeDocumentProbe()
        let unchangedToken = irrelevant.editorWriteLifetime.token()!
        let irrelevantRows = irrelevant.irrelevantUpdateForFixture()
        checks.expect(irrelevantRows.isEmpty && irrelevant.editorWriteLifetime.isCurrent(unchangedToken),
            "unrelated_document_update_does_not_revoke_editing")

        let replacedDocument = LifetimeDocumentProbe()
        let replacedOwner = try EditorDocumentWriteOwner(data: lifetimeData(replacedDocument), lifetimeDocument: replacedDocument)
        replacedDocument.replaceLifetimeForFixture()
        let replacedError = await lifetimeFailure { try replacedOwner.validateOwnership() }
        checks.expect(replacedError == .rejected(.retired), "replacement_lifetime_source_cannot_silently_renew_owner")

        let raw = TextProbe(), ownedEvents = LocalPublisherProbe()
        let preparedDoc = LifetimeDocumentProbe()
        let prepared = try session(preparedDoc, text: raw, events: ownedEvents)
        let builder = FixturePreparedAssembly()
        let state = try builder.buildStateModel(preparedSession: prepared, output: nil, showHeader: true, torahSession: nil)
        checks.expect(builder.document === preparedDoc && state.preparedSession === prepared
                      && builder.data == lifetimeData(preparedDoc),
            "prepared_assembly_passes_same_original_document_and_state")
        checks.expect(prepared.services.blockActionService.objectActionService === fixtureMarker
                      && prepared.services.blockBuilder.detailsService === fixtureMarker
                      && prepared.services.router.templateService === fixtureMarker,
            "prepared_session_preserves_other_explicit_service_instances")
        try await prepared.services.blockActionService.textServiceHandler.setStyle(contextId: "owned", blockId: "a", style: .text)
        let rawCalls = await raw.snapshot(), localCalls = await ownedEvents.snapshot()
        checks.expect(rawCalls.count == 1 && localCalls.count == 1 && localCalls[0].operation == "style",
            "original_text_handler_and_local_events_share_the_prepared_owner")
        let lifecycleCalls = await preparedDoc.lifecycle.snapshot()
        let nativeFallback = await Container.shared.nativeText.snapshot()
        checks.expect(lifecycleCalls.isEmpty && nativeFallback.isEmpty,
            "prepared_assembly_never_reopens_document_or_uses_global_text_fallback")

        let container = FixturePreparedContainer(viewController: state.viewController, preparedSession: prepared)
        let coordinator = container.makeCoordinator()
        let otherController = EditorPageController()
        FixturePreparedContainer.dismantleUIViewController(otherController, coordinator: coordinator)
        checks.expect(!prepared.owner.isRetired, "foreign_controller_cleanup_does_not_retire_bound_editor")
        FixturePreparedContainer.dismantleUIViewController(state.viewController, coordinator: coordinator)
        let retiredText = await lifetimeFailure {
            try await prepared.services.blockActionService.textServiceHandler.setStyle(contextId: "owned", blockId: "a", style: .text)
        }
        checks.expect(retiredText == .rejected(.retired), "exact_original_controller_dismantle_retires_prepared_writer")

        let leaseDoc = LifetimeDocumentProbe()
        let leaseSession = try session(leaseDoc)
        let leaseState = try FixturePreparedAssembly().buildStateModel(preparedSession: leaseSession, output: nil, showHeader: true, torahSession: nil)
        var leaseCoordinator: FixturePreparedContainer.Coordinator? =
            FixturePreparedContainer(viewController: leaseState.viewController, preparedSession: leaseSession).makeCoordinator()
        let beforeRelease = !leaseSession.owner.isRetired && leaseCoordinator != nil
        leaseCoordinator = nil
        checks.expect(beforeRelease && leaseSession.owner.isRetired,
            "host_coordinator_release_revokes_its_lease_without_a_dismantle_callback")

        let sharedDoc = LifetimeDocumentProbe()
        let first = try session(sharedDoc), second = try session(sharedDoc)
        first.retire()
        try await second.services.blockActionService.textServiceHandler.checked(contextId: "owned", blockId: "a", newValue: true)
        checks.expect(first.owner.isRetired && !second.owner.isRetired && sharedDoc.isOpened,
            "retiring_one_prepared_host_does_not_revoke_another_same_document_host")

        let duplicate = try session(LifetimeDocumentProbe())
        let duplicateBuilder = FixturePreparedAssembly()
        _ = try duplicateBuilder.buildStateModel(preparedSession: duplicate, output: nil, showHeader: true, torahSession: nil)
        let duplicateError = await lifetimeFailure {
            _ = try duplicateBuilder.buildStateModel(preparedSession: duplicate, output: nil, showHeader: true, torahSession: nil)
        }
        checks.expect(duplicateError == .rejected(.invalidLease) && duplicate.owner.isRetired,
            "a_second_assembly_cannot_reuse_one_prepared_owner")

        let binding = try session(LifetimeDocumentProbe())
        try binding.claimAssembly()
        var originalController: EditorPageController? = EditorPageController()
        try binding.bind(controller: originalController!)
        originalController = nil
        let rebound = await lifetimeFailure { try binding.bind(controller: EditorPageController()) }
        checks.expect(rebound == .rejected(.invalidLease),
            "released_controller_does_not_make_one_use_binding_available_again")

        let duplicateHost = try session(LifetimeDocumentProbe())
        let duplicateHostState = try FixturePreparedAssembly().buildStateModel(preparedSession: duplicateHost, output: nil, showHeader: true, torahSession: nil)
        let duplicateContainer = FixturePreparedContainer(viewController: duplicateHostState.viewController, preparedSession: duplicateHost)
        let originalHost = duplicateContainer.makeCoordinator()
        let secondHost = duplicateContainer.makeCoordinator()
        checks.expect(originalHost.hostLease != nil && secondHost.hostLease == nil && duplicateHost.owner.isRetired,
            "duplicate_host_registration_fails_closed")

        let releasedDoc = LifetimeDocumentProbe()
        var releasedSession: PreparedEditorPageSession? = try session(releasedDoc)
        weak var weakSession = releasedSession
        let retainedWriter = releasedSession!.services.blockActionService.textServiceHandler
        releasedSession = nil
        let releasedError = await lifetimeFailure {
            try await retainedWriter.checked(contextId: "owned", blockId: "a", newValue: true)
        }
        checks.expect(weakSession == nil && releasedError == .rejected(.retired) && releasedDoc.isOpened,
            "released_session_invalidates_retained_writer_without_closing_document")

        let racingDoc = LifetimeDocumentProbe()
        let racingSession = try session(racingDoc)
        let racingBuilder = FixturePreparedAssembly()
        racingBuilder.duringBuild = {
            _ = racingDoc.applyPermissionForFixture(false)
            _ = racingDoc.applyPermissionForFixture(true)
        }
        let raceError = await lifetimeFailure {
            _ = try racingBuilder.buildStateModel(preparedSession: racingSession, output: nil, showHeader: true, torahSession: nil)
        }
        checks.expect(raceError == .rejected(.retired) && racingSession.owner.isRetired,
            "revocation_during_original_state_construction_prevents_prepared_binding")

        try await exerciseOwnedTableServices(checks)
        try await exerciseOriginalHostUpdates(checks)
        try await exerciseOwnedBlockServices(checks)

        let data = try JSONEncoder().encode(checks.checks)
        guard CommandLine.arguments.count == 2 else { throw BoundaryFixtureError.failed }
        try data.write(to: URL(fileURLWithPath: CommandLine.arguments[1]), options: .atomic)
        print(String(decoding: data, as: UTF8.self))
        if checks.checks.contains(where: { !$0.passed }) { throw BoundaryFixtureError.failed }
    }
}

// Appended into the same executed fixture as the preserved original lifetime controls.
@MainActor
private func exerciseOwnedTableServices(_ checks: BoundaryChecks) async throws {
    let document = LifetimeDocumentProbe()
    let owner = try EditorDocumentWriteOwner(data: lifetimeData(document), lifetimeDocument: document)
    let original = OwnedTableServiceProbe(label: "forward")
    let table = DocumentOwnedBlockTableService(owner: owner, service: original)
    let created = try await table.createTable(contextId: "owned", targetId: "first", position: .inner, rowsCount: 3, columnsCount: 5)
    try await table.rowListFill(contextId: "owned", targetIds: ["r2", "r1", "r2"])
    try await table.insertColumn(contextId: "owned", targetId: "c1", position: .left)
    try await table.deleteColumn(contextId: "owned", targetId: "c2")
    try await table.columnDuplicate(contextId: "owned", targetId: "c3")
    try await table.columnSort(contextId: "owned", columnId: "c4", blocksSortType: .desc)
    try await table.columnMove(contextId: "owned", targetId: "c5", dropTargetID: "c6", position: .right)
    try await table.insertRow(contextId: "owned", targetId: "r3", position: .top)
    try await table.deleteRow(contextId: "owned", targetId: "r4")
    try await table.rowDuplicate(contextId: "owned", targetId: "r5")
    try await table.rowMove(contextId: "owned", targetId: "r6", dropTargetID: "r7", position: .bottom)
    try await table.clearContents(contextId: "owned", blockIds: ["a2", "a1", "a2"])
    try await table.clearStyle(contextId: "owned", blocksIds: ["b2", "b1"])
    let expected: [OwnedTableInvocation] = [
        .init(operation: "create", context: "owned", targets: ["first"], position: "inner", rows: 3, columns: 5),
        .init(operation: "fill", context: "owned", targets: ["r2", "r1", "r2"]),
        .init(operation: "insert-column", context: "owned", targets: ["c1"], position: "left"),
        .init(operation: "delete-column", context: "owned", targets: ["c2"]),
        .init(operation: "duplicate-column", context: "owned", targets: ["c3"]),
        .init(operation: "sort-column", context: "owned", targets: ["c4"], sort: "desc"),
        .init(operation: "move-column", context: "owned", targets: ["c5"], dropTarget: "c6", position: "right"),
        .init(operation: "insert-row", context: "owned", targets: ["r3"], position: "top"),
        .init(operation: "delete-row", context: "owned", targets: ["r4"]),
        .init(operation: "duplicate-row", context: "owned", targets: ["r5"]),
        .init(operation: "move-row", context: "owned", targets: ["r6"], dropTarget: "r7", position: "bottom"),
        .init(operation: "clear-contents", context: "owned", targets: ["a2", "a1", "a2"]),
        .init(operation: "clear-style", context: "owned", targets: ["b2", "b1"])
    ]
    let forwarded = await original.snapshot()
    checks.expect(forwarded.count == 13 && owner.pendingOperationCount == 0, "table_all_thirteen_original_methods_finish_their_leases")
    checks.expect(created == "forward-original-table-id", "table_creation_returns_the_original_service_identity")
    for (index, call) in expected.enumerated() {
        checks.expect(index < forwarded.count && forwarded[index] == call, "table_exact_original_arguments_" + call.operation)
    }

    let foreign = await lifetimeFailure { try await table.deleteRow(contextId: "other", targetId: "r1") }
    let afterForeign = await original.snapshot()
    checks.expect(foreign == .rejected(.wrongContext) && afterForeign.count == 13, "table_foreign_context_is_refused_before_dispatch")

    let unicodeDocument = LifetimeDocumentProbe(object: "\u{e9}")
    let unicodeOwner = try EditorDocumentWriteOwner(data: lifetimeData(unicodeDocument), lifetimeDocument: unicodeDocument)
    let unicodeTarget = OwnedTableServiceProbe(label: "unicode")
    let unicodeTable = DocumentOwnedBlockTableService(owner: unicodeOwner, service: unicodeTarget)
    let unicodeError = await lifetimeFailure { try await unicodeTable.deleteRow(contextId: "e\u{301}", targetId: "row") }
    let unicodeCalls = await unicodeTarget.snapshot()
    checks.expect(unicodeError == .rejected(.wrongContext) && unicodeCalls.isEmpty, "table_context_preserves_exact_utf8_identity")

    let preview = LifetimeDocumentProbe(mode: .preview)
    let previewOwner = try EditorDocumentWriteOwner(data: lifetimeData(preview), lifetimeDocument: preview)
    let previewTarget = OwnedTableServiceProbe(label: "preview")
    let previewError = await lifetimeFailure {
        try await DocumentOwnedBlockTableService(owner: previewOwner, service: previewTarget).deleteRow(contextId: "owned", targetId: "row")
    }
    let previewCalls = await previewTarget.snapshot()
    checks.expect(previewError == .rejected(.notHandling) && previewCalls.isEmpty, "table_readonly_mode_cannot_mutate")

    let locked = LifetimeDocumentProbe()
    locked.isLocked = true
    let lockedOwner = try EditorDocumentWriteOwner(data: lifetimeData(locked), lifetimeDocument: locked)
    let lockedTarget = OwnedTableServiceProbe(label: "locked")
    let lockedError = await lifetimeFailure {
        try await DocumentOwnedBlockTableService(owner: lockedOwner, service: lockedTarget).deleteRow(contextId: "owned", targetId: "row")
    }
    let lockedCalls = await lockedTarget.snapshot()
    checks.expect(lockedError == .rejected(.notEditable) && lockedCalls.isEmpty, "table_locked_document_refuses_dispatch")

    let readonly = LifetimeDocumentProbe()
    _ = readonly.applyPermissionForFixture(false)
    let readonlyOwner = try EditorDocumentWriteOwner(data: lifetimeData(readonly), lifetimeDocument: readonly)
    let readonlyTarget = OwnedTableServiceProbe(label: "permission")
    let readonlyError = await lifetimeFailure {
        try await DocumentOwnedBlockTableService(owner: readonlyOwner, service: readonlyTarget).deleteRow(contextId: "owned", targetId: "row")
    }
    let readonlyCalls = await readonlyTarget.snapshot()
    checks.expect(readonlyError == .rejected(.notEditable) && readonlyCalls.isEmpty, "table_original_permission_refuses_dispatch")

    let heldDoc = LifetimeDocumentProbe()
    var drains = 0
    let heldOwner = try EditorDocumentWriteOwner(data: lifetimeData(heldDoc), lifetimeDocument: heldDoc, onDrained: { drains += 1 })
    let heldGate = OwnershipGate()
    let heldTarget = OwnedTableServiceProbe(label: "held", gate: heldGate)
    let heldTable = DocumentOwnedBlockTableService(owner: heldOwner, service: heldTarget)
    let heldOperation = Task { try await heldTable.createTable(contextId: "owned", targetId: "target", position: .bottom, rowsCount: 2, columnsCount: 4) }
    await heldGate.waitForEntry()
    heldOwner.retire()
    let duringCloseCount = heldOwner.pendingOperationCount
    await heldGate.release()
    let late = await lifetimeFailure { _ = try await heldOperation.value }
    let heldCalls = await heldTarget.snapshot()
    checks.expect(late == .completedWithoutOwnership(.retired) && heldCalls.count == 1
        && duringCloseCount == 1 && heldOwner.isDrained && drains == 1,
        "table_actual_admitted_creation_survives_retirement_with_explicit_late_outcome")
    let repeated = await lifetimeFailure { try await heldTable.deleteRow(contextId: "owned", targetId: "new") }
    let repeatCalls = await heldTarget.snapshot()
    checks.expect(repeated == .rejected(.retired) && repeatCalls.count == 1, "table_retirement_does_not_retry_or_admit_a_new_operation")

    let failingTarget = OwnedTableServiceProbe(label: "failure", fails: true)
    var originalError: OwnedTableProbeError?
    do { try await DocumentOwnedBlockTableService(owner: owner, service: failingTarget).clearContents(contextId: "owned", blockIds: ["a"]) }
    catch { originalError = error as? OwnedTableProbeError }
    let failureCalls = await failingTarget.snapshot()
    checks.expect(originalError == .deliberate && failureCalls.count == 1 && owner.pendingOperationCount == 0,
        "table_original_service_error_propagates_without_retry")

    let cancelledTarget = OwnedTableServiceProbe(label: "cancel-before")
    let cancelledTable = DocumentOwnedBlockTableService(owner: owner, service: cancelledTarget)
    let cancelledTask = Task {
        await lifetimeFailure { try await cancelledTable.deleteColumn(contextId: "owned", targetId: "c") }
    }
    cancelledTask.cancel()
    let cancelledError = await cancelledTask.value
    let cancelledCalls = await cancelledTarget.snapshot()
    checks.expect(cancelledError == .rejected(.cancelled) && cancelledCalls.isEmpty, "table_cancellation_before_dispatch_refuses_original_service")

    let cancelGate = OwnershipGate()
    let cancelTarget = OwnedTableServiceProbe(label: "cancel-after", gate: cancelGate)
    let cancelTable = DocumentOwnedBlockTableService(owner: owner, service: cancelTarget)
    let cancelAfter = Task {
        await lifetimeFailure { try await cancelTable.deleteColumn(contextId: "owned", targetId: "actual") }
    }
    await cancelGate.waitForEntry()
    cancelAfter.cancel()
    await cancelGate.release()
    let cancelAfterError = await cancelAfter.value
    let cancelAfterCalls = await cancelTarget.snapshot()
    checks.expect(cancelAfterError == .completedWithoutOwnership(.cancelled) && cancelAfterCalls.count == 1
        && owner.pendingOperationCount == 0, "table_cancellation_after_admission_does_not_claim_rollback")

    for mode in ["close", "permission"] {
        let abaDocument = LifetimeDocumentProbe()
        let abaOwner = try EditorDocumentWriteOwner(data: lifetimeData(abaDocument), lifetimeDocument: abaDocument)
        let abaGate = OwnershipGate()
        let abaTarget = OwnedTableServiceProbe(label: mode, gate: abaGate)
        let abaTable = DocumentOwnedBlockTableService(owner: abaOwner, service: abaTarget)
        let task = Task { try await abaTable.insertRow(contextId: "owned", targetId: "row", position: .bottom) }
        await abaGate.waitForEntry()
        if mode == "close" { try await abaDocument.close(); abaDocument.reopenForFixture() }
        else { _ = abaDocument.applyPermissionForFixture(false); _ = abaDocument.applyPermissionForFixture(true) }
        await abaGate.release()
        let outcome = await lifetimeFailure { try await task.value }
        let actual = await abaTarget.snapshot()
        checks.expect(outcome == .completedWithoutOwnership(.retired) && actual.count == 1 && abaOwner.isRetired,
            "table_" + mode + "_aba_keeps_the_actual_effect_and_refuses_renewed_ownership")
    }

    let targets = FixtureTableServices()
    let preparedDocument = LifetimeDocumentProbe()
    let prepared = try PreparedEditorPageSession(data: lifetimeData(preparedDocument), document: preparedDocument,
        textService: TextProbe(), services: fixtureServices(events: LocalPublisherProbe(), tableServices: targets))
    let selected: [(String, any BlockTableServiceProtocol, OwnedTableServiceProbe)] = [
        ("action", prepared.services.blockActionHandler.blockTableService, targets.action),
        ("builder", prepared.services.blockBuilder.tableService, targets.builder),
        ("simple", prepared.services.simpleTable.tableService, targets.simple)
    ]
    for (name, service, target) in selected {
        try await service.rowDuplicate(contextId: "owned", targetId: name)
        let actual = await target.snapshot()
        checks.expect(actual == [.init(operation: "duplicate-row", context: "owned", targets: [name])],
            "prepared_table_slot_preserves_its_own_original_service_" + name)
    }
    prepared.retire()
    var refused = 0
    for (_, service, target) in selected {
        let error = await lifetimeFailure { try await service.deleteRow(contextId: "owned", targetId: "late") }
        let actual = await target.snapshot()
        if error == .rejected(.retired) && actual.count == 1 { refused += 1 }
    }
    checks.expect(refused == 3 && prepared.owner.isDrained, "prepared_all_three_table_slots_share_the_same_host_retirement")

    let shared = LifetimeDocumentProbe()
    let first = try EditorDocumentWriteOwner(data: lifetimeData(shared), lifetimeDocument: shared)
    let second = try EditorDocumentWriteOwner(data: lifetimeData(shared), lifetimeDocument: shared)
    let sharedTarget = OwnedTableServiceProbe(label: "shared")
    first.retire()
    let firstError = await lifetimeFailure {
        try await DocumentOwnedBlockTableService(owner: first, service: sharedTarget).clearStyle(contextId: "owned", blocksIds: ["a"])
    }
    try await DocumentOwnedBlockTableService(owner: second, service: sharedTarget).clearStyle(contextId: "owned", blocksIds: ["b"])
    let sharedCalls = await sharedTarget.snapshot()
    checks.expect(firstError == .rejected(.retired) && sharedCalls == [.init(operation: "clear-style", context: "owned", targets: ["b"])]
        && !second.isRetired, "table_two_owners_share_the_service_without_sharing_retirement")
}

import Foundation

@MainActor
private struct HostUpdatePreparedFixture {
    let document: LifetimeDocumentProbe
    let destination: TextProbe
    let session: PreparedEditorPageSession
    let state: EditorPageViewState
    let container: FixturePreparedContainer
    let coordinator: FixturePreparedContainer.Coordinator?

    init(document: LifetimeDocumentProbe = LifetimeDocumentProbe(), attach: Bool = true) throws {
        let destination = TextProbe()
        let prepared = try PreparedEditorPageSession(
            data: lifetimeData(document), document: document, textService: destination,
            services: fixtureServices(events: LocalPublisherProbe())
        )
        let state = try FixturePreparedAssembly().buildStateModel(
            preparedSession: prepared, output: nil, showHeader: true, torahSession: nil
        )
        let container = FixturePreparedContainer(
            viewController: state.viewController, preparedSession: prepared
        )
        self.document = document
        self.destination = destination
        self.session = prepared
        self.state = state
        self.container = container
        self.coordinator = attach ? container.makeCoordinator() : nil
    }

    func write(_ block: String) async -> EditorDocumentWriteError? {
        await lifetimeFailure {
            try await session.services.blockActionService.textServiceHandler.checked(
                contextId: document.objectId, blockId: block, newValue: true
            )
        }
    }
}

@MainActor
private func exerciseOriginalHostUpdates(_ checks: BoundaryChecks) async throws {
    let originalEffects = ["insets:91", "hidden:true", "owner:fixture-owner"]

    do {
        let actual = EditorPageController()
        let container = FixturePreparedContainer(viewController: actual)
        let coordinator = container.makeCoordinator()
        container.updateUIViewController(actual, context: .init(coordinator: coordinator))
        checks.expect(actual.updateEffects == originalEffects,
            "host_update_legacy_nil_session_keeps_all_three_original_effects")
    }

    do {
        let actual = EditorPageController()
        let original = FixturePreparedContainer(viewController: actual)
        let coordinator = original.makeCoordinator()
        let replacement = EditorPageController()
        let changed = FixturePreparedContainer(viewController: replacement)
        changed.updateUIViewController(actual, context: .init(coordinator: coordinator))
        checks.expect(actual.updateEffects.isEmpty && replacement.updateEffects == originalEffects,
            "host_update_legacy_nil_to_nil_replacement_preserves_original_callback_behavior")
    }

    do {
        let host = try HostUpdatePreparedFixture()
        host.container.updateUIViewController(
            host.state.viewController, context: .init(coordinator: host.coordinator!)
        )
        let outcome = await host.write("matching")
        let effects = await host.destination.snapshot()
        checks.expect(host.state.viewController.updateEffects == originalEffects
            && outcome == nil && effects.count == 1 && !host.session.owner.isRetired,
            "host_update_matching_prepared_identity_preserves_effects_and_actual_writer")
    }

    do {
        let host = try HostUpdatePreparedFixture()
        let replacement = EditorPageController()
        let changed = FixturePreparedContainer(
            viewController: replacement, preparedSession: host.session
        )
        changed.updateUIViewController(
            host.state.viewController, context: .init(coordinator: host.coordinator!)
        )
        let outcome = await host.write("stale-controller")
        let effects = await host.destination.snapshot()
        checks.expect(outcome == .rejected(.retired) && effects.isEmpty
            && host.state.viewController.updateEffects.isEmpty && replacement.updateEffects.isEmpty,
            "host_update_changed_incoming_controller_retires_only_the_captured_host")
    }

    do {
        let first = try HostUpdatePreparedFixture()
        let second = try HostUpdatePreparedFixture(document: first.document)
        second.container.updateUIViewController(
            first.state.viewController, context: .init(coordinator: first.coordinator!)
        )
        let oldOutcome = await first.write("old-session")
        let currentOutcome = await second.write("current-session")
        let oldEffects = await first.destination.snapshot()
        let currentEffects = await second.destination.snapshot()
        checks.expect(oldOutcome == .rejected(.retired) && oldEffects.isEmpty
            && currentOutcome == nil && currentEffects.count == 1
            && !second.session.owner.isRetired && second.coordinator?.hostLease != nil
            && first.state.viewController.updateEffects.isEmpty
            && second.state.viewController.updateEffects.isEmpty,
            "host_update_changed_session_does_not_revoke_another_already_hosted_owner")
    }

    do {
        let first = try HostUpdatePreparedFixture()
        let second = try HostUpdatePreparedFixture(document: first.document)
        first.container.updateUIViewController(
            second.state.viewController, context: .init(coordinator: first.coordinator!)
        )
        let firstOutcome = await first.write("first-remains")
        let secondOutcome = await second.write("second-remains")
        let firstEffects = await first.destination.snapshot()
        let secondEffects = await second.destination.snapshot()
        checks.expect(firstOutcome == nil && secondOutcome == nil
            && firstEffects.count == 1 && secondEffects.count == 1
            && !first.session.owner.isRetired && !second.session.owner.isRetired
            && first.state.viewController.updateEffects.isEmpty
            && second.state.viewController.updateEffects.isEmpty,
            "host_update_foreign_actual_callback_changes_neither_controller_nor_owner")
    }

    do {
        let host = try HostUpdatePreparedFixture()
        let changed = FixturePreparedContainer(viewController: host.state.viewController)
        changed.updateUIViewController(
            host.state.viewController, context: .init(coordinator: host.coordinator!)
        )
        let outcome = await host.write("removed-session")
        let effects = await host.destination.snapshot()
        checks.expect(outcome == .rejected(.retired) && effects.isEmpty
            && host.state.viewController.updateEffects.isEmpty,
            "host_update_removed_prepared_session_retires_the_captured_writer")
    }

    do {
        let actual = EditorPageController()
        let legacy = FixturePreparedContainer(viewController: actual)
        let coordinator = legacy.makeCoordinator()
        let incoming = try HostUpdatePreparedFixture(attach: false)
        incoming.container.updateUIViewController(actual, context: .init(coordinator: coordinator))
        let outcome = await incoming.write("unattached-reuse")
        let effects = await incoming.destination.snapshot()
        checks.expect(outcome == .rejected(.retired) && effects.isEmpty
            && actual.updateEffects.isEmpty && incoming.state.viewController.updateEffects.isEmpty,
            "host_update_new_unattached_prepared_session_cannot_reuse_a_legacy_host")
    }
}


@MainActor
private func blockAuthorityFailure(_ operation: () async throws -> Void) async -> DocumentOwnedBlockServiceError? {
    do { try await operation(); return nil }
    catch { return error as? DocumentOwnedBlockServiceError }
}

@MainActor
private func exerciseOwnedBlockServices(_ checks: BoundaryChecks) async throws {
    let document = LifetimeDocumentProbe()
    let owner = try EditorDocumentWriteOwner(data: lifetimeData(document), lifetimeDocument: document)
    let original = OwnedBlockServiceProbe(label: "forward")
    let service = DocumentOwnedBlockService(owner: owner, service: original)
    let appearance = BlockLink.Appearance(iconSize: .small, cardStyle: .text, description: .added,
        relations: [.type, .name, .type])
    let fields: BlockFields = ["title": .string("Exact \u{e9}"), "ordinal": .number(3), "enabled": .bool(false)]
    let info = BlockInformation(id: "client-block", content: .link(.init(targetBlockID: "retained-link", appearance: appearance)),
        backgroundColor: .ice, horizontalAlignment: .right, childrenIds: ["c2", "c1", "c2"],
        configurationData: .init(parentId: "parent", backgroundColor: .teal), fields: fields)
    let added = try await service.add(contextId: "owned", targetId: "target", info: info, position: .inner)
    let first = try await service.addFirstBlock(contextId: "owned", info: info)
    try await service.delete(contextId: "owned", blockIds: ["b2", "b1", "b2"])
    try await service.duplicate(contextId: "owned", targetId: "dup-target", blockIds: ["d2", "d1"], position: .left)
    try await service.move(contextId: "owned", blockIds: ["m2", "m1"], targetContextID: "owned",
        dropTargetID: "drop", position: .right)
    try await service.setAlign(objectId: "owned", blockIds: ["a2", "a1"], alignment: .justify)
    try await service.setBackgroundColor(objectId: "owned", blockIds: ["bg"], color: .orange)
    try await service.setFields(objectId: "owned", blockId: "field-block", fields: fields)
    try await service.setBlockColor(objectId: "owned", blockIds: ["t2", "t1"], color: .purple)
    try await service.replace(objectId: "owned", blockIds: ["old2", "old1"], targetId: "replacement")
    let replacement = try await service.replaceBlock(contextId: "owned", blockId: "old", info: info)
    try await service.move(objectId: "owned", blockId: "move-one", targetId: "target-one", position: .innerFirst)
    try await service.moveToPage(objectId: "owned", blockIds: ["p2", "p1"], pageId: "owned")
    try await service.setLinkAppearance(objectId: "owned", blockIds: ["l2", "l1"], appearance: appearance)
    try await service.changeMarkup(objectId: "owned", blockIds: ["mk2", "mk1"], markType: .linkToObject("literal-target"))
    let last = try await service.lastBlockId(from: "owned", spaceId: "owned-space")
    let expected: [OwnedBlockInvocation] = [
        .init(operation: "add", context: "owned", targets: ["target"], position: "inner", info: info),
        .init(operation: "add-first", context: "owned", info: info),
        .init(operation: "delete", context: "owned", targets: ["b2", "b1", "b2"]),
        .init(operation: "duplicate", context: "owned", targets: ["d2", "d1"], target: "dup-target", position: "left"),
        .init(operation: "move-context", context: "owned", targets: ["m2", "m1"], target: "drop", destination: "owned", position: "right"),
        .init(operation: "align", context: "owned", targets: ["a2", "a1"], alignment: 3),
        .init(operation: "background", context: "owned", targets: ["bg"], color: .orange),
        .init(operation: "fields", context: "owned", targets: ["field-block"], fields: fields),
        .init(operation: "text-color", context: "owned", targets: ["t2", "t1"], color: .purple),
        .init(operation: "replace", context: "owned", targets: ["old2", "old1"], target: "replacement"),
        .init(operation: "replace-block", context: "owned", targets: ["old"], info: info),
        .init(operation: "move-block", context: "owned", targets: ["move-one"], target: "target-one", middlewarePosition: 7),
        .init(operation: "move-page", context: "owned", targets: ["p2", "p1"], destination: "owned"),
        .init(operation: "appearance", context: "owned", targets: ["l2", "l1"], appearance: appearance),
        .init(operation: "markup", context: "owned", targets: ["mk2", "mk1"], markup: .linkToObject("literal-target")),
        .init(operation: "last-block", context: "owned", space: "owned-space")
    ]
    let forwarded = await original.snapshot()
    checks.expect(forwarded.count == 16 && owner.pendingOperationCount == 0, "block_all_sixteen_admitted_methods_finish_their_leases")
    checks.expect(added == "forward-original-block-id" && first == added && replacement == added
        && last == "forward-original-last-id", "block_original_mutation_and_read_return_identities_are_preserved")
    for (index, call) in expected.enumerated() {
        checks.expect(index < forwarded.count && forwarded[index] == call, "block_exact_original_arguments_" + call.operation)
    }

    let foreignSource = await lifetimeFailure { try await service.delete(contextId: "foreign", blockIds: ["a"]) }
    let afterForeign = await original.snapshot()
    checks.expect(foreignSource == .rejected(.wrongContext) && afterForeign.count == 16,
        "block_foreign_source_context_is_refused_before_service")
    let unicodeDocument = LifetimeDocumentProbe(object: "\u{e9}")
    let unicodeOwner = try EditorDocumentWriteOwner(data: lifetimeData(unicodeDocument), lifetimeDocument: unicodeDocument)
    let unicodeTarget = OwnedBlockServiceProbe(label: "unicode")
    let unicode = DocumentOwnedBlockService(owner: unicodeOwner, service: unicodeTarget)
    let unicodeSource = await lifetimeFailure { try await unicode.delete(contextId: "e\u{301}", blockIds: ["a"]) }
    let unicodeCalls = await unicodeTarget.snapshot()
    checks.expect(unicodeSource == .rejected(.wrongContext) && unicodeCalls.isEmpty, "block_source_identity_uses_exact_utf8")

    let foreignMove = await blockAuthorityFailure {
        try await service.move(contextId: "owned", blockIds: ["a"], targetContextID: "other", dropTargetID: "target", position: .bottom)
    }
    let foreignPage = await blockAuthorityFailure {
        try await service.moveToPage(objectId: "owned", blockIds: ["a"], pageId: "other")
    }
    let unicodeMove = await blockAuthorityFailure {
        try await unicode.move(contextId: "\u{e9}", blockIds: ["a"], targetContextID: "e\u{301}", dropTargetID: "target", position: .bottom)
    }
    let unicodePage = await blockAuthorityFailure {
        try await unicode.moveToPage(objectId: "\u{e9}", blockIds: ["a"], pageId: "e\u{301}")
    }
    let postDestination = await original.snapshot(), postUnicode = await unicodeTarget.snapshot()
    checks.expect(foreignMove == .separateDocumentAuthorityRequired && postDestination.count == 16,
        "block_move_to_foreign_document_requires_separate_authority")
    checks.expect(foreignPage == .separateDocumentAuthorityRequired && postDestination.count == 16,
        "block_move_to_foreign_page_requires_separate_authority")
    checks.expect(unicodeMove == .separateDocumentAuthorityRequired && postUnicode.isEmpty,
        "block_move_destination_does_not_normalize_unicode")
    checks.expect(unicodePage == .separateDocumentAuthorityRequired && postUnicode.isEmpty,
        "block_page_destination_does_not_normalize_unicode")

    let promote = await blockAuthorityFailure {
        _ = try await service.convertChildrenToObjects(contextId: "owned", blocksIds: ["child"],
            typeUniqueKey: .note, templateId: "retained-template")
    }
    let create = await blockAuthorityFailure {
        _ = try await service.createBlockLink(contextId: "owned", targetId: "target", spaceId: "owned-space",
            details: [.name("retained")], typeUniqueKey: .note, position: .bottom, templateId: "retained-template")
    }
    let postCreation = await original.snapshot()
    checks.expect(promote == .separateObjectAuthorityRequired && postCreation.count == 16,
        "block_promote_has_no_invented_object_authority_or_raw_fallback")
    checks.expect(create == .separateObjectAuthorityRequired && postCreation.count == 16,
        "block_create_link_has_no_invented_object_authority_or_raw_fallback")

    let foreignSpace = await lifetimeFailure { _ = try await service.lastBlockId(from: "owned", spaceId: "other-space") }
    let postSpace = await original.snapshot()
    checks.expect(foreignSpace == .rejected(.wrongContext) && postSpace.count == 16,
        "block_read_requires_exact_owned_space_before_original_object_show")

    for (label, mode) in [("preview", DocumentMode.preview), ("version", DocumentMode.version("exact-version"))] {
        let readonly = LifetimeDocumentProbe(mode: mode)
        let readonlyOwner = try EditorDocumentWriteOwner(data: lifetimeData(readonly), lifetimeDocument: readonly)
        let target = OwnedBlockServiceProbe(label: label)
        let readonlyService = DocumentOwnedBlockService(owner: readonlyOwner, service: target)
        let value = try await readonlyService.lastBlockId(from: "owned", spaceId: "owned-space")
        let actual = await target.snapshot()
        checks.expect(value == label + "-original-last-id"
            && actual == [.init(operation: "last-block", context: "owned", space: "owned-space")],
            "block_read_retains_original_nonmutating_semantics_in_" + label)
    }
    for state in ["locked", "no-permission"] {
        let readonly = LifetimeDocumentProbe()
        if state == "locked" { readonly.isLocked = true }
        else { _ = readonly.applyPermissionForFixture(false) }
        let readonlyOwner = try EditorDocumentWriteOwner(data: lifetimeData(readonly), lifetimeDocument: readonly)
        let target = OwnedBlockServiceProbe(label: state)
        let value = try await DocumentOwnedBlockService(owner: readonlyOwner, service: target)
            .lastBlockId(from: "owned", spaceId: "owned-space")
        let actual = await target.snapshot()
        checks.expect(value == state + "-original-last-id" && actual.count == 1,
            "block_read_does_not_require_edit_permission_" + state)
    }
    for state in ["preview", "locked", "no-permission"] {
        let restricted = LifetimeDocumentProbe(mode: state == "preview" ? .preview : .handling)
        if state == "locked" { restricted.isLocked = true }
        if state == "no-permission" { _ = restricted.applyPermissionForFixture(false) }
        let restrictedOwner = try EditorDocumentWriteOwner(data: lifetimeData(restricted), lifetimeDocument: restricted)
        let target = OwnedBlockServiceProbe(label: state)
        let denied = await lifetimeFailure {
            try await DocumentOwnedBlockService(owner: restrictedOwner, service: target).delete(contextId: "owned", blockIds: ["a"])
        }
        let actual = await target.snapshot()
        checks.expect(denied == .rejected(state == "preview" ? .notHandling : .notEditable) && actual.isEmpty,
            "block_write_denied_before_service_" + state)
    }

    let errorTarget = OwnedBlockServiceProbe(label: "error", fails: true)
    var unchangedError = false
    do { try await DocumentOwnedBlockService(owner: owner, service: errorTarget).delete(contextId: "owned", blockIds: ["a"]) }
    catch { unchangedError = (error as? OwnedBlockProbeError) == .deliberate }
    let errorCalls = await errorTarget.snapshot()
    checks.expect(unchangedError && errorCalls.count == 1 && owner.pendingOperationCount == 0,
        "block_original_mutation_error_is_not_rewritten_or_retried")
    let missing = OwnedBlockServiceProbe(label: "missing", missingLast: true)
    var originalMissing = false
    do { _ = try await DocumentOwnedBlockService(owner: owner, service: missing).lastBlockId(from: "owned", spaceId: "owned-space") }
    catch { if case .lastBlockIdNotFound? = error as? BlockServiceError { originalMissing = true } }
    let missingCalls = await missing.snapshot()
    checks.expect(originalMissing && missingCalls.count == 1 && owner.pendingOperationCount == 0,
        "block_original_last_block_not_found_error_is_preserved")

    for isRead in [false, true] {
        let label = isRead ? "read" : "mutation"
        let target = OwnedBlockServiceProbe(label: label)
        let bound = DocumentOwnedBlockService(owner: owner, service: target)
        let task = Task {
            await lifetimeFailure {
                if isRead { _ = try await bound.lastBlockId(from: "owned", spaceId: "owned-space") }
                else { try await bound.delete(contextId: "owned", blockIds: ["a"]) }
            }
        }
        task.cancel()
        let denied = await task.value, actual = await target.snapshot()
        checks.expect(denied == .rejected(.cancelled) && actual.isEmpty,
            "block_cancellation_before_" + label + "_does_not_dispatch")

        let gate = OwnershipGate()
        let held = OwnedBlockServiceProbe(label: label, gate: gate)
        let heldService = DocumentOwnedBlockService(owner: owner, service: held)
        let admitted = Task {
            await lifetimeFailure {
                if isRead { _ = try await heldService.lastBlockId(from: "owned", spaceId: "owned-space") }
                else { try await heldService.delete(contextId: "owned", blockIds: ["actual"]) }
            }
        }
        await gate.waitForEntry()
        admitted.cancel()
        await gate.release()
        let outcome = await admitted.value, calls = await held.snapshot()
        checks.expect(outcome == .completedWithoutOwnership(.cancelled) && calls.count == 1
            && owner.pendingOperationCount == 0, "block_cancellation_after_" + label + "_preserves_admitted_effect")
    }

    for isRead in [false, true] {
        let label = isRead ? "read" : "mutation"
        let heldDocument = LifetimeDocumentProbe()
        var drains = 0
        let heldOwner = try EditorDocumentWriteOwner(data: lifetimeData(heldDocument), lifetimeDocument: heldDocument,
            onDrained: { drains += 1 })
        let gate = OwnershipGate()
        let target = OwnedBlockServiceProbe(label: label, gate: gate)
        let bound = DocumentOwnedBlockService(owner: heldOwner, service: target)
        let task = Task {
            await lifetimeFailure {
                if isRead { _ = try await bound.lastBlockId(from: "owned", spaceId: "owned-space") }
                else { _ = try await bound.add(contextId: "owned", targetId: "target", info: info, position: .bottom) }
            }
        }
        await gate.waitForEntry()
        heldOwner.retire()
        let pending = heldOwner.pendingOperationCount
        await gate.release()
        let outcome = await task.value, calls = await target.snapshot()
        checks.expect(outcome == .completedWithoutOwnership(.retired) && calls.count == 1
            && pending == 1 && heldOwner.isDrained && drains == 1,
            "block_admitted_" + label + "_finishes_once_without_renewing_retired_ownership")
    }
    for mode in ["close", "permission"] {
        for isRead in [false, true] {
            let label = isRead ? "read" : "mutation"
            let abaDocument = LifetimeDocumentProbe()
            let abaOwner = try EditorDocumentWriteOwner(data: lifetimeData(abaDocument), lifetimeDocument: abaDocument)
            let gate = OwnershipGate()
            let target = OwnedBlockServiceProbe(label: label, gate: gate)
            let bound = DocumentOwnedBlockService(owner: abaOwner, service: target)
            let task = Task {
                await lifetimeFailure {
                    if isRead { _ = try await bound.lastBlockId(from: "owned", spaceId: "owned-space") }
                    else { try await bound.delete(contextId: "owned", blockIds: ["actual"]) }
                }
            }
            await gate.waitForEntry()
            if mode == "close" { try await abaDocument.close(); abaDocument.reopenForFixture() }
            else { _ = abaDocument.applyPermissionForFixture(false); _ = abaDocument.applyPermissionForFixture(true) }
            await gate.release()
            let outcome = await task.value, calls = await target.snapshot()
            checks.expect(outcome == .completedWithoutOwnership(.retired) && calls.count == 1 && abaOwner.isRetired,
                "block_" + mode + "_aba_preserves_actual_" + label + "_and_refuses_delivery")
        }
    }

    let targets = FixtureBlockServices()
    let preparedDocument = LifetimeDocumentProbe()
    let prepared = try PreparedEditorPageSession(data: lifetimeData(preparedDocument), document: preparedDocument,
        textService: TextProbe(), services: fixtureServices(events: LocalPublisherProbe(), blockServices: targets))
    let slots: [(String, any BlockServiceProtocol, OwnedBlockServiceProbe)] = [
        ("action", prepared.services.blockActionService.blockService, targets.action),
        ("handler", prepared.services.blockActionHandler.blockService, targets.handler),
        ("keyboard", prepared.services.keyboardHandler.blockService, targets.keyboard),
        ("state", prepared.services.blocksStateManager.blockService, targets.state),
        ("builder", prepared.services.blockBuilder.blockService, targets.builder),
        ("viewModel", prepared.services.viewModel.blockService, targets.viewModel)
    ]
    for (name, bound, target) in slots {
        try await bound.delete(contextId: "owned", blockIds: [name])
        let calls = await target.snapshot()
        checks.expect(calls == [.init(operation: "delete", context: "owned", targets: [name])],
            "prepared_block_slot_retains_its_original_service_" + name)
    }
    prepared.retire()
    for (name, bound, target) in slots {
        let outcome = await lifetimeFailure { try await bound.delete(contextId: "owned", blockIds: ["late"]) }
        let calls = await target.snapshot()
        checks.expect(outcome == .rejected(.retired) && calls.count == 1,
            "prepared_block_slot_is_retired_with_its_one_host_" + name)
    }

    let shared = LifetimeDocumentProbe()
    let firstOwner = try EditorDocumentWriteOwner(data: lifetimeData(shared), lifetimeDocument: shared)
    let secondOwner = try EditorDocumentWriteOwner(data: lifetimeData(shared), lifetimeDocument: shared)
    let sharedTarget = OwnedBlockServiceProbe(label: "shared")
    firstOwner.retire()
    let refused = await lifetimeFailure {
        try await DocumentOwnedBlockService(owner: firstOwner, service: sharedTarget).delete(contextId: "owned", blockIds: ["first"])
    }
    try await DocumentOwnedBlockService(owner: secondOwner, service: sharedTarget).delete(contextId: "owned", blockIds: ["second"])
    let sharedCalls = await sharedTarget.snapshot()
    checks.expect(refused == .rejected(.retired) && sharedCalls == [.init(operation: "delete", context: "owned", targets: ["second"])]
        && !secondOwner.isRetired, "block_two_owners_do_not_share_retirement_or_admission")

    checks.expect(BlockActionServiceDependencies.original().blockService === Container.shared.block,
        "block_original_default_factory_remains_the_unwrapped_original_service")
    let legacy = OwnedBlockServiceProbe(label: "legacy")
    try await legacy.moveToPage(objectId: "source", blockIds: ["a"], pageId: "unrelated")
    let promoted = try await legacy.convertChildrenToObjects(contextId: "source", blocksIds: ["a"],
        typeUniqueKey: .note, templateId: "template")
    let created = try await legacy.createBlockLink(contextId: "source", targetId: "target", spaceId: "space",
        details: [.name("original")], typeUniqueKey: .note, position: .bottom, templateId: "template")
    let legacyCalls = await legacy.snapshot()
    checks.expect(legacyCalls.count == 3 && legacyCalls[0].destination == "unrelated"
        && promoted == ["legacy-link-2", "legacy-link-1", "legacy-link-2"] && created == "legacy-original-object-id",
        "block_unwrapped_service_boundary_retains_foreign_move_and_original_creation_results")
}
