import Foundation

public enum Anytype_Model_Block {
    public enum Content {
        public enum Text {
            public struct Marks: Equatable, Sendable {
                public var retainedFixtureMarks: [String] = []
                public init() {}
            }
        }
    }
}
public enum BlockText {
    public enum Style: Sendable, Equatable { case text, quote }
}
public enum Anytype_Rpc {
    public enum Block {
        public enum Split {
            public enum Request {
                public enum Mode: Sendable, Equatable { case fixture }
            }
        }
    }
}
enum ObjectHeaderEmptyUsecase: Hashable, Codable { case full }
enum ObjectHeaderExpectedLayout: Hashable, Codable { case fixture }
protocol InfoContainerProtocol: AnyObject, Sendable {}
final class FixtureInfo: InfoContainerProtocol {}
final class ObjectDetailsStorage: Sendable {}
struct ParsedProperties: Sendable {}
struct SpaceSyncStatus: Sendable {}
struct AnyPublisher<Output, Failure: Error>: Sendable {}
actor DocumentLifecycleProbe {
    private var operations: [String] = []
    func record(_ operation: String) { operations.append(operation) }
    func snapshot() -> [String] { operations }
}
final class DocumentProbe: BaseDocumentProtocol, @unchecked Sendable {
    let objectId: String
    let spaceId: String
    let mode: DocumentMode
    let isOpened: Bool
    let lifecycle: DocumentLifecycleProbe
    let infoContainer: any InfoContainerProtocol = FixtureInfo()
    let detailsStorage = ObjectDetailsStorage()
    var children: [BlockInformation] { [] }
    var parsedProperties: ParsedProperties { ParsedProperties() }
    var isLocked: Bool { false }
    var isEmpty: Bool { false }
    var details: ObjectDetails? { nil }
    var permissions: ObjectPermissions { ObjectPermissions() }
    var syncStatus: SpaceSyncStatus? { nil }
    var syncPublisher: AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    init(_ object: String = "object", space: String = "space", mode: DocumentMode = .handling,
         opened: Bool = true, lifecycle: DocumentLifecycleProbe = DocumentLifecycleProbe()) {
        objectId = object; spaceId = space; self.mode = mode; isOpened = opened; self.lifecycle = lifecycle
    }
    func subscibeFor(update: [BaseDocumentUpdate]) -> AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    @MainActor func open() async throws { await lifecycle.record("open") }
    @MainActor func update() async throws { await lifecycle.record("update") }
    @MainActor func close() async throws { await lifecycle.record("close") }
}
struct TextCall: Sendable {
    let operation: String
    let context: String
    let block: String
    var body: MiddlewareString?
    var payload: [String] = []
    var range: NSRange?
    var style: TextServiceProtocol.Style?
    var mode: TextServiceProtocol.SplitMode?
}
enum TextProbeFailure: Error, Equatable, Sendable { case deliberate, cancel }
actor TextProbe: TextServiceProtocol {
    let failure: TextProbeFailure?
    private var calls: [TextCall] = []
    init(failure: TextProbeFailure? = nil) { self.failure = failure }
    func snapshot() -> [TextCall] { calls }
    private func record(_ call: TextCall) throws {
        calls.append(call)
        if failure == .cancel { throw CancellationError() }
        if let failure { throw failure }
    }
    func setText(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try record(.init(operation: "text", context: contextId, block: blockId, body: middlewareString))
    }
    func setTextForced(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try record(.init(operation: "forced", context: contextId, block: blockId, body: middlewareString))
    }
    func setStyle(contextId: String, blockId: String, style: Style) async throws {
        try record(.init(operation: "style", context: contextId, block: blockId, style: style))
    }
    func split(contextId: String, blockId: String, range: NSRange, style: Style, mode: SplitMode) async throws -> String {
        try record(.init(operation: "split", context: contextId, block: blockId, range: range, style: style, mode: mode))
        return "injected-created-block"
    }
    func checked(contextId: String, blockId: String, newValue: Bool) async throws {
        try record(.init(operation: "checked", context: contextId, block: blockId, payload: [String(newValue)]))
    }
    func merge(contextId: String, firstBlockId: String, secondBlockId: String) async throws {
        try record(.init(operation: "merge", context: contextId, block: firstBlockId, payload: [secondBlockId]))
    }
    func setTextIcon(contextId: String, blockId: String, imageObjectId: String, emojiUnicode: String) async throws {
        try record(.init(operation: "icon", context: contextId, block: blockId, payload: [imageObjectId, emojiUnicode]))
    }
}
enum LocalEvent: Sendable {
    case general
    case setStyle(blockId: String)
    case setToggled(blockId: String)
    case setText(blockId: String, text: MiddlewareString)
    case setLoadingState(blockId: String)
}
actor EventProbe {
    static let shared = EventProbe()
    private var events: [[String]] = []
    private var detailed: [TextCall] = []
    func record(_ context: String, _ block: String) { events.append([context, block]) }
    func recordDetailed(_ call: TextCall) { detailed.append(call) }
    func snapshot() -> [[String]] { events }
    func detailedSnapshot() -> [TextCall] { detailed }
}
struct EventsBunch: Sendable {
    let contextId: String
    let localEvents: [LocalEvent]
    func send() async {
        for event in localEvents {
            let call: TextCall
            switch event {
            case .general: call = .init(operation: "general", context: contextId, block: "")
            case .setStyle(let block):
                await EventProbe.shared.record(contextId, block)
                call = .init(operation: "style", context: contextId, block: block)
            case .setToggled(let block): call = .init(operation: "toggle", context: contextId, block: block)
            case .setText(let block, let text): call = .init(operation: "text", context: contextId, block: block, body: text)
            case .setLoadingState(let block): call = .init(operation: "loading", context: contextId, block: block)
            }
            await EventProbe.shared.recordDetailed(call)
        }
    }
}
actor LocalPublisherProbe: EditorLocalEventPublishing {
    private var calls: [TextCall] = []
    let service: TextProbe?
    init(service: TextProbe? = nil) { self.service = service }
    func snapshot() -> [TextCall] { calls }
    func refresh(contextId: String) { calls.append(.init(operation: "general", context: contextId, block: "")) }
    func setStyle(contextId: String, blockId: String) async {
        let completed = await service?.snapshot().map(\.operation) ?? []
        calls.append(.init(operation: "style", context: contextId, block: blockId, payload: completed))
    }
    func setToggled(contextId: String, blockId: String) { calls.append(.init(operation: "toggle", context: contextId, block: blockId)) }
    func setText(contextId: String, blockId: String, text: MiddlewareString) {
        calls.append(.init(operation: "text", context: contextId, block: blockId, body: text))
    }
    func setLoadingState(contextId: String, blockId: String) {
        calls.append(.init(operation: "loading", context: contextId, block: blockId))
    }
}
protocol ObjectActionsServiceProtocol: AnyObject, Sendable {}
protocol BookmarkServiceProtocol: AnyObject, Sendable {}
protocol FileActionsServiceProtocol: AnyObject, Sendable {}
protocol ObjectTypeProviderProtocol: AnyObject, Sendable {}
@MainActor protocol KeyboardInsertedBlocksStorageProtocol: AnyObject {}
final class ServiceMarker: ObjectActionsServiceProtocol, BookmarkServiceProtocol,
    FileActionsServiceProtocol, ObjectTypeProviderProtocol, Sendable {
    let name: String
    init(_ name: String) { self.name = name }
}
@MainActor final class KeyboardMarker: KeyboardInsertedBlocksStorageProtocol {
    let name: String
    init(_ name: String) { self.name = name }
}
struct Container: Sendable {
    static let shared = Container()
    let nativeText = TextProbe()
    let nativeHandler: TextServiceHandler
    let object = ServiceMarker("original-object")
    let block = OwnedBlockServiceProbe(label: "original-block")
    let bookmark = ServiceMarker("original-bookmark")
    let file = ServiceMarker("original-file")
    let types = ServiceMarker("original-types")
    @MainActor static let originalKeyboard = KeyboardMarker("original-keyboard")
    @MainActor var keyboard: KeyboardMarker { Self.originalKeyboard }
    init() { nativeHandler = TextServiceHandler(textService: nativeText) }
    func textService() -> any TextServiceProtocol { nativeText }
    func textServiceHandler() -> any TextServiceProtocol { nativeHandler }
    func objectActionsService() -> any ObjectActionsServiceProtocol { object }
    func blockService() -> any BlockServiceProtocol { block }
    func bookmarkService() -> any BookmarkServiceProtocol { bookmark }
    func fileActionsService() -> any FileActionsServiceProtocol { file }
    func objectTypeProvider() -> any ObjectTypeProviderProtocol { types }
    @MainActor func keyboardInsertedBlocksStorage() -> any KeyboardInsertedBlocksStorageProtocol { keyboard }
}
@MainActor protocol BlockActionServiceProtocol {}
@MainActor final class EditorMainItemModelsHolder {}
@MainActor final class EditorCursorManager {}
struct BoundaryCheck: Codable { let name: String; let passed: Bool }
@MainActor final class BoundaryChecks {
    private(set) var checks: [BoundaryCheck] = []
    func expect(_ condition: Bool, _ name: String) { checks.append(.init(name: name, passed: condition)) }
    func validate(_ name: String, data: EditorPageObject, document: DocumentProbe,
                  expected: PreparedEditorPageDocumentError? = nil) {
        do {
            try PreparedEditorPageDocument.validate(data: data, document: document)
            expect(expected == nil, name)
        } catch {
            expect((error as? PreparedEditorPageDocumentError) == expected && expected != nil, name)
        }
    }
}
enum BoundaryFixtureError: Error { case failed }
import Foundation

final class OwnershipDocumentProbe: BaseDocumentProtocol, @unchecked Sendable {
    private struct State {
        var object: String
        var space: String
        var mode: DocumentMode
        var opened = true
        var locked = false
        var editable = true
    }
    private let lock = NSLock()
    private var state: State
    let lifecycle = DocumentLifecycleProbe()
    let infoContainer: any InfoContainerProtocol = FixtureInfo()
    let detailsStorage = ObjectDetailsStorage()
    init(object: String = "owned", space: String = "owned-space", mode: DocumentMode = .handling) {
        state = State(object: object, space: space, mode: mode)
    }
    private func read<Value>(_ body: (State) -> Value) -> Value {
        lock.lock(); defer { lock.unlock() }; return body(state)
    }
    func change(object: String? = nil, space: String? = nil, mode: DocumentMode? = nil,
                opened: Bool? = nil, locked: Bool? = nil, editable: Bool? = nil) {
        lock.lock(); defer { lock.unlock() }
        if let object { state.object = object }
        if let space { state.space = space }
        if let mode { state.mode = mode }
        if let opened { state.opened = opened }
        if let locked { state.locked = locked }
        if let editable { state.editable = editable }
    }
    var objectId: String { read { $0.object } }
    var spaceId: String { read { $0.space } }
    var mode: DocumentMode { read { $0.mode } }
    var isOpened: Bool { read { $0.opened } }
    var isLocked: Bool { read { $0.locked } }
    var permissions: ObjectPermissions { read { state in
        var value = ObjectPermissions(); value.canEditBlocks = state.editable; return value
    } }
    var children: [BlockInformation] { [] }
    var parsedProperties: ParsedProperties { ParsedProperties() }
    var isEmpty: Bool { false }
    var details: ObjectDetails? { nil }
    var syncStatus: SpaceSyncStatus? { nil }
    var syncPublisher: AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    func subscibeFor(update: [BaseDocumentUpdate]) -> AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    @MainActor func open() async throws { await lifecycle.record("open") }
    @MainActor func update() async throws { await lifecycle.record("update") }
    @MainActor func close() async throws { await lifecycle.record("close") }
}

actor OwnershipGate {
    private var entered = false
    private var released = false
    private var waiters: [CheckedContinuation<Void, Never>] = []
    private var pending: [CheckedContinuation<Void, Never>] = []
    func hold() async {
        entered = true
        let notices = waiters; waiters = []
        for notice in notices { notice.resume() }
        if !released { await withCheckedContinuation { pending.append($0) } }
    }
    func waitForEntry() async {
        if entered { return }
        await withCheckedContinuation { waiters.append($0) }
    }
    func release() {
        released = true
        let values = pending; pending = []
        for value in values { value.resume() }
    }
}

final class HeldOwnershipTextService: TextServiceProtocol {
    let gate: OwnershipGate
    let target: TextProbe
    init(gate: OwnershipGate, target: TextProbe) { self.gate = gate; self.target = target }
    func setText(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        await gate.hold()
        try await target.setText(contextId: contextId, blockId: blockId, middlewareString: middlewareString)
    }
    func setTextForced(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try await target.setTextForced(contextId: contextId, blockId: blockId, middlewareString: middlewareString)
    }
    func setStyle(contextId: String, blockId: String, style: Style) async throws {
        try await target.setStyle(contextId: contextId, blockId: blockId, style: style)
    }
    func split(contextId: String, blockId: String, range: NSRange, style: Style, mode: SplitMode) async throws -> String {
        try await target.split(contextId: contextId, blockId: blockId, range: range, style: style, mode: mode)
    }
    func merge(contextId: String, firstBlockId: String, secondBlockId: String) async throws {
        try await target.merge(contextId: contextId, firstBlockId: firstBlockId, secondBlockId: secondBlockId)
    }
    func checked(contextId: String, blockId: String, newValue: Bool) async throws {
        try await target.checked(contextId: contextId, blockId: blockId, newValue: newValue)
    }
    func setTextIcon(contextId: String, blockId: String, imageObjectId: String, emojiUnicode: String) async throws {
        try await target.setTextIcon(contextId: contextId, blockId: blockId, imageObjectId: imageObjectId, emojiUnicode: emojiUnicode)
    }
}

struct HeldOwnershipPublication: EditorLocalEventPublishing {
    let gate: OwnershipGate
    let target: LocalPublisherProbe
    func setStyle(contextId: String, blockId: String) async {
        await gate.hold()
        await target.setStyle(contextId: contextId, blockId: blockId)
    }
    func refresh(contextId: String) async { await target.refresh(contextId: contextId) }
    func setToggled(contextId: String, blockId: String) async { await target.setToggled(contextId: contextId, blockId: blockId) }
    func setText(contextId: String, blockId: String, text: MiddlewareString) async {
        await target.setText(contextId: contextId, blockId: blockId, text: text)
    }
    func setLoadingState(contextId: String, blockId: String) async {
        await target.setLoadingState(contextId: contextId, blockId: blockId)
    }
}

@MainActor
private func ownershipData(_ document: OwnershipDocumentProbe) -> EditorPageObject {
    .init(objectId: document.objectId, spaceId: document.spaceId, mode: document.mode)
}

@MainActor
private func ownerFailure(_ operation: () async throws -> Void) async -> EditorDocumentWriteError? {
    do { try await operation(); return nil }
    catch { return error as? EditorDocumentWriteError }
}


extension String { var isNotEmpty: Bool { !isEmpty } }
enum ObjectRestriction: Sendable { case typeChange, delete, duplicate, template, details, relations, blocks }
struct PermissionLayout: Sendable {
    let isFileOrMedia = false, isChat = false, isList = false, isParticipant = false
    let haveIcon = true, haveCover = true, isEditorLayout = true
}
struct ObjectDetails: Sendable {
    var id: String = ""
    var isArchived = false
    var isTemplate = false
    var isObjectType = false
    var canMakeTemplate = true
    var resolvedLayoutValue = PermissionLayout()
}
final class CallbackRecorder: @unchecked Sendable {
    private let lock = NSLock()
    private var count = 0
    func add() { lock.lock(); count += 1; lock.unlock() }
    var value: Int { lock.lock(); defer { lock.unlock() }; return count }
}
import Foundation

// Explicit protobuf boundary values; the original BlockPosition and BlocksSortType
// declarations and complete table protocol are compiled separately, unchanged.
public extension Anytype_Model_Block.Content {
    enum Dataview {
        public enum Sort {
            public enum TypeEnum: Sendable { case asc, desc }
        }
    }
}

struct OwnedTableInvocation: Equatable, Sendable {
    let operation: String
    let context: String
    var targets: [String] = []
    var dropTarget: String? = nil
    var position: String? = nil
    var rows: Int? = nil
    var columns: Int? = nil
    var sort: String? = nil
}

enum OwnedTableProbeError: Error, Equatable, Sendable { case deliberate }

actor OwnedTableServiceProbe: BlockTableServiceProtocol {
    let label: String
    let gate: OwnershipGate?
    let fails: Bool
    private var calls: [OwnedTableInvocation] = []

    init(label: String, gate: OwnershipGate? = nil, fails: Bool = false) {
        self.label = label
        self.gate = gate
        self.fails = fails
    }

    func snapshot() -> [OwnedTableInvocation] { calls }

    private func record(_ call: OwnedTableInvocation) async throws {
        await gate?.hold()
        calls.append(call)
        if fails { throw OwnedTableProbeError.deliberate }
    }

    func createTable(contextId: String, targetId: String, position: BlockPosition,
                     rowsCount: Int, columnsCount: Int) async throws -> String {
        try await record(.init(operation: "create", context: contextId, targets: [targetId],
            position: String(describing: position), rows: rowsCount, columns: columnsCount))
        return label + "-original-table-id"
    }
    func rowListFill(contextId: String, targetIds: [String]) async throws {
        try await record(.init(operation: "fill", context: contextId, targets: targetIds))
    }
    func insertColumn(contextId: String, targetId: String, position: BlockPosition) async throws {
        try await record(.init(operation: "insert-column", context: contextId, targets: [targetId], position: String(describing: position)))
    }
    func deleteColumn(contextId: String, targetId: String) async throws {
        try await record(.init(operation: "delete-column", context: contextId, targets: [targetId]))
    }
    func columnDuplicate(contextId: String, targetId: String) async throws {
        try await record(.init(operation: "duplicate-column", context: contextId, targets: [targetId]))
    }
    func columnSort(contextId: String, columnId: String, blocksSortType: BlocksSortType) async throws {
        try await record(.init(operation: "sort-column", context: contextId, targets: [columnId], sort: String(describing: blocksSortType)))
    }
    func columnMove(contextId: String, targetId: String, dropTargetID: String, position: BlockPosition) async throws {
        try await record(.init(operation: "move-column", context: contextId, targets: [targetId],
            dropTarget: dropTargetID, position: String(describing: position)))
    }
    func insertRow(contextId: String, targetId: String, position: BlockPosition) async throws {
        try await record(.init(operation: "insert-row", context: contextId, targets: [targetId], position: String(describing: position)))
    }
    func deleteRow(contextId: String, targetId: String) async throws {
        try await record(.init(operation: "delete-row", context: contextId, targets: [targetId]))
    }
    func rowDuplicate(contextId: String, targetId: String) async throws {
        try await record(.init(operation: "duplicate-row", context: contextId, targets: [targetId]))
    }
    func rowMove(contextId: String, targetId: String, dropTargetID: String, position: BlockPosition) async throws {
        try await record(.init(operation: "move-row", context: contextId, targets: [targetId],
            dropTarget: dropTargetID, position: String(describing: position)))
    }
    func clearContents(contextId: String, blockIds: [String]) async throws {
        try await record(.init(operation: "clear-contents", context: contextId, targets: blockIds))
    }
    func clearStyle(contextId: String, blocksIds: [String]) async throws {
        try await record(.init(operation: "clear-style", context: contextId, targets: blocksIds))
    }
}

struct FixtureTableServices: Sendable {
    let action = OwnedTableServiceProbe(label: "action")
    let builder = OwnedTableServiceProbe(label: "builder")
    let simple = OwnedTableServiceProbe(label: "simple")
}

import Foundation

// The original public protocol and forwarding value declarations are compiled.
// These are explicit non-RPC boundaries; protobuf runtime serialization,
// BlockContent rendering, and conversion/service execution are not replaced claims.
@preconcurrency
public protocol ProtobufEnumBoundary: RawRepresentable, Hashable, Sendable {
    init()
    init?(rawValue: Int)
    var rawValue: Int { get }
}
public enum SwiftProtobuf { public typealias Enum = ProtobufEnumBoundary }
public enum Google_Protobuf_Value: Hashable, Sendable {
    case string(String), number(Double), bool(Bool)
}
public enum BlockContent: Hashable, Sendable { case unsupported, link(BlockLink) }
public enum MentionObject: Hashable, Sendable { case noDetails(blockId: String) }
public struct Emoji: Hashable, Sendable { public let value: String }
public enum CoverType: Int, Sendable { case fixture = 1 }

struct OwnedBlockInvocation: Equatable, Sendable {
    let operation: String
    let context: String
    var targets: [String] = []
    var target: String? = nil
    var destination: String? = nil
    var space: String? = nil
    var position: String? = nil
    var middlewarePosition: Int? = nil
    var info: BlockInformation? = nil
    var fields: BlockFields? = nil
    var alignment: Int? = nil
    var color: MiddlewareColor? = nil
    var appearance: BlockLink.Appearance? = nil
    var markup: MarkupType? = nil
    var objectType: String? = nil
    var template: String? = nil
}
enum OwnedBlockProbeError: Error, Equatable, Sendable { case deliberate }

actor OwnedBlockServiceProbe: BlockServiceProtocol {
    let label: String
    let gate: OwnershipGate?
    let fails: Bool
    let missingLast: Bool
    private var calls: [OwnedBlockInvocation] = []

    init(label: String, gate: OwnershipGate? = nil, fails: Bool = false, missingLast: Bool = false) {
        self.label = label; self.gate = gate; self.fails = fails; self.missingLast = missingLast
    }
    func snapshot() -> [OwnedBlockInvocation] { calls }
    private func record(_ call: OwnedBlockInvocation) async throws {
        await gate?.hold()
        calls.append(call)
        if fails { throw OwnedBlockProbeError.deliberate }
    }

    func add(contextId: String, targetId: String, info: BlockInformation, position: BlockPosition) async throws -> String {
        try await record(.init(operation: "add", context: contextId, targets: [targetId], position: String(describing: position), info: info))
        return label + "-original-block-id"
    }

    func addFirstBlock(contextId: String, info: BlockInformation) async throws -> String {
        try await record(.init(operation: "add-first", context: contextId, info: info))
        return label + "-original-block-id"
    }

    func delete(contextId: String, blockIds: [String]) async throws {
        try await record(.init(operation: "delete", context: contextId, targets: blockIds))
    }

    func duplicate(contextId: String, targetId: String, blockIds: [String], position: BlockPosition) async throws {
        try await record(.init(operation: "duplicate", context: contextId, targets: blockIds, target: targetId, position: String(describing: position)))
    }

    func move(contextId: String, blockIds: [String], targetContextID: String, dropTargetID: String, position: BlockPosition) async throws {
        try await record(.init(operation: "move-context", context: contextId, targets: blockIds, target: dropTargetID, destination: targetContextID, position: String(describing: position)))
    }

    func setAlign(objectId: String, blockIds: [String], alignment: LayoutAlignment) async throws {
        try await record(.init(operation: "align", context: objectId, targets: blockIds, alignment: alignment.rawValue))
    }

    func setBackgroundColor(objectId: String, blockIds: [String], color: MiddlewareColor) async throws {
        try await record(.init(operation: "background", context: objectId, targets: blockIds, color: color))
    }

    func setFields(objectId: String, blockId: String, fields: BlockFields) async throws {
        try await record(.init(operation: "fields", context: objectId, targets: [blockId], fields: fields))
    }

    func setBlockColor(objectId: String, blockIds: [String], color: MiddlewareColor) async throws {
        try await record(.init(operation: "text-color", context: objectId, targets: blockIds, color: color))
    }

    func replace(objectId: String, blockIds: [String], targetId: String) async throws {
        try await record(.init(operation: "replace", context: objectId, targets: blockIds, target: targetId))
    }

    func replaceBlock(contextId: String, blockId: String, info: BlockInformation) async throws -> String {
        try await record(.init(operation: "replace-block", context: contextId, targets: [blockId], info: info))
        return label + "-original-block-id"
    }

    func move(objectId: String, blockId: String, targetId: String, position: Anytype_Model_Block.Position) async throws {
        try await record(.init(operation: "move-block", context: objectId, targets: [blockId], target: targetId, middlewarePosition: position.rawValue))
    }

    func moveToPage(objectId: String, blockIds: [String], pageId: String) async throws {
        try await record(.init(operation: "move-page", context: objectId, targets: blockIds, destination: pageId))
    }

    func setLinkAppearance(objectId: String, blockIds: [String], appearance: BlockLink.Appearance) async throws {
        try await record(.init(operation: "appearance", context: objectId, targets: blockIds, appearance: appearance))
    }

    func changeMarkup(objectId: String, blockIds: [String], markType: MarkupType) async throws {
        try await record(.init(operation: "markup", context: objectId, targets: blockIds, markup: markType))
    }

    func lastBlockId(from objectId: String, spaceId: String) async throws -> String {
        try await record(.init(operation: "last-block", context: objectId, space: spaceId))
        if missingLast { throw BlockServiceError.lastBlockIdNotFound }
        return label + "-original-last-id"
    }

    func convertChildrenToObjects(contextId: String, blocksIds: [String], typeUniqueKey: ObjectTypeUniqueKey, templateId: String) async throws -> [String] {
        try await record(.init(operation: "promote", context: contextId, targets: blocksIds, objectType: typeUniqueKey.value, template: templateId))
        return [label + "-link-2", label + "-link-1", label + "-link-2"]
    }

    func createBlockLink(contextId: String, targetId: String, spaceId: String, details: [BundledDetails], typeUniqueKey: ObjectTypeUniqueKey, position: BlockPosition, templateId: String) async throws -> String {
        try await record(.init(operation: "create-link", context: contextId, targets: [targetId], space: spaceId, position: String(describing: position), objectType: typeUniqueKey.value, template: templateId))
        return label + "-original-object-id"
    }
}
struct FixtureBlockServices: Sendable {
    let action = OwnedBlockServiceProbe(label: "action")
    let handler = OwnedBlockServiceProbe(label: "handler")
    let keyboard = OwnedBlockServiceProbe(label: "keyboard")
    let state = OwnedBlockServiceProbe(label: "state")
    let builder = OwnedBlockServiceProbe(label: "builder")
    let viewModel = OwnedBlockServiceProbe(label: "viewModel")
}
@MainActor
struct BlockActionHandlerDependencies {
    let blockService: any BlockServiceProtocol
    let blockTableService: any BlockTableServiceProtocol
    let fileService: any FileActionsServiceProtocol
    let objectService: any ObjectActionsServiceProtocol
    let pasteboardBlockService: any PasteboardBlockServiceProtocol
    let bookmarkService: any BookmarkServiceProtocol
    let objectTypeProvider: any ObjectTypeProviderProtocol
}

@MainActor
struct KeyboardActionHandlerDependencies {
    let blockService: any BlockServiceProtocol
    let keyboardInsertedBlocksStorage: any KeyboardInsertedBlocksStorageProtocol
}

@MainActor
struct EditorPageBlocksStateManagerDependencies {
    let blockService: any BlockServiceProtocol
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let documentsProvider: any DocumentsProviderProtocol
    let objectActionsService: any ObjectActionsServiceProtocol
    let toastPresenter: any ToastPresenterProtocol
}

@MainActor
struct BlockViewModelBuilderDependencies {
    let tableService: any BlockTableServiceProtocol
    let detailsService: any DetailsServiceProtocol
    let audioSessionService: any AudioSessionServiceProtocol
    let objectTypeProvider: any ObjectTypeProviderProtocol
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let blockService: any BlockServiceProtocol
}

@MainActor
struct SimpleTableServiceDependencies {
    let tableService: any BlockTableServiceProtocol
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let defaultObjectService: any DefaultObjectCreationServiceProtocol
    let typesService: any TypesServiceProtocol
}

@MainActor
struct SlashMenuActionHandlerDependencies {
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let objectDateByTimestampService: any ObjectDateByTimestampServiceProtocol
}

@MainActor
struct ObjectHeaderViewModelDependencies {
    let objectHeaderUploadingService: any ObjectHeaderUploadingServiceProtocol
}

@MainActor
struct EditorRouterDependencies {
    let navigationContext: any NavigationContextProtocol
    let templatesCoordinator: any TemplatesCoordinatorProtocol
    let setObjectCreationSettingsCoordinator: any SetObjectCreationSettingsCoordinatorProtocol
    let toastPresenter: any ToastPresenterProtocol
    let templateService: any TemplatesServiceProtocol
}

@MainActor
struct EditorPageViewModelDependencies {
    let objectActionsService: any ObjectActionsServiceProtocol
    let objectTypeProvider: any ObjectTypeProviderProtocol
    let searchService: any SearchServiceProtocol
    let templatesSubscriptionService: any TemplatesSubscriptionServiceProtocol
    let accountManager: any AccountManagerProtocol
    let publishingService: any PublishingServiceProtocol
    let participantStorage: any ParticipantsStorageProtocol
    let publishedUrlBuilder: any PublishedUrlBuilderProtocol
    let keyboardInsertedBlocksStorage: any KeyboardInsertedBlocksStorageProtocol
    let blockService: any BlockServiceProtocol
}
@MainActor protocol AccountManagerProtocol: AnyObject {}
@MainActor protocol AudioSessionServiceProtocol: AnyObject {}
@MainActor protocol DefaultObjectCreationServiceProtocol: AnyObject {}
@MainActor protocol DetailsServiceProtocol: AnyObject {}
@MainActor protocol DocumentsProviderProtocol: AnyObject {}
@MainActor protocol NavigationContextProtocol: AnyObject {}
@MainActor protocol ObjectDateByTimestampServiceProtocol: AnyObject {}
@MainActor protocol ObjectHeaderUploadingServiceProtocol: AnyObject {}
@MainActor protocol ParticipantsStorageProtocol: AnyObject {}
@MainActor protocol PasteboardBlockDocumentServiceProtocol: AnyObject {}
@MainActor protocol PasteboardBlockServiceProtocol: AnyObject {}
@MainActor protocol PublishedUrlBuilderProtocol: AnyObject {}
@MainActor protocol PublishingServiceProtocol: AnyObject {}
@MainActor protocol SearchServiceProtocol: AnyObject {}
@MainActor protocol SetObjectCreationSettingsCoordinatorProtocol: AnyObject {}
@MainActor protocol TemplatesCoordinatorProtocol: AnyObject {}
@MainActor protocol TemplatesServiceProtocol: AnyObject {}
@MainActor protocol TemplatesSubscriptionServiceProtocol: AnyObject {}
@MainActor protocol ToastPresenterProtocol: AnyObject {}
@MainActor protocol TypesServiceProtocol: AnyObject {}
@MainActor final class LifetimeServiceMarker: AccountManagerProtocol, AudioSessionServiceProtocol, BookmarkServiceProtocol, DefaultObjectCreationServiceProtocol, DetailsServiceProtocol, DocumentsProviderProtocol, FileActionsServiceProtocol, KeyboardInsertedBlocksStorageProtocol, NavigationContextProtocol, ObjectActionsServiceProtocol, ObjectDateByTimestampServiceProtocol, ObjectHeaderUploadingServiceProtocol, ObjectTypeProviderProtocol, ParticipantsStorageProtocol, PasteboardBlockDocumentServiceProtocol, PasteboardBlockServiceProtocol, PublishedUrlBuilderProtocol, PublishingServiceProtocol, SearchServiceProtocol, SetObjectCreationSettingsCoordinatorProtocol, TemplatesCoordinatorProtocol, TemplatesServiceProtocol, TemplatesSubscriptionServiceProtocol, ToastPresenterProtocol, TypesServiceProtocol {}
@MainActor let fixtureMarker = LifetimeServiceMarker()
@MainActor func fixtureServices(events: any EditorLocalEventPublishing, tableServices: FixtureTableServices? = nil, blockServices: FixtureBlockServices? = nil) -> EditorPageServiceDependencies {
    let ownedTables = tableServices ?? FixtureTableServices()
    let ownedBlocks = blockServices ?? FixtureBlockServices()
    return .init(
        blockActionService: .init(objectActionService: fixtureMarker, textServiceHandler: TextProbe(), blockService: ownedBlocks.action, bookmarkService: fixtureMarker, fileService: fixtureMarker, objectTypeProvider: fixtureMarker, keyboardInsertedBlocksStorage: fixtureMarker),
        blockActionHandler: .init(blockService: ownedBlocks.handler, blockTableService: ownedTables.action, fileService: fixtureMarker, objectService: fixtureMarker, pasteboardBlockService: fixtureMarker, bookmarkService: fixtureMarker, objectTypeProvider: fixtureMarker),
        keyboardHandler: .init(blockService: ownedBlocks.keyboard, keyboardInsertedBlocksStorage: fixtureMarker),
        blocksStateManager: .init(blockService: ownedBlocks.state, pasteboardService: fixtureMarker, documentsProvider: fixtureMarker, objectActionsService: fixtureMarker, toastPresenter: fixtureMarker),
        blockBuilder: .init(tableService: ownedTables.builder, detailsService: fixtureMarker, audioSessionService: fixtureMarker, objectTypeProvider: fixtureMarker, pasteboardService: fixtureMarker, blockService: ownedBlocks.builder),
        simpleTable: .init(tableService: ownedTables.simple, pasteboardService: fixtureMarker, defaultObjectService: fixtureMarker, typesService: fixtureMarker),
        slashMenu: .init(pasteboardService: fixtureMarker, objectDateByTimestampService: fixtureMarker),
        header: .init(objectHeaderUploadingService: fixtureMarker),
        router: .init(navigationContext: fixtureMarker, templatesCoordinator: fixtureMarker, setObjectCreationSettingsCoordinator: fixtureMarker, toastPresenter: fixtureMarker, templateService: fixtureMarker),
        viewModel: .init(objectActionsService: fixtureMarker, objectTypeProvider: fixtureMarker, searchService: fixtureMarker, templatesSubscriptionService: fixtureMarker, accountManager: fixtureMarker, publishingService: fixtureMarker, participantStorage: fixtureMarker, publishedUrlBuilder: fixtureMarker, keyboardInsertedBlocksStorage: fixtureMarker, blockService: ownedBlocks.viewModel),
        localEvents: events
    )
}
