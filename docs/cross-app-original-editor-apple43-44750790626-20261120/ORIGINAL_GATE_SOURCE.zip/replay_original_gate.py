#!/usr/bin/env python3
"""Re-read the authentic Apple43 artifact with the exact original result gates.
This does not run Swift, Xcode, simulator tests, or native writes.
"""
from pathlib import Path
from datetime import datetime, timezone
import collections
import hashlib
import importlib
import json
import re
import sqlite3
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
RAW = ROOT / "extracted"
HEAD = "7c0fb7fca950197adee66e1b577727a4359d4068"
RUN = 44750790626
ARTIFACT = 14641683197

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode())

def main():
    started = datetime.now(timezone.utc).isoformat()
    receipts = load(ROOT / "GITHUB_RECEIPTS.json")
    run = receipts["run"]
    artifact = receipts["artifacts"]["artifacts"][0]
    assert run["id"] == RUN and run["head_sha"] == HEAD
    assert run["run_attempt"] == 1 and run["status"] == "completed" and run["conclusion"] == "success"
    assert artifact["id"] == ARTIFACT and artifact["workflow_run"]["id"] == RUN
    assert artifact["workflow_run"]["head_sha"] == HEAD and artifact["expired"] is False
    full_jobs = load(ROOT / "GITHUB_COMPLETE_JOBS.json")
    matching_jobs = [j for j in full_jobs["jobs"] if j["id"] == 136337842510]
    assert len(matching_jobs) == 1
    job = matching_jobs[0]
    assert job["run_id"] == RUN and job["head_sha"] == HEAD and job["conclusion"] == "success"
    assert job["run_attempt"] == 1
    upload = [s for s in job["steps"] if s["name"] == "Upload original editor Apple evidence"]
    assert len(upload) == 1 and upload[0]["conclusion"] == "success"
    assert upload[0]["started_at"] <= artifact["created_at"] <= upload[0]["completed_at"]
    outer = ROOT / ("artifact-" + str(ARTIFACT) + ".zip")
    assert outer.stat().st_size == artifact["size_in_bytes"] == 799625
    assert artifact["digest"] == "sha256:" + sha(outer)
    assert sha(outer) == "8a44af75463a4dfc198e4e00e9dc61dba3c3409d40fc562c1737e14150670e04"
    with zipfile.ZipFile(outer) as z:
        assert z.namelist() == ["Pinkha-Native-Derived-Evidence.zip"]
        assert z.testzip() is None
        assert z.read(z.namelist()[0]) == (ROOT / z.namelist()[0]).read_bytes()
    raw_files = []
    with zipfile.ZipFile(ROOT / "Pinkha-Native-Derived-Evidence.zip") as z:
        assert z.testzip() is None
        for item in z.infolist():
            if item.is_dir():
                continue
            relative = Path(item.filename)
            assert not relative.is_absolute() and ".." not in relative.parts
            b = z.read(item)
            assert b == (RAW / relative).read_bytes()
            raw_files.append({"path": item.filename, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
    inputs = []
    for entry in load(ROOT / "AUTHENTICATED_SOURCE_INDEX.json"):
        file = SOURCE / entry["path"]
        b = file.read_bytes()
        assert hashlib.sha1(b"blob " + str(len(b)).encode() + b"\0" + b).hexdigest() == entry["git_blob"]
        inputs.append(dict(entry, bytes=len(b), sha256=hashlib.sha256(b).hexdigest()))
    sys.path.insert(0, str(SOURCE / "Tools/Hanlin"))
    profile = importlib.import_module("original_editor_profile")
    host = importlib.import_module("run_host_tests")
    heart_gate = importlib.import_module("prepare_original_editor_heart")
    manifest = profile.manifest()
    expected = set()
    for suite, item in manifest["suites"].items():
        b = (SOURCE / item["path"]).read_bytes()
        assert hashlib.sha256(b).hexdigest() == item["sha256"]
        expected.update(profile.validate_declarations(b.decode("utf-8"), suite, item["methods"]))
    assert len(expected) == 43
    trees = {x["path"]: x["sha"] for x in receipts["root_contents"] if x["path"] in manifest["application_trees"]}
    assert trees == manifest["application_trees"]
    execution = load(RAW / "execution.json")
    selection = load(RAW / "original-editor-selection.json")
    summary = load(RAW / "original-editor-summary.json")
    tree = load(RAW / "original-editor-tests.json")
    preflight = load(RAW / "preflight/preflight.json")
    assert execution["source_sha"] == selection["source_sha"] == preflight["source_sha"] == HEAD
    assert execution["run_id"] == preflight["run_id"] == str(RUN)
    assert execution["run_attempt"] == preflight["run_attempt"] == "1"
    assert execution["status"] == "ORIGINAL_EDITOR_COMPONENT_PASS" and execution["phase"] == "COMPLETE"
    assert execution["post_execution_source_verified"] is True and execution["release_accepted"] is False
    assert selection["ui_executed"] == preflight["ui_tests_executed"] == 0
    assert set(selection["methods"]) == set(execution["expected_methods"]) == expected
    expected_test_hashes = {x["path"]: x["sha256"] for x in manifest["suites"].values()}
    assert selection["test_source_sha256"] == execution["test_source_hashes"] == expected_test_hashes
    assert execution["original_editor_manifest_sha256"] == selection["profile_manifest_sha256"] == sha(SOURCE / "Tools/Hanlin/original_editor_profile.json")
    assert execution["raw_summary_sha256"] == sha(RAW / "original-editor-summary.json")
    assert execution["raw_tests_sha256"] == sha(RAW / "original-editor-tests.json")
    udid = preflight["selected"]["ipad"]["udid"]
    actual = host.validate_results(summary, tree, expected, udid, host.HostTestProfile.ORIGINAL_EDITOR)
    assert actual == execution["actual"]
    assert summary["runtimeWarnings"] == [] and summary["testFailures"] == []
    uri = (RAW / "OriginalEditor.xcresult/database.sqlite3").as_uri() + "?mode=ro"
    with sqlite3.connect(uri, uri=True) as db:
        rows = db.execute("SELECT c.identifier,r.result,r.duration FROM TestCaseRuns r JOIN TestCases c ON c.rowid=r.testCase_fk ORDER BY c.identifier").fetchall()
        assert len(rows) == 43 and {x[0] for x in rows} == {x + "()" for x in expected}
        assert all(x[1] == "Success" for x in rows)
        assert db.execute("SELECT COUNT(*) FROM TestCases").fetchone()[0] == 43
        assert db.execute("SELECT COUNT(*) FROM TestSuites").fetchone()[0] == 7
        assert db.execute("SELECT COUNT(*) FROM TestIssues").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM SkipNotices").fetchone()[0] == 0
        aggregate_rows = db.execute("SELECT COUNT(*) FROM TestCaseResultsByDestinationAndConfiguration").fetchone()[0]
    pins_actual = {x["identity"]: x for x in load(RAW / "actual-package-pins.json")["pins"]}
    pins_source = {x["identity"]: x for x in load(SOURCE / "Anytype.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved")["pins"]}
    assert len(pins_actual) == len(pins_source) == 44 and pins_actual == pins_source
    sdk_pin = load(SOURCE / "Tools/Hanlin/source.json")
    sdk = load(RAW / "hanlin-snapshot.json")
    assert sdk["revision"] == execution["hanlin_revision"] == sdk_pin["revision"]
    assert len(sdk["files"]) == 407 and sha(RAW / "hanlin-snapshot.json") == execution["hanlin_snapshot_sha256"]
    assert all(any(p.startswith(prefix + "/") for prefix in sdk_pin["packages"]) and re.fullmatch("[0-9a-f]{64}", h) for p,h in sdk["files"].items())
    for name, commit in execution["dependency_checkouts"].items():
        assert pins_actual[name]["state"]["revision"] == commit
    assert execution["dependency_checkouts"]["swift-ai-sdk"] == sdk_pin["swiftAISDKRevision"]
    kit = execution["dependency_checkouts"]["torahinspectorkit"]
    kit_source = (SOURCE / "Modules/PinkhaKit/Package.swift").read_text()
    assert 'revision: "' + kit + '"' in kit_source
    assert 'revision = ' + kit + ';' in (SOURCE / 'Anytype.xcodeproj/project.pbxproj').read_text()
    producer_run = load(RAW / "heart-source/original-heart-producer-run.json")
    producer_artifact = load(RAW / "heart-source/original-heart-artifact.json")
    heart_gate.verify_metadata(producer_run, producer_artifact, manifest["heart"])
    download = load(RAW / "heart-source/original-heart-download.json")
    installed = load(RAW / "heart/heart-installation.json")
    heart = load(RAW / "heart/custom-heart-build.json")
    original_inventory = load(SOURCE / "docs/pinkha/torah-integration/evidence/native-derived/8494cfb347/approval/revision-14/native-heart-integration.json")
    assert download["consumer_sha"] == installed["app_source_sha"] == HEAD
    assert download["outer_zip_sha256"] == manifest["heart"]["zip_sha256"]
    assert installed["archive_sha256"] == download["inner_archive_sha256"]
    assert installed["source_run_id"] == str(manifest["heart"]["run_id"])
    assert installed["status"] == heart["status"] == "PASS" and heart["target"] == "ios"
    assert heart["files"] == original_inventory["files"]
    assert installed["patch_sha256"] == heart["patch_sha256"] == original_inventory["patch_sha256"]
    assert installed["marker"] == heart["marker"] == "pinkha-native-derived-v1-" + original_inventory["patch_sha256"]
    copies = load(RAW / "runtime-copies.json")
    assert copies["root_present"] is True and copies["test_host_present"] is True
    assert len(copies["copies"]) == 2 and all(x["marker_present"] is True for x in copies["copies"].values())
    commands = [load(x) for x in sorted(RAW.glob("command-*.json"))]
    assert len(commands) == 5 and all(x["exit_code"] == 0 and x["status"] == "SUCCEEDED" for x in commands)
    assert commands[2]["command"] == execution["build_command"] and commands[4]["command"] == execution["test_command"]
    assert commands[3]["command"][:3] == ["codesign", "--verify", "--strict"]
    assert execution["configuration"] == "Debug-Anytype" and execution["build_succeeded"] is True
    assert commands[2]["command"][:8] == ["xcodebuild","build-for-testing","-project","Anytype.xcodeproj","-scheme","Anytype","-configuration","Debug-Anytype"]
    assert commands[4]["command"][1] == "test-without-building"
    selected = {"-only-testing:AnytypeTests/" + suite for suite in manifest["suites"]}
    assert {x for x in commands[2]["command"] if x.startswith("-only-testing:")} == selected
    assert {x for x in commands[4]["command"] if x.startswith("-only-testing:")} == selected
    joblog = (ROOT / "job-136337842510.log").read_text(encoding="utf-8-sig")
    host_rows = [l for l in joblog.splitlines() if re.search(r"test_\w+ \(.+\) \.\.\. (ok|skipped|FAIL|ERROR)",l)]
    assert len(host_rows) == 74 and len(set(re.sub(r"^\S+Z ", "",x) for x in host_rows)) == 74
    assert all(x.endswith("ok") for x in host_rows) and "Ran 74 tests in " in joblog
    assert any("test_sigterm_flushes_partial_log_and_stops_only_the_owned_child_group" in x for x in host_rows)
    assert any("test_success_and_failure_keep_output_and_distinct_completed_receipts" in x for x in host_rows)
    warnings = [l for l in (RAW / "command-02.log").read_text().splitlines() if re.search(r"\bwarning:",l)]
    messages = collections.Counter(re.sub(r"^.*?warning:","warning:",x) for x in warnings)
    owned = [x for x in warnings if re.search(r"EditorDocument|PreparedEditor|DocumentOwned|TextServiceHandler|EditorLocalEvent",x)]
    after = {x["path"]: sha(SOURCE / x["path"]) for x in inputs}
    assert after == {x["path"]: x["sha256"] for x in inputs}
    write(ROOT / "CASE_TABLE.json", [{"identifier":x[0],"result":x[1],"duration_seconds":x[2]} for x in rows])
    write(ROOT / "RAW_FILES.json", raw_files)
    write(ROOT / "SOURCE_INPUTS.json", {"head":HEAD,"files":inputs,"unchanged_after_replay":True,"application_trees":trees})
    write(ROOT / "HOST_CONTROLS.json", {"executed":74,"passed":74,"failed":0,"skipped":0,"rows":host_rows})
    write(ROOT / "WARNINGS.json", {"build_warning_line_count":len(warnings),"message_string_count":len(messages),"scope":"Compiler/tool warning lines in original command-02.log; not unique source defects and not runtimeWarnings.","message_strings":dict(sorted(messages.items())),"owned_file_lines":owned,"runtime_warnings":summary["runtimeWarnings"],"lines":warnings})
    result = {"schema":"authenticated-apple43-review.v1","status":"PASS","started_at":started,"finished_at":datetime.now(timezone.utc).isoformat(),"repository":"davidpovarsky/anytype-swift","run_id":RUN,"job_id":136337842510,"run_attempt":1,"head":HEAD,"branch":run["head_branch"],"application_source":manifest["application_base"],"artifact":{"id":ARTIFACT,"bytes":outer.stat().st_size,"sha256":sha(outer),"inner_bytes":(ROOT/"Pinkha-Native-Derived-Evidence.zip").stat().st_size,"inner_sha256":sha(ROOT/"Pinkha-Native-Derived-Evidence.zip"),"raw_members_verified":len(raw_files)},"original_gate_replay":actual,"xcresult_sqlite":{"named_cases":43,"actual_case_runs":43,"successful_runs":43,"suites":7,"issues":0,"skip_notices":0,"aggregate_rows_not_tests":aggregate_rows},"host_controls":{"executed":74,"passed":74,"failed":0,"skipped":0,"posix_controls_executed":2},"source":{"canonical_input_files_verified":len(inputs),"application_trees":trees,"test_files":7,"package_pins_exact":44,"sdk_files_ci_verified_before_after":407,"sdk_revision":sdk["revision"],"sdk_snapshot_sha256":sha(RAW/"hanlin-snapshot.json"),"post_execution_source_verified":True},"heart":{"original_metadata_gate":"PASS","producer_run":manifest["heart"]["run_id"],"artifact":manifest["heart"]["artifact_id"],"outer_sha256":manifest["heart"]["zip_sha256"],"inner_sha256":download["inner_archive_sha256"],"patch_sha256":heart["patch_sha256"],"original_source_inventory_equal":True,"framework_files_ci_verified":len(heart["artifacts"]),"slice_rows_ci_verified":len(heart["binary_slices"]),"runtime_copies":copies},"build":{"configuration":"Debug-Anytype","build_exit":0,"strict_codesign_exit":0,"test_without_building_exit":0,"source_xcode":preflight["xcode"],"source_swift":preflight["swift"],"app_executable_sha256":execution["app_executable_sha256"],"test_executable_sha256":execution["test_executable_sha256"],"xctestrun_sha256":execution["xctestrun_sha256"]},"warnings":{"build_lines":len(warnings),"message_strings":len(messages),"owned_file_lines":len(owned),"runtime_warnings":0},"scope":"Actual original Anytype app build and 43 original target component methods on one arm64 iOS27 simulator; controlled service/document fixtures.","not_established":["Original block-editing UI or native Maktabah embedding","Durable annotation integration or live-account writer isolation","Physical-device or performance acceptance","Later Maktabah local-body persistence and original editor mount","Independent local rehash of remote app/framework binaries: their exact digests and original verification are retained CI observations"],"release_accepted":False,"ui_test_count":0}
    previous37 = load(ROOT / "PREVIOUS37_REFERENCE.json")
    actual_hashes = {x["path"]: x["sha256"] for x in inputs}
    assert len(previous37["test_source_sha256"]) == 6
    assert all(actual_hashes[k] == v for k,v in previous37["test_source_sha256"].items())
    assert len(previous37["methods"]) == 37
    assert set(previous37["methods"]) <= {x[0] for x in rows}
    source_report = load(ROOT / "SOURCE_INPUTS.json")
    source_report["previous_37"] = dict(previous37, unchanged=True, all_37_named_cases_still_executed=True)
    write(ROOT / "SOURCE_INPUTS.json", source_report)
    result["source"]["previous_37_test_files_byte_identical"] = True
    result["source"]["previous_37_methods_all_executed"] = True
    result["workflow_other_jobs"] = {"skipped_unselected_jobs": sum(j["conclusion"] == "skipped" for j in full_jobs["jobs"]),
        "selected_completed_jobs": 1, "scope": "Unselected dispatcher jobs; these are not XCTest skips."}
    result["build"].update(started_at=commands[2]["started_at"], finished_at=commands[2]["finished_at"],
        tests_started_at=commands[4]["started_at"], tests_finished_at=commands[4]["finished_at"])
    result["warnings"]["owned_non_timing_lines"] = [x for x in owned if "took " not in x]
    result["warnings"]["owned_timing_line_count"] = sum("took " in x for x in owned)
    write(ROOT / "REVIEW.json",result)
    print(json.dumps({"status":result["status"],"cases":43,"host_controls":74,"source_inputs":len(inputs),"raw_members":len(raw_files),"review_sha256":sha(ROOT/"REVIEW.json")},indent=2))

if __name__ == "__main__":
    main()
