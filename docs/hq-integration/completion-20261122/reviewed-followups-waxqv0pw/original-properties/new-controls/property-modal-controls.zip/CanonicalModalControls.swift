import Foundation

// Disposable immutable input values only. No account, store, document open,
// search, protobuf decoding, editor, or native RPC is implemented here.
private final class CanonicalModalDocument: BaseDocumentProtocol, EditorDocumentWriteLifetimeProviding, Sendable {
    let objectId: String
    let spaceId: String
    let mode = DocumentMode.handling
    let isOpened = true
    let isLocked = false
    let permissions = ObjectPermissions()
    let editorWriteLifetime = EditorDocumentWriteLifetime()

    init(objectId: String, spaceId: String) {
        self.objectId = objectId
        self.spaceId = spaceId
    }
}

@MainActor
private final class CanonicalModalCurrentness {
    var current = true
}

private enum CanonicalModalFailure: Error {
    case assertion(String)
    case acceptedInvalidInput(String)
}

@MainActor
enum CanonicalModalControls {
    static let expectedIDs = [
        "modal.canonical_json_roundtrip_retains_raw_internal_identities",
        "modal.canonical_result_rejects_missing_incomplete_and_malformed_identity",
        "modal.canonical_result_requires_exact_space_bytes",
        "modal.identity_snapshot_cannot_cross_scope_or_outlive_current_source",
        "modal.original_discovery_filters_decoded_candidates_without_fallback",
        "modal.original_discovery_rejects_two_canonical_roots"
    ]

    private static func require(_ condition: @autoclosure () -> Bool, _ message: String) throws {
        if !condition() { throw CanonicalModalFailure.assertion(message) }
    }

    private static func scope(
        spaceId: String = "owned-space",
        currentness: CanonicalModalCurrentness? = nil
    ) throws -> OriginalEditorPropertyScope {
        let document = CanonicalModalDocument(objectId: "owned-object", spaceId: spaceId)
        let currentness = currentness ?? CanonicalModalCurrentness()
        let binding = try EditorDocumentWriteSourceBinding(
            lifetime: EditorDocumentWriteLifetime(),
            accountLifetime: EditorDocumentWriteLifetime(),
            isCurrent: { currentness.current }
        )
        let owner = try EditorDocumentWriteOwner(
            data: .init(objectId: document.objectId, spaceId: document.spaceId, mode: document.mode),
            lifetimeDocument: document, sourceBinding: binding
        )
        return OriginalEditorPropertyScope(
            owner: owner, objectId: document.objectId, spaceId: document.spaceId, document: document
        )
    }

    private static func manifest(spaceId: String = "owned-space", rootId: String = "manifest-root") -> PinkhaSpaceManifest {
        PinkhaSpaceManifest(
            spaceId: spaceId, manifestObjectId: rootId,
            orderPropertyId: "internal-order-id", orderPropertyKey: "internal-order-key",
            documentAssociationsPropertyId: "internal-canonical-id",
            documentAssociationsPropertyKey: "internal-canonical-key",
            createdAt: Date(timeIntervalSince1970: 1_700_000_000),
            updatedAt: Date(timeIntervalSince1970: 1_700_000_000)
        )
    }

    private static func candidate(
        _ manifest: PinkhaSpaceManifest,
        resultId: String? = nil,
        resultSpace: String? = nil
    ) throws -> CanonicalDiscoveryCandidate {
        CanonicalDiscoveryCandidate(
            id: resultId ?? manifest.manifestObjectId ?? "manifest-root",
            spaceId: resultSpace ?? manifest.spaceId,
            values: [BundledPropertyKey.description.rawValue: .init(stringValue: try manifest.toJSONString())]
        )
    }

    static func run() async throws -> [String] {
        var passed: [String] = []

        // The actual Foundation Codable model and original identity matcher
        // execute together with the new production post-read validator.
        do {
            let scope = try scope()
            let original = manifest()
            let decoded = try PinkhaSpaceManifest.fromJSONString(original.toJSONString())
            try require(decoded == original, "actual manifest Codable roundtrip changed fields")
            let snapshot = try scope.probeValidateCanonicalResult(decoded)
            guard let identities = try scope.probeInternalIdentities(snapshot) else {
                throw CanonicalModalFailure.assertion("complete canonical identities were lost")
            }
            try require(identities.canonicalPropertyId.utf8.elementsEqual(original.documentAssociationsPropertyId.utf8), "canonical ID bytes changed")
            try require(identities.canonicalPropertyKey.utf8.elementsEqual(original.documentAssociationsPropertyKey.utf8), "canonical key bytes changed")
            try require(identities.orderPropertyId.utf8.elementsEqual(original.orderPropertyId.utf8), "order ID bytes changed")
            try require(identities.orderPropertyKey.utf8.elementsEqual(original.orderPropertyKey.utf8), "order key bytes changed")
            try require(identities.isInternal(propertyId: original.documentAssociationsPropertyId, key: "ordinary-key"), "canonical ID was not protected")
            try require(identities.isInternal(propertyId: "ordinary-id", key: original.documentAssociationsPropertyKey), "canonical key was not protected")
            try require(identities.isInternal(propertyId: original.orderPropertyId, key: "ordinary-key"), "order ID was not protected")
            try require(identities.isInternal(propertyId: "ordinary-id", key: original.orderPropertyKey), "order key was not protected")
            try require(!identities.isInternal(propertyId: "ordinary-id", key: "ordinary-key"), "unrelated input falsely matched an internal identity")
            passed.append(expectedIDs[0])
        }

        do {
            let scope = try scope()
            var invalid: [(String, PinkhaSpaceManifest?)] = [("absent canonical result", nil)]
            var value = manifest(); value.provisioningState = .inProgress
            invalid.append(("incomplete canonical result", value))
            value = manifest(); value.schemaVersion += 1
            invalid.append(("unsupported schema", value))
            value = manifest(); value.manifestObjectId = nil
            invalid.append(("absent canonical root ID", value))
            value = manifest(); value.manifestObjectId = ""
            invalid.append(("empty canonical root ID", value))
            value = manifest(); value.manifestObjectId = "manifest\0root"
            invalid.append(("NUL canonical root ID", value))
            let fields: [(String, WritableKeyPath<PinkhaSpaceManifest, String>)] = [
                ("canonical ID", \.documentAssociationsPropertyId),
                ("canonical key", \.documentAssociationsPropertyKey),
                ("order ID", \.orderPropertyId),
                ("order key", \.orderPropertyKey)
            ]
            for (name, field) in fields {
                value = manifest(); value[keyPath: field] = ""
                invalid.append(("empty " + name, value))
                value = manifest(); value[keyPath: field] = "raw\0identity"
                invalid.append(("NUL " + name, value))
                value = manifest(); value[keyPath: field] = " " + value[keyPath: field] + "\n"
                invalid.append(("trimmed " + name + " must not acquire raw identity", value))
            }
            for (name, input) in invalid {
                do {
                    _ = try scope.probeValidateCanonicalResult(input)
                    throw CanonicalModalFailure.acceptedInvalidInput(name)
                } catch OriginalEditorPropertyModalError.internalIdentityUnavailable { }
            }
            passed.append(expectedIDs[1])
        }

        do {
            let composed = "space-\u{00E9}"
            let decomposed = "space-e\u{0301}"
            try require(composed == decomposed && !composed.utf8.elementsEqual(decomposed.utf8), "Unicode byte-boundary fixture is invalid")
            let scope = try scope(spaceId: composed)
            _ = try scope.probeValidateCanonicalResult(manifest(spaceId: composed))
            for foreign in ["foreign-space", decomposed, composed + "\0"] {
                do {
                    _ = try scope.probeValidateCanonicalResult(manifest(spaceId: foreign))
                    throw CanonicalModalFailure.acceptedInvalidInput("non-exact Space bytes")
                } catch OriginalEditorPropertyModalError.internalIdentityUnavailable { }
            }
            passed.append(expectedIDs[2])
        }

        do {
            let currentness = CanonicalModalCurrentness()
            let first = try scope(currentness: currentness)
            let second = try scope()
            let snapshot = try first.probeValidateCanonicalResult(manifest())
            try first.probeRequireIdentity(snapshot)
            do {
                try second.probeRequireIdentity(snapshot)
                throw CanonicalModalFailure.acceptedInvalidInput("snapshot issued by another scope")
            } catch OriginalEditorPropertyModalError.invalidPropertyIdentity { }
            currentness.current = false
            do {
                _ = try first.probeValidateCanonicalResult(manifest())
                throw CanonicalModalFailure.acceptedInvalidInput("canonical response after current-source invalidation")
            } catch EditorDocumentWriteError.rejected(.documentChanged) { }
            // A later Boolean equality does not revive the captured generation.
            currentness.current = true
            do {
                try first.probeRequireIdentity(snapshot)
                throw CanonicalModalFailure.acceptedInvalidInput("revived old snapshot")
            } catch EditorDocumentWriteError.rejected(.retired) { }
            passed.append(expectedIDs[3])
        }

        do {
            let emptySelection = try OriginalManifestDiscoveryProbe.discover(candidates: [:], spaceId: "owned-space")
            try require(emptySelection == nil, "missing discovery candidates selected a root")
            let valid = try candidate(manifest())
            var foreignManifest = manifest(rootId: "wrong-space-payload"); foreignManifest.spaceId = "foreign-space"
            let malformed = CanonicalDiscoveryCandidate(id: "malformed", spaceId: "owned-space", values: [BundledPropertyKey.description.rawValue: .init(stringValue: "{broken")])
            let rootMismatch = try candidate(manifest(rootId: "recorded-root"), resultId: "different-result-root")
            let foreignResult = try candidate(manifest(rootId: "wrong-space-result"), resultSpace: "foreign-space")
            let foreignPayload = try candidate(foreignManifest, resultId: "wrong-space-payload", resultSpace: "owned-space")
            let missingPayload = CanonicalDiscoveryCandidate(id: "missing-payload", spaceId: "owned-space", values: [:])
            let rejected = [malformed, rootMismatch, foreignResult, foreignPayload, missingPayload]
            let absent = try OriginalManifestDiscoveryProbe.discover(
                candidates: Dictionary(uniqueKeysWithValues: rejected.map { ($0.id, $0) }), spaceId: "owned-space"
            )
            try require(absent == nil, "invalid decoded candidates were used as canonical authority")
            let selected = try OriginalManifestDiscoveryProbe.discover(
                candidates: Dictionary(uniqueKeysWithValues: ([valid] + rejected).map { ($0.id, $0) }), spaceId: "owned-space"
            )
            try require(selected == valid.id, "original filter did not select the only canonical root")
            passed.append(expectedIDs[4])
        }

        do {
            let one = try candidate(manifest(rootId: "canonical-one"))
            let two = try candidate(manifest(rootId: "canonical-two"))
            do {
                _ = try OriginalManifestDiscoveryProbe.discover(
                    candidates: [one.id: one, two.id: two], spaceId: "owned-space"
                )
                throw CanonicalModalFailure.acceptedInvalidInput("two canonical roots")
            } catch {
                try require(OriginalManifestDiscoveryProbe.isAmbiguous(error), "unexpected error instead of original ManifestDiscoveryError.ambiguous")
            }
            passed.append(expectedIDs[5])
        }

        try require(passed == expectedIDs, "canonical case identities are incomplete or reordered")
        return passed
    }
}
