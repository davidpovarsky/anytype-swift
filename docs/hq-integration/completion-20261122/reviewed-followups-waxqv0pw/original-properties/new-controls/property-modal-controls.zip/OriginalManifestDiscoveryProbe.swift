import Foundation

// Explicit already-decoded response projections. These do not search, decode
// protobufs or impersonate ObjectDetails/Lib. The original final discovery
// filter below consumes exactly these three fields and the string projection.
struct CanonicalDiscoveryValue: Sendable { let stringValue: String }
struct CanonicalDiscoveryCandidate: Sendable {
    let id: String
    let spaceId: String
    let values: [String: CanonicalDiscoveryValue]
}

enum OriginalManifestDiscoveryProbe {
    static func discover(candidates: [String: CanonicalDiscoveryCandidate], spaceId: String) throws -> String? {
        let valid = candidates.values.filter { details in
            guard details.spaceId == spaceId,
                  let raw = details.values[BundledPropertyKey.description.rawValue]?.stringValue,
                  let manifest = try? PinkhaSpaceManifest.fromJSONString(raw),
                  manifest.spaceId == spaceId else { return false }
            return manifest.manifestObjectId == nil || manifest.manifestObjectId == details.id
        }
        // Neither discovery nor an engine rebuild may delete synced manifests.
        // Ambiguity is a recoverable explicit error, not permission to pick one.
        guard valid.count <= 1 else { throw ManifestDiscoveryError.ambiguous }
        return valid.first?.id
    }

    private enum ManifestDiscoveryError: Error { case ambiguous }

    static func isAmbiguous(_ error: Error) -> Bool {
        guard case .ambiguous? = error as? ManifestDiscoveryError else { return false }
        return true
    }
}
