import Foundation

// New causal controls for the property-modal owner boundary. The packaging
// harness supplies the exact production withCurrent/withActionCallback/
// prepareAction regions and the unchanged original Owner, Lifetime, Operation,
// Binding and PreparedEditorPageDocument implementation. This file supplies
// explicit disposable document values and effect logs only; it does not open
// an account, emulate a Factory, call Lib, or run the original property UI.
// Source lineage: modal patch
// 377ef209aa567db9f95728f54be101726befea96b2e2cc36b28d0ca3a8bb729d.
// Canonical Owner SHA256:
// b0ae02be8c28c22246d29bf927cb154e10019d841f3b831771f968a8938f7d46.

private struct ModalOwnerControlFailure: Error, Sendable, CustomStringConvertible {
    let description: String
}

private final class ModalOwnerDocument: BaseDocumentProtocol, EditorDocumentWriteLifetimeProviding, Sendable {
    let objectId: String
    let spaceId = "modal-owned-space"
    let mode = DocumentMode.handling
    let isOpened = true
    let isLocked = false
    let editorWriteLifetime = EditorDocumentWriteLifetime()
    let permissions: ObjectPermissions

    init(objectId: String, permitsList: Bool = true) {
        self.objectId = objectId
        var permissions = ObjectPermissions()
        permissions.canEditBlocks = true
        permissions.editBlocks = .edit
        permissions.canEditDetails = true
        permissions.canEditRelationValues = true
        permissions.canEditPropertiesList = permitsList
        permissions.canArchive = true
        self.permissions = permissions
    }
}

@MainActor
private final class ModalOwnerEffects {
    private(set) var values: [String] = []
    func append(_ value: String) { values.append(value) }
}

@MainActor
private final class ModalOwnerFixture {
    let document: ModalOwnerDocument
    let sourceLifetime: EditorDocumentWriteLifetime
    let accountLifetime: EditorDocumentWriteLifetime
    let owner: EditorDocumentWriteOwner
    let scope: OriginalEditorPropertyScope

    init(permitsList: Bool = true) throws {
        let document = ModalOwnerDocument(objectId: "modal-parent", permitsList: permitsList)
        let source = EditorDocumentWriteLifetime()
        let account = EditorDocumentWriteLifetime()
        let sourceBinding = try EditorDocumentWriteSourceBinding(
            lifetime: source, accountLifetime: account, isCurrent: { true }
        )
        let owner = try EditorDocumentWriteOwner(
            data: .init(objectId: document.objectId, spaceId: document.spaceId, mode: document.mode),
            lifetimeDocument: document, sourceBinding: sourceBinding
        )
        self.document = document
        sourceLifetime = source
        accountLifetime = account
        self.owner = owner
        scope = OriginalEditorPropertyScope(
            owner: owner, objectId: document.objectId, spaceId: document.spaceId, document: document
        )
    }

    // An actual child Owner is constructed from the original parent's frozen
    // childSourceBinding. The document is an explicit input, not a fake opener.
    func child() throws -> ModalOwnerChild {
        let document = ModalOwnerDocument(objectId: "modal-selected-property")
        let binding = try owner.childSourceBinding()
        let owner = try EditorDocumentWriteOwner(
            data: .init(objectId: document.objectId, spaceId: document.spaceId, mode: document.mode),
            lifetimeDocument: document, sourceBinding: binding
        )
        return ModalOwnerChild(document: document, owner: owner)
    }
}

@MainActor
private final class ModalOwnerChild {
    let document: ModalOwnerDocument
    let owner: EditorDocumentWriteOwner

    init(document: ModalOwnerDocument, owner: EditorDocumentWriteOwner) {
        self.document = document
        self.owner = owner
    }
}

// A deterministic await boundary after the real dispatch permit has begun.
// The test controls only when its explicit effect body returns. No sleep,
// backend completion, or importer completion is inferred from this probe.
@MainActor
private final class ModalOwnerReadGate {
    private var began = false
    private var released = false
    private var earlyFailure: Error?
    private var beginWaiter: CheckedContinuation<Void, Error>?
    private var releaseWaiter: CheckedContinuation<Void, Never>?

    func signalBegan() {
        began = true
        let waiter = beginWaiter
        beginWaiter = nil
        waiter?.resume()
    }

    func signalFailureBeforeBegan(_ error: Error) {
        guard !began else { return }
        earlyFailure = error
        let waiter = beginWaiter
        beginWaiter = nil
        waiter?.resume(throwing: error)
    }

    func waitUntilBegan() async throws {
        if began { return }
        if let earlyFailure { throw earlyFailure }
        try await withCheckedThrowingContinuation { (waiter: CheckedContinuation<Void, Error>) in
            beginWaiter = waiter
        }
    }

    func waitForRelease() async {
        if released { return }
        await withCheckedContinuation { (waiter: CheckedContinuation<Void, Never>) in
            releaseWaiter = waiter
        }
    }

    func release() {
        released = true
        let waiter = releaseWaiter
        releaseWaiter = nil
        waiter?.resume()
    }
}

@MainActor
enum OwnerModalControls {
    static let expectedIDs = [
        "modal_action_callback_reserves_before_task_and_drains",
        "modal_read_callback_cannot_schedule_write_and_latches",
        "modal_parent_add_precedes_child_write_and_publication",
        "modal_child_cannot_reenter_passive_parent_and_latches",
        "modal_missing_list_permission_blocks_reservation_and_capture",
        "modal_reserved_source_retirement_blocks_body_and_revival",
        "modal_prepared_permit_rejects_retired_source_before_effect",
        "modal_account_change_during_read_suppresses_publication"
    ]

    static func run() async throws -> [String] {
        var passed: [String] = []

        try await actionCallbackReservesBeforeTask()
        passed.append("modal_action_callback_reserves_before_task_and_drains")

        try await readCallbackCannotScheduleWrite()
        passed.append("modal_read_callback_cannot_schedule_write_and_latches")

        try await parentBeforeChildOrdering()
        passed.append("modal_parent_add_precedes_child_write_and_publication")

        try await childCannotReenterPassiveParent()
        passed.append("modal_child_cannot_reenter_passive_parent_and_latches")

        try await missingListPermissionBlocksReservation()
        passed.append("modal_missing_list_permission_blocks_reservation_and_capture")

        try await reservedSourceRetirementBlocksBody()
        passed.append("modal_reserved_source_retirement_blocks_body_and_revival")

        try await preparedPermitRejectsRetiredSource()
        passed.append("modal_prepared_permit_rejects_retired_source_before_effect")

        try await changedAccountSuppressesReadPublication()
        passed.append("modal_account_change_during_read_suppresses_publication")

        return passed
    }

    private static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw ModalOwnerControlFailure(description: message) }
    }

    private static func expect(
        _ expected: EditorDocumentWriteError,
        _ label: String,
        operation: @MainActor () async throws -> Void
    ) async throws {
        var observed: Error?
        do { try await operation() } catch { observed = error }
        guard let observed else {
            throw ModalOwnerControlFailure(description: "\(label): expected \(expected), received success")
        }
        try require(observed as? EditorDocumentWriteError == expected,
                    "\(label): expected \(expected), received \(observed)")
    }

    private static func runPrepared(
        _ action: @escaping @MainActor @Sendable () async throws -> Void
    ) async throws {
        // The reservation has already been inspected before this Task exists.
        let task = Task { @MainActor in try await action() }
        try await task.value
    }

    private static func effect(
        messageName: String, label: String, effects: ModalOwnerEffects
    ) async throws {
        guard let binding = InvocationDispatchContext.binding else {
            throw ModalOwnerControlFailure(description: "\(label): missing actual dispatch binding")
        }
        let permit = try await binding.prepare(messageName: messageName)
        let completion = try permit.begin()
        defer { completion.finish() }
        effects.append(label)
    }

    private static func captureSucceeds(
        _ fixture: ModalOwnerFixture, effects: ModalOwnerEffects
    ) async throws {
        let value = try await fixture.owner.withExclusiveRead(
            contextId: fixture.document.objectId, spaceId: fixture.document.spaceId,
            rpcNames: ["ObjectListExport"]
        ) { @MainActor in
            try await effect(messageName: "ObjectListExport", label: "capture:ObjectListExport", effects: effects)
            return "explicit-export-effect-probe"
        }
        try require(value == "explicit-export-effect-probe" && fixture.owner.isDrained,
                    "valid modal operation did not drain through the actual exclusive-read boundary")
    }

    private static func captureRejects(
        _ fixture: ModalOwnerFixture, expected: EditorDocumentWriteError, effects: ModalOwnerEffects
    ) async throws {
        let prior = effects.values
        try await expect(expected, "exclusive read after rejected modal write") {
            try await captureSucceeds(fixture, effects: effects)
        }
        try require(effects.values == prior, "rejected capture entered its effect body")
        try require(fixture.owner.isDrained, "rejected modal operation retained a phantom pending write")
    }

    private static func actionCallbackReservesBeforeTask() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let prepared = try fixture.scope.withActionCallback(
            requiredPermissions: OriginalEditorPropertyScope.listPermissions
        ) {
            fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                try await effect(messageName: "ObjectRelationAdd", label: "parent:registered-add", effects: effects)
            }
        }
        try require(fixture.owner.pendingOperationCount == 1 && effects.values.isEmpty,
                    "actual callback did not reserve exactly its pending action before Task creation")
        try await runPrepared(prepared)
        try await captureSucceeds(fixture, effects: effects)
        try require(effects.values == ["parent:registered-add", "capture:ObjectListExport"],
                    "registered action or subsequent capture effect order changed")
    }

    private static func readCallbackCannotScheduleWrite() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let prepared = try fixture.scope.withCurrent {
            fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                try await effect(messageName: "ObjectRelationAdd", label: "forbidden:read-upgrade", effects: effects)
            }
        }
        try require(fixture.owner.isDrained, "read-to-write rejection created a pending mutation")
        try await expect(.rejected(.unqualifiedDispatch), "read callback mutation reservation") {
            try await runPrepared(prepared)
        }
        try require(effects.values.isEmpty, "read callback silently acquired mutation authority")
        try await captureRejects(fixture, expected: .rejected(.failedWrite), effects: effects)
    }

    private static func parentBeforeChildOrdering() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let prepared = fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
            let child = try fixture.child()
            defer { child.owner.retire() }
            try await effect(messageName: "ObjectRelationAdd", label: "parent:add", effects: effects)
            try await child.owner.performDocumentAction(
                contextId: child.document.objectId, requiredPermissions: [.editDetails]
            ) { @MainActor in
                try await effect(messageName: "ObjectSetDetails", label: "child:last-used", effects: effects)
            }
            try fixture.scope.withCurrent { effects.append("parent:publish") }
        }
        try require(fixture.owner.pendingOperationCount == 1 && effects.values.isEmpty,
                    "parent/child flow was not reserved before its Task")
        try await runPrepared(prepared)
        try await captureSucceeds(fixture, effects: effects)
        try require(effects.values == ["parent:add", "child:last-used", "parent:publish", "capture:ObjectListExport"],
                    "parent add, selected-child write and original-parent publication did not preserve order")
    }

    private static func childCannotReenterPassiveParent() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let prepared = fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
            let child = try fixture.child()
            defer { child.owner.retire() }
            try await child.owner.performDocumentAction(
                contextId: child.document.objectId, requiredPermissions: [.editDetails]
            ) { @MainActor in
                try fixture.scope.withCurrent { effects.append("forbidden:passive-parent-reentry") }
                try await effect(messageName: "ObjectSetDetails", label: "forbidden:child-after-reentry", effects: effects)
            }
        }
        try await expect(.rejected(.unqualifiedDispatch), "child reentry into passive parent") {
            try await runPrepared(prepared)
        }
        try require(effects.values.isEmpty, "passive parent admitted a callback from its child lease")
        try await captureRejects(fixture, expected: .rejected(.failedWrite), effects: effects)
    }

    private static func missingListPermissionBlocksReservation() async throws {
        let fixture = try ModalOwnerFixture(permitsList: false)
        let effects = ModalOwnerEffects()
        let prepared = fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
            try await effect(messageName: "ObjectRelationAdd", label: "forbidden:missing-list-permission", effects: effects)
        }
        try require(fixture.owner.isDrained, "missing list permission still admitted a scheduled write")
        try await expect(.rejected(.notEditable), "named list permission reservation") {
            try await runPrepared(prepared)
        }
        try require(effects.values.isEmpty, "missing list permission reached the actual permit effect")
        try await captureRejects(fixture, expected: .rejected(.failedWrite), effects: effects)
    }

    private static func reservedSourceRetirementBlocksBody() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let prepared = fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
            effects.append("forbidden:retired-body-entered")
            try await effect(messageName: "ObjectRelationAdd", label: "forbidden:retired-effect", effects: effects)
        }
        try require(fixture.owner.pendingOperationCount == 1, "source retirement control has no prior reservation")
        fixture.sourceLifetime.markUnavailable()
        fixture.sourceLifetime.confirmOpened()
        try await expect(.rejected(.retired), "source replaced after reservation") {
            try await runPrepared(prepared)
        }
        try require(effects.values.isEmpty && fixture.owner.isRetired,
                    "restored availability revived the old source or entered its scheduled body")
        try await captureRejects(fixture, expected: .rejected(.retired), effects: effects)
    }

    private static func preparedPermitRejectsRetiredSource() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let prepared = fixture.scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
            guard let binding = InvocationDispatchContext.binding else {
                throw ModalOwnerControlFailure(description: "queued-permit control has no actual binding")
            }
            let permit = try await binding.prepare(messageName: "ObjectRelationAdd")
            fixture.sourceLifetime.markUnavailable()
            fixture.sourceLifetime.confirmOpened()
            let completion = try permit.begin()
            defer { completion.finish() }
            effects.append("forbidden:queued-permit-effect")
        }
        try await expect(.rejected(.retired), "source replaced between permit preparation and begin") {
            try await runPrepared(prepared)
        }
        try require(effects.values.isEmpty, "a prepared permit bypassed its frozen source at actual begin")
        try await captureRejects(fixture, expected: .rejected(.retired), effects: effects)
    }

    private static func changedAccountSuppressesReadPublication() async throws {
        let fixture = try ModalOwnerFixture()
        let effects = ModalOwnerEffects()
        let gate = ModalOwnerReadGate()
        guard let capturedAccount = fixture.accountLifetime.token() else {
            throw ModalOwnerControlFailure(description: "fresh account-generation input is unavailable")
        }
        let task = Task { @MainActor () async throws -> String in
            do {
                let value = try await fixture.owner.performRead(
                    contextId: fixture.document.objectId, spaceId: fixture.document.spaceId,
                    rpcNames: ["ObjectShow"]
                ) { @MainActor in
                    guard let binding = InvocationDispatchContext.binding else {
                        throw ModalOwnerControlFailure(description: "held read has no actual dispatch binding")
                    }
                    let permit = try await binding.prepare(messageName: "ObjectShow")
                    let completion = try permit.begin()
                    defer { completion.finish() }
                    effects.append("read:ObjectShow:begin")
                    gate.signalBegan()
                    await gate.waitForRelease()
                    effects.append("read:ObjectShow:complete")
                    return "explicit-read-result"
                }
                try fixture.scope.withCurrent { effects.append("forbidden:stale-read-publication") }
                return value
            } catch {
                gate.signalFailureBeforeBegan(error)
                throw error
            }
        }
        defer { gate.release(); task.cancel() }
        try await gate.waitUntilBegan()
        try require(effects.values == ["read:ObjectShow:begin"] && !fixture.owner.isDrained,
                    "read was not actually admitted and held before account replacement")
        fixture.accountLifetime.markUnavailable()
        fixture.accountLifetime.confirmOpened()
        try require(!fixture.accountLifetime.isCurrent(capturedAccount) && fixture.accountLifetime.token() != nil,
                    "account replacement did not create available-but-different generation input")
        gate.release()
        try await expect(.completedWithoutOwnership(.retired), "account replaced while actual read awaited") {
            _ = try await task.value
        }
        try require(effects.values == ["read:ObjectShow:begin", "read:ObjectShow:complete"],
                    "stale account read published success or lost its original completion")
        try require(fixture.owner.isDrained && fixture.owner.isRetired,
                    "completed stale read did not drain while preserving retirement")
    }
}
