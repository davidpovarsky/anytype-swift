import Foundation

public struct PinkhaInternalPropertyIdentities: Equatable, Sendable {
    public let canonicalPropertyId: String
    public let canonicalPropertyKey: String
    public let orderPropertyId: String
    public let orderPropertyKey: String

    public init(
        canonicalPropertyId: String,
        canonicalPropertyKey: String,
        orderPropertyId: String = "",
        orderPropertyKey: String = ""
    ) {
        self.canonicalPropertyId = canonicalPropertyId
        self.canonicalPropertyKey = canonicalPropertyKey
        self.orderPropertyId = orderPropertyId
        self.orderPropertyKey = orderPropertyKey
    }

    public init?(manifest: PinkhaSpaceManifest) {
        let cId = manifest.documentAssociationsPropertyId.trimmingCharacters(in: .whitespacesAndNewlines)
        let cKey = manifest.documentAssociationsPropertyKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let oId = manifest.orderPropertyId.trimmingCharacters(in: .whitespacesAndNewlines)
        let oKey = manifest.orderPropertyKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cId.isEmpty || !cKey.isEmpty || !oId.isEmpty || !oKey.isEmpty else {
            return nil
        }
        self.init(
            canonicalPropertyId: cId,
            canonicalPropertyKey: cKey,
            orderPropertyId: oId,
            orderPropertyKey: oKey
        )
    }

    public func isCanonical(propertyId: String, key: String) -> Bool {
        (!canonicalPropertyId.isEmpty && propertyId == canonicalPropertyId) ||
        (!canonicalPropertyKey.isEmpty && key == canonicalPropertyKey)
    }

    public func isOrder(propertyId: String, key: String) -> Bool {
        (!orderPropertyId.isEmpty && propertyId == orderPropertyId) ||
        (!orderPropertyKey.isEmpty && key == orderPropertyKey)
    }

    public func isInternal(propertyId: String, key: String) -> Bool {
        isCanonical(propertyId: propertyId, key: key) || isOrder(propertyId: propertyId, key: key)
    }
}

