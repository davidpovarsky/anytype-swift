import Foundation

@main
private struct PropertyModalControlMain {
    @MainActor static func main() async throws {
        let canonical = try await CanonicalModalControls.run()
        let owner = try await OwnerModalControls.run()
        let passed = canonical + owner
        let expected = CanonicalModalControls.expectedIDs + OwnerModalControls.expectedIDs
        guard passed == expected, Set(passed).count == passed.count else {
            throw NSError(domain: "PropertyModalControls", code: 1)
        }
        let report: [String: Any] = [
            "status": "PASS_NEW_PORTABLE_PROPERTY_MODAL_CONTROLS",
            "passed": passed, "expected": expected, "executed": passed.count,
            "failed": 0, "skipped": 0,
            "modal_patch_sha256": "377ef209aa567db9f95728f54be101726befea96b2e2cc36b28d0ca3a8bb729d",
            "combined_patch_sha256": "90605b0cb2576c87c3102729ef4784733fc4e24989045acd756b3b9d1f6d5a25",
            "prior_suites_rerun": false,
            "apple_typecheck": "NOT_RUN_BY_THIS_EXECUTABLE",
            "native_editor": "NOT_RUN",
            "canonical_network_read": "NOT_RUN",
            "native_mutation_dispatch": "NOT_RUN_DISPOSABLE_EFFECT_ONLY"
        ]
        let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    }
}
