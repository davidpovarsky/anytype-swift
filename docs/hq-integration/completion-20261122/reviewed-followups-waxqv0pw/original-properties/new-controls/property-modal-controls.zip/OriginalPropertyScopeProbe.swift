import Foundation

// Portable envelope only: the real owner and explicit document input are
// supplied directly. No PreparedSession, Factory, service or acquisition is
// implemented. Every copied production body below is byte-verified by region.
@MainActor
final class OriginalEditorPropertyScope {
    static let valuePermissions: Set<EditorDocumentWritePermission> = [.editDetails, .editRelationValues]
    static let listPermissions: Set<EditorDocumentWritePermission> = [.editDetails, .editPropertiesList]

    let owner: EditorDocumentWriteOwner
    let objectId: String
    let spaceId: String
    private let document: any BaseDocumentProtocol

    init(owner: EditorDocumentWriteOwner, objectId: String, spaceId: String,
         document: any BaseDocumentProtocol) {
        self.owner = owner
        self.objectId = objectId
        self.spaceId = spaceId
        self.document = document
    }

    func withCurrent<Value>(
        requiredPermissions: Set<EditorDocumentWritePermission> = [],
        _ operation: () throws -> Value
    ) throws -> Value {
        try owner.performSynchronousOperation(
            contextId: objectId, spaceId: spaceId, requiresEditing: false,
            requiredPermissions: requiredPermissions
        ) {
            try owner.validateDocument(document)
            return try operation()
        }
    }

    func withActionCallback<Value>(
        requiredPermissions: Set<EditorDocumentWritePermission> = OriginalEditorPropertyScope.valuePermissions,
        _ operation: () throws -> Value
    ) throws -> Value {
        try owner.performSynchronousDocumentAction(
            contextId: objectId, spaceId: spaceId, requiredPermissions: requiredPermissions
        ) {
            try owner.validateDocument(document)
            return try operation()
        }
    }

    func prepareAction(
        requiredPermissions: Set<EditorDocumentWritePermission> = OriginalEditorPropertyScope.valuePermissions,
        operation: @escaping @MainActor @Sendable () async throws -> Void
    ) -> @MainActor @Sendable () async throws -> Void {
        do {
            let scheduled = try owner.scheduleDocumentAction(
                contextId: objectId, requiredPermissions: requiredPermissions
            )
            // If identity/Space validation fails after reservation, dropping
            // this original one-use handle records the abandoned write.
            try withCurrent {}
            return { try await scheduled.run(operation: operation) }
        } catch { return { throw error } }
    }


    // Test-only signature supplies the actual canonical read's decoded result.
    // The following return block is exactly the production post-await block.
    func probeValidateCanonicalResult(
        _ manifest: PinkhaSpaceManifest?, enabled: Bool = PinkhaRuntime.enabled
    ) throws -> OriginalEditorPropertyIdentitySnapshot {
        return try withCurrent {
            guard PinkhaRuntime.enabled == enabled, let manifest,
                  manifest.spaceId.utf8.elementsEqual(spaceId.utf8), manifest.isComplete,
                  manifest.schemaVersion == PinkhaSpaceManifest.currentSchemaVersion,
                  let manifestId = manifest.manifestObjectId, !manifestId.isEmpty, !manifestId.utf8.contains(0),
                  let identities = PinkhaInternalPropertyIdentities(manifest: manifest),
                  identities.canonicalPropertyId.utf8.elementsEqual(manifest.documentAssociationsPropertyId.utf8),
                  identities.canonicalPropertyKey.utf8.elementsEqual(manifest.documentAssociationsPropertyKey.utf8),
                  identities.orderPropertyId.utf8.elementsEqual(manifest.orderPropertyId.utf8),
                  identities.orderPropertyKey.utf8.elementsEqual(manifest.orderPropertyKey.utf8),
                  [identities.canonicalPropertyId, identities.canonicalPropertyKey,
                   identities.orderPropertyId, identities.orderPropertyKey].allSatisfy({ !$0.isEmpty && !$0.utf8.contains(0) }) else {
                throw OriginalEditorPropertyModalError.internalIdentityUnavailable
            }
            return .init(scope: self, spaceId: spaceId, pinkhaEnabled: enabled, internalIdentities: identities)
        }
    }

    private func requireModalIdentity(_ identity: OriginalEditorPropertyIdentitySnapshot) throws {
        guard identity.scope === self, identity.spaceId.utf8.elementsEqual(spaceId.utf8),
              identity.pinkhaEnabled == PinkhaRuntime.enabled else {
            throw OriginalEditorPropertyModalError.invalidPropertyIdentity
        }
    }


    // Test visibility only, preserving the original private guard unchanged.
    func probeRequireIdentity(_ identity: OriginalEditorPropertyIdentitySnapshot) throws {
        try withCurrent { try requireModalIdentity(identity) }
    }

    func probeInternalIdentities(_ identity: OriginalEditorPropertyIdentitySnapshot) throws -> PinkhaInternalPropertyIdentities? {
        try withCurrent {
            try requireModalIdentity(identity)
            return identity.internalIdentities
        }
    }
}

enum OriginalEditorPropertyModalError: Error, Sendable {
    case unsupportedTarget
    case internalIdentityUnavailable
    case invalidPropertyIdentity
    case unsupportedOriginalDelegate
}

struct OriginalEditorPropertyIdentitySnapshot: Sendable {
    fileprivate let scope: OriginalEditorPropertyScope
    fileprivate let spaceId: String
    fileprivate let pinkhaEnabled: Bool
    fileprivate let internalIdentities: PinkhaInternalPropertyIdentities?
}

