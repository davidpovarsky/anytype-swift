public protocol BlockTableServiceProtocol: Sendable {
    func createTable(
        contextId: String,
        targetId: String,
        position: BlockPosition,
        rowsCount: Int,
        columnsCount: Int
    ) async throws -> String

    func rowListFill(
        contextId: String,
        targetIds: [String]
    ) async throws


    func insertColumn(contextId: String, targetId: String, position: BlockPosition) async throws
    func deleteColumn(contextId: String, targetId: String) async throws
    func columnDuplicate(contextId: String, targetId: String) async throws
    func columnSort(contextId: String, columnId: String, blocksSortType: BlocksSortType) async throws
    func columnMove(contextId: String, targetId: String, dropTargetID: String, position: BlockPosition) async throws

    func insertRow(contextId: String, targetId: String, position: BlockPosition) async throws
    func deleteRow(contextId: String, targetId: String) async throws
    func rowDuplicate(contextId: String, targetId: String) async throws
    func rowMove(contextId: String, targetId: String, dropTargetID: String, position: BlockPosition) async throws

    func clearContents(contextId: String, blockIds: [String]) async throws
    func clearStyle(contextId: String, blocksIds: [String]) async throws
}
