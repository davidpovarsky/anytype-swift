
enum BaseDocumentUpdate: Hashable {
    // From DocumentUpdate
    case general
    case block(blockId: String)
    case children
    case details(id: String)
    case unhandled(blockId: String)
    // Local State
    case relations
    case permissions
    case syncStatus
}
