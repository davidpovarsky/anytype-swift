
@MainActor final class EditorPageController {}
@MainActor protocol EditorPageModuleOutput: AnyObject {}
@MainActor final class TorahEditorSession {}
@MainActor final class EditorPageViewState {
    let viewController = EditorPageController()
    private(set) var preparedSession: PreparedEditorPageSession?
    @MainActor
    func bindPreparedSession(_ session: PreparedEditorPageSession) throws {
        guard preparedSession == nil else {
            throw EditorDocumentWriteError.rejected(.invalidLease)
        }
        try session.bind(controller: viewController)
        preparedSession = session
    }
}
@MainActor final class FixturePreparedAssembly {
    var data: EditorPageObject?
    var document: (any BaseDocumentProtocol)?
    var duringBuild: (@MainActor () -> Void)?
    func buildStateModel(data: EditorPageObject, preparedDocument: any BaseDocumentProtocol,
        services: EditorPageServiceDependencies, output: (any EditorPageModuleOutput)?,
        showHeader: Bool, torahSession: TorahEditorSession?) throws -> EditorPageViewState {
        self.data = data
        self.document = preparedDocument
        duringBuild?()
        return EditorPageViewState()
    }
    func buildStateModel(
        preparedSession: PreparedEditorPageSession,
        output: (any EditorPageModuleOutput)?,
        showHeader: Bool,
        torahSession: TorahEditorSession?
    ) throws -> EditorPageViewState {
        do {
            try preparedSession.claimAssembly()
            let state = try buildStateModel(
                data: preparedSession.data,
                preparedDocument: preparedSession.document,
                services: preparedSession.services,
                output: output,
                showHeader: showHeader,
                torahSession: torahSession
            )
            try state.bindPreparedSession(preparedSession)
            return state
        } catch {
            preparedSession.retire()
            throw error
        }
    }
}
@MainActor struct FixturePreparedContainer {
    let viewController: EditorPageController
    var preparedSession: PreparedEditorPageSession? = nil
    @MainActor
    final class Coordinator {
        let controller: EditorPageController
        let session: PreparedEditorPageSession?
        let hostLease: EditorDocumentWriteLifetime.Observation?

        init(controller: EditorPageController, session: PreparedEditorPageSession?) {
            self.controller = controller
            self.session = session
            do {
                self.hostLease = try session?.attachHost(controller: controller)
            } catch {
                session?.retire()
                self.hostLease = nil
            }
        }
    }
    func makeCoordinator() -> Coordinator {
        Coordinator(controller: viewController, session: preparedSession)
    }
    static func dismantleUIViewController(_ uiViewController: EditorPageController, coordinator: Coordinator) {
        guard coordinator.controller === uiViewController else { return }
        coordinator.hostLease?.cancel()
        coordinator.session?.retire(controller: uiViewController)
    }
}
