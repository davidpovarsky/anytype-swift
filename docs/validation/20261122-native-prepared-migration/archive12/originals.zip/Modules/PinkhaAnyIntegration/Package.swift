// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "PinkhaAnyIntegration",
    platforms: [.iOS(.v18), .macOS(.v14)],
    products: [.library(name: "PinkhaAnyIntegration", targets: ["PinkhaAnyIntegration"]),
               .executable(name: "pinkha-any-integration-probe", targets: ["PinkhaAnyIntegrationProbe"])],
    dependencies: [
        .package(path: "C:/Users/DAVID/AppData/Local/Temp/pinkha-history-components-j1o7h7i6/Modules/PinkhaAnyEngine"),
        .package(path: "C:/Users/DAVID/AppData/Local/Temp/pinkha-history-components-j1o7h7i6/Modules/PinkhaKit")
    ],
    targets: [
        .target(name: "PinkhaAnyIntegration", dependencies: ["PinkhaAnyEngine", "PinkhaKit"]),
        .testTarget(name: "PinkhaAnyIntegrationTests", dependencies: ["PinkhaAnyIntegration"]),
        .executableTarget(name: "PinkhaAnyIntegrationProbe", dependencies: ["PinkhaAnyIntegration"])
    ]
)
