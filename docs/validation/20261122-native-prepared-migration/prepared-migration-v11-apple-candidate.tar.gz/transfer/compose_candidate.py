from pathlib import Path
import base64, gzip, hashlib, io, json, os, subprocess, tarfile

root = Path(r'C:\Users\DAVID\Code\any-pinkha-migration-apple-candidate-20261122')
packet_bytes = b''.join((root/'transfer'/f'composition-packet.part{i}.base64').read_bytes() for i in range(1, 9))
packet = json.loads(gzip.decompress(base64.b64decode(packet_bytes, validate=True)))
assert packet['contract'] == 'prepared-migration-candidate-composition-v1'
inputs = root/'inputs'; inputs.mkdir(exist_ok=True)
output = root/'output'; output.mkdir(exist_ok=True)
origins = {
    'any': Path(r'C:\Users\DAVID\Code\any-pinkha-runtime-authorized-read-candidate-20261121'),
    'sdk': Path(r'C:\Users\DAVID\Code\any-pinkha-runtime-authorized-read-candidate-20261121\.runtime-artifacts\sdk-source'),
}
repos = {'any': root/'any', 'sdk': root/'any'/'.runtime-artifacts'/'sdk-source'}

def run(args, timeout=120):
    p = subprocess.run(args, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError(json.dumps({'args':args,'code':p.returncode,'stdout':p.stdout.decode('utf-8',errors='replace')[-3000:],'stderr':p.stderr.decode('utf-8',errors='replace')[-3000:]}))
    return p.stdout

def git(repo, *args):
    return run(['git','-C',str(repo),*args])

def inventory(directory, section):
    values = {}
    for parent, dirs, files in os.walk(directory):
        dirs[:] = sorted(d for d in dirs if d not in ('.git','node_modules','.build') and not(section == 'any' and d == '.runtime-artifacts'))
        for name in sorted(files):
            if name.endswith('.go') or name in ('go.mod','go.sum'):
                p = Path(parent)/name
                values[p.relative_to(directory).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return values

result = {'schemaVersion':1,'nativeVersion':'v0.5.0-pinkha.prepared.1','packetSHA256':hashlib.sha256(packet_bytes).hexdigest(),'fileCapability':0,'networkVerified':False,'sections':{}}
for section in ('any','sdk'):
    repo = repos[section]
    assert not repo.exists(), 'candidate checkout already exists: '+str(repo)
    repo.parent.mkdir(parents=True, exist_ok=True)
    run(['git','clone','--quiet','--no-hardlinks','--no-checkout',str(origins[section]),str(repo)], timeout=240)
    git(repo,'config','core.autocrlf','false')
    git(repo,'config','core.eol','lf')
    base = packet['upstream'][section]
    git(repo,'checkout','--quiet','--detach',base)
    assert git(repo,'rev-parse','HEAD').decode().strip() == base
    assert not git(repo,'diff','--name-only','HEAD').strip()
    layers = sorted((x for x in packet['layers'] if x['section'] == section), key=lambda x:x['order'])
    for layer in layers:
        data = base64.b64decode(layer['base64'], validate=True)
        assert hashlib.sha256(data).hexdigest() == layer['sha256'], layer['name']
        patch = inputs/layer['name']; patch.write_bytes(data)
        git(repo,'apply','--check','--index',str(patch))
        git(repo,'apply','--index',str(patch))
    expected = {x['path']:x for x in packet['expected'][section]}
    changed = git(repo,'diff','--cached','--name-only','--no-renames','HEAD').decode().splitlines()
    assert set(changed) == set(expected), json.dumps({'section':section,'unexpected':sorted(set(changed)-set(expected)),'missing':sorted(set(expected)-set(changed))})
    rows = []
    for path in sorted(changed):
        data = (repo/path).read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        blob = git(repo,'hash-object','--path='+path,path).decode().strip()
        assert digest == expected[path]['sha256'], (section,path,'native SHA differs',digest,expected[path]['sha256'])
        assert blob == expected[path]['gitBlob'], (section,path,'Git blob differs')
        rows.append({'path':path,'gitBlob':blob,'worktreeSHA256':digest,'bytes':len(data),'origin':expected[path].get('origin','retained exact source')})
    actual_inventory = inventory(repo,section)
    expected_inventory = packet['inventories'][section]['after']
    differences = {'missing':sorted(set(expected_inventory)-set(actual_inventory)),'extra':sorted(set(actual_inventory)-set(expected_inventory)),'changed':sorted(p for p in set(actual_inventory)&set(expected_inventory) if actual_inventory[p] != expected_inventory[p])}
    assert not any(differences.values()), json.dumps({'section':section,'nativeInventoryMismatch':differences})
    patch_name = f'native-prepared-migration-v11-candidate-{section}.patch'
    patch_data = git(repo,'diff','--cached','--binary','--full-index','HEAD')
    (output/patch_name).write_bytes(patch_data)
    tree = git(repo,'write-tree').decode().strip()
    record = {'upstreamCommit':base,'testedLocalCommit':base,'testedEffectiveTree':tree,'testedWorkingTreeIncludesUncommittedChanges':True,'testedWorkingTreeRevision':'v11-prepared-object-block-inline-native-candidate','patch':patch_name,'patchSHA256':hashlib.sha256(patch_data).hexdigest(),'patchBytes':len(patch_data),'files':rows,'nativeGoModuleInventoryFiles':len(actual_inventory),'nativeGoModuleInventorySHA256':hashlib.sha256(json.dumps(actual_inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'exactNativeSourceInventoryMatched':True,'layers':[{k:v for k,v in layer.items() if k != 'base64'} for layer in layers]}
    if section == 'sdk':
        tag = git(repo,'rev-parse','refs/tags/v0.8.0').decode().strip()
        assert tag == 'b161a0475479bbe7d9d693bc496c6fdd90c3969b', tag
        record.update(upstreamTag='v0.8.0',upstreamTagObject=tag)
    result['sections'][section] = record
    (output/f'composition-{section}-source.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'section':section,'files':len(rows),'nativeInventoryFiles':len(actual_inventory),'effectiveTree':tree,'patchSHA256':record['patchSHA256']}),flush=True)

(output/'composition-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for name in sorted(output.iterdir()):
        archive.add(name,arcname=name.name)
data = buffer.getvalue(); (root/'native-prepared-candidate-composition.tar.gz').write_bytes(data)
encoded = base64.b64encode(data).decode(); parts=[]
for i,start in enumerate(range(0,len(encoded),60000),1):
    part=encoded[start:start+60000]; name=f'composition-output.part{i}.base64'
    (root/name).write_text(part,encoding='ascii');parts.append({'name':name,'bytes':len(part),'sha256':hashlib.sha256(part.encode()).hexdigest()})
report={'archiveBytes':len(data),'archiveSHA256':hashlib.sha256(data).hexdigest(),'parts':parts,'sections':{s:{k:v for k,v in value.items() if k not in ('files','layers')} for s,value in result['sections'].items()}}
(root/'composition-output-manifest.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(report),flush=True)
