package spaceimpl

import (
	"context"
	"encoding/json"
	"errors"
	"slices"

	"github.com/anyproto/any-sync-sdk/internal/migrationintent"
	"github.com/anyproto/any-sync-sdk/space"
)

var _ space.PreparedInlineFileService = (*filesAPI)(nil)

func inlineFileReceipt(e *migrationintent.InlineFile, stage, outcome string) space.MigrationInlineFileReceipt {
	return space.MigrationInlineFileReceipt{MigrationReceipt: receipt(&e.Prepared, stage, outcome), OwnerObjectID: e.OwnerObjectID, FileID: e.RecordIDs[0], ContentSHA256: e.ContentSHA256, Size: e.Size}
}

func (f *filesAPI) PrepareMigrationInlineFile(ctx context.Context, input space.MigrationInput, requested space.MigrationInlineFileSpec) (space.MigrationInlineFileReceipt, error) {
	// Size/hash/schema bounds precede native ledger open and DAG preparation.
	spec := migrationintent.InlineFileSpec{OwnerObjectID: requested.OwnerObjectID, Name: requested.Name, Mime: requested.Mime, Content: slices.Clone(requested.Content), ContentSHA256: requested.ContentSHA256}
	if err := spec.Validate(); err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	if input.Contract != migrationintent.Contract || input.SpecSHA256 != migrationintent.Digest(input.SourceSpec) {
		return space.MigrationInlineFileReceipt{}, migrationintent.ErrScope
	}
	unlock := f.s.store.LockMigration()
	defer unlock()
	journal, err := f.s.store.MigrationJournal(ctx)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	id := journal.Identity()
	binding := migrationintent.Binding{StoreID: input.StoreID, AccountID: id.AccountID, SpaceID: id.SpaceID, PlanID: input.PlanID, PlanSHA256: input.PlanSHA256, IntentID: input.IntentID, SourceKey: input.SourceKey}
	nativeSpec, err := json.Marshal(spec)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	fp, err := journal.InlineFileFingerprint(binding, nativeSpec, input.SourceSpec)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	if old, err := journal.LoadInlineFile(ctx, input.IntentID); err == nil {
		if old.Binding != binding || old.Fingerprint != fp {
			return space.MigrationInlineFileReceipt{}, migrationintent.ErrCollision
		}
		stage, outcome, err := f.s.store.MigrationInlineFileState(ctx, old, false)
		return inlineFileReceipt(old, stage, outcome), err
	} else if !errors.Is(err, migrationintent.ErrNotFound) {
		return space.MigrationInlineFileReceipt{}, err
	}
	e := &migrationintent.InlineFile{Prepared: migrationintent.Prepared{Binding: binding, Fingerprint: fp, Kind: migrationintent.InlineFileKind, Stage: "inline-file", Spec: nativeSpec, SourceSpec: slices.Clone(input.SourceSpec), SpecSHA256: input.SpecSHA256}}
	e, err = f.s.store.PrepareMigrationInlineFile(ctx, journal, e, spec)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	stage, outcome, err := f.s.store.MigrationInlineFileState(ctx, e, false)
	return inlineFileReceipt(e, stage, outcome), err
}

func (f *filesAPI) MigrationInlineFileStatus(ctx context.Context, intentID string) (space.MigrationInlineFileReceipt, error) {
	unlock := f.s.store.LockMigration()
	defer unlock()
	journal, err := f.s.store.MigrationJournal(ctx)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	e, err := journal.LoadInlineFile(ctx, intentID)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	stage, outcome, err := f.s.store.MigrationInlineFileState(ctx, e, false)
	return inlineFileReceipt(e, stage, outcome), err
}

func (f *filesAPI) CommitMigrationInlineFile(ctx context.Context, input space.MigrationCommit) (space.MigrationInlineFileReceipt, error) {
	unlock := f.s.store.LockMigration()
	defer unlock()
	journal, err := f.s.store.MigrationJournal(ctx)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	e, err := journal.LoadInlineFile(ctx, input.IntentID)
	if err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	if input.Contract != migrationintent.Contract || input.StoreID != e.Binding.StoreID || input.PlanID != e.Binding.PlanID || input.PlanSHA256 != e.Binding.PlanSHA256 || input.Fingerprint != e.Fingerprint {
		return space.MigrationInlineFileReceipt{}, migrationintent.ErrCollision
	}
	if err = journal.EnsureDurable(ctx); err != nil {
		return space.MigrationInlineFileReceipt{}, err
	}
	stage, outcome, err := f.s.store.MigrationInlineFileState(ctx, e, true)
	return inlineFileReceipt(e, stage, outcome), err
}
