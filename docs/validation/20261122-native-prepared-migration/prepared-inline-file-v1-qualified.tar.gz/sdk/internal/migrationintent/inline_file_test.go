package migrationintent

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	anystore "github.com/anyproto/any-store/v2"
	"github.com/stretchr/testify/require"
)

// These are ledger-only opaque envelopes; actual signed native bytes are
// independently exercised by commitguard and the production SDK fixture.
func inlineEntry(t *testing.T, s *Store, suffix string) *InlineFile {
	t.Helper()
	base := entryFor(t, s, "signed row "+suffix)
	spec := InlineFileSpec{OwnerObjectID: "owner", Name: "source.txt", Mime: "text/plain", Content: []byte("durable inline bytes"), ContentSHA256: Digest([]byte("durable inline bytes"))}
	base.Spec, _ = json.Marshal(spec)
	base.SourceSpec = bytes.Clone(base.Spec)
	base.SpecSHA256 = Digest(base.SourceSpec)
	base.Kind, base.Stage, base.ObjectID, base.ChangeID = InlineFileKind, inlineFileStage, "payload-root", "row-change"
	base.Payload, base.Timestamp, base.RecordIDs = []byte("sealed native row"), 1, []string{"file-id"}
	base.Dependencies = map[string][]string{"owner": {"owner-head"}, "payload-root": {"payload-root"}}
	base.Fingerprint, _ = s.InlineFileFingerprint(base.Binding, base.Spec, base.SourceSpec)
	return &InlineFile{Prepared: *base, RootRaw: []byte("native derived root " + suffix), OwnerObjectID: "owner", ReadKeyID: "read-key", ACLHeadID: "acl-head", ContentSHA256: spec.ContentSHA256, Size: int64(len(spec.Content))}
}

func TestPreparedInlineLedgerConcurrentRootRowReservationAndRestart(t *testing.T) {
	ctx := context.Background()
	path := filepath.Join(t.TempDir(), "projection.db")
	db, s := openTestStore(t, path)
	var wg sync.WaitGroup
	results := make(chan *InlineFile, 8)
	errs := make(chan error, 8)
	for i := range 8 {
		e := inlineEntry(t, s, string(rune('a'+i)))
		wg.Add(1)
		go func() { defer wg.Done(); got, err := s.ReserveInlineFile(ctx, e); results <- got; errs <- err }()
	}
	wg.Wait()
	close(results)
	close(errs)
	for err := range errs {
		if err != nil {
			require.ErrorIs(t, err, anystore.ErrBusy)
		}
	}
	var first *InlineFile
	for got := range results {
		if got != nil {
			if first != nil {
				require.Equal(t, first, got)
			}
			first = got
		}
	}
	selected, err := s.ReserveInlineFile(ctx, inlineEntry(t, s, "late loser"))
	require.NoError(t, err)
	if first != nil {
		require.Equal(t, first, selected)
	}
	require.NoError(t, db.Close())
	db, reopened := openTestStore(t, path)
	defer db.Close()
	recovered, err := reopened.ReserveInlineFile(ctx, inlineEntry(t, reopened, "after restart loser"))
	require.NoError(t, err)
	require.Equal(t, selected, recovered, "root and row must be recovered as one exact immutable preparation")
}

func TestPreparedInlineLedgerCrossKindIntentAndStageIsolation(t *testing.T) {
	for _, originalKind := range []string{"object", "editorBlock", InlineFileKind} {
		t.Run(originalKind, func(t *testing.T) {
			db, s := openTestStore(t, filepath.Join(t.TempDir(), "projection.db"))
			defer db.Close()
			ctx := context.Background()
			file := inlineEntry(t, s, "first")
			ordinary := entryFor(t, s, "ordinary")
			if originalKind == "editorBlock" {
				ordinary.Kind, ordinary.Stage = "editorBlock", "block"
				ordinary.Fingerprint, _ = s.Fingerprint(ordinary.Binding, ordinary.Kind, ordinary.Spec, ordinary.SourceSpec)
			}
			if originalKind == InlineFileKind {
				_, err := s.ReserveInlineFile(ctx, file)
				require.NoError(t, err)
				_, err = s.Reserve(ctx, ordinary)
				require.ErrorIs(t, err, ErrCollision)
				_, err = s.Load(ctx, file.Binding.IntentID, "root")
				require.ErrorIs(t, err, ErrNotFound)
			} else {
				_, err := s.Reserve(ctx, ordinary)
				require.NoError(t, err)
				_, err = s.ReserveInlineFile(ctx, file)
				require.ErrorIs(t, err, ErrCollision)
				_, err = s.LoadInlineFile(ctx, ordinary.Binding.IntentID)
				require.ErrorIs(t, err, ErrNotFound)
			}
			// The original kind-inclusive source entity contract is preserved:
			// a file payload may share its logical source key with its object.
			file.Binding.IntentID = strings.Repeat("e", 64)
			file.Fingerprint, _ = s.InlineFileFingerprint(file.Binding, file.Spec, file.SourceSpec)
			if originalKind != InlineFileKind {
				_, err := s.ReserveInlineFile(ctx, file)
				require.NoError(t, err)
			}
		})
	}
}

func TestPreparedInlineLedgerImmutablePlanSpecAndEntity(t *testing.T) {
	db, s := openTestStore(t, filepath.Join(t.TempDir(), "projection.db"))
	defer db.Close()
	ctx := context.Background()
	_, err := s.ReserveInlineFile(ctx, inlineEntry(t, s, "selected"))
	require.NoError(t, err)
	for _, mode := range []string{"plan", "spec", "alternate-intent"} {
		e := inlineEntry(t, s, "loser")
		switch mode {
		case "plan":
			e.Binding.PlanSHA256 = strings.Repeat("f", 64)
			e.Binding.IntentID = strings.Repeat("e", 64)
			e.Binding.SourceKey = "new/source"
		case "spec":
			var spec InlineFileSpec
			require.NoError(t, json.Unmarshal(e.Spec, &spec))
			spec.Name = "changed"
			e.Spec, _ = json.Marshal(spec)
		case "alternate-intent":
			e.Binding.IntentID = strings.Repeat("e", 64)
		}
		e.Fingerprint, _ = s.InlineFileFingerprint(e.Binding, e.Spec, e.SourceSpec)
		_, err := s.ReserveInlineFile(ctx, e)
		require.ErrorIs(t, err, ErrCollision, mode)
	}
	_, err = s.LoadInlineFile(ctx, strings.Repeat("e", 64))
	require.ErrorIs(t, err, ErrNotFound)
}

func TestPreparedInlineLedgerCheckpointFailureAdmitsNoPreparation(t *testing.T) {
	db, s := openTestStore(t, filepath.Join(t.TempDir(), "projection.db"))
	defer db.Close()
	failed := &failingCheckpointDB{DB: db}
	s.db = failed
	got, err := s.ReserveInlineFile(context.Background(), inlineEntry(t, s, "reserved but not admitted"))
	require.Nil(t, got)
	require.ErrorContains(t, err, "checkpoint failure")
	require.Error(t, s.EnsureDurable(context.Background()))
	require.Equal(t, 2, failed.calls)
}

func TestPreparedInlineNativeStrictTierBoundary(t *testing.T) {
	for _, size := range []int{0, 4095, 4096, 4097} {
		bytes := bytes.Repeat([]byte{0xa5}, size)
		spec := InlineFileSpec{OwnerObjectID: "owner", Content: bytes, ContentSHA256: Digest(bytes)}
		err := spec.Validate()
		if size < 4096 {
			require.NoError(t, err)
		} else {
			require.True(t, errors.Is(err, ErrScope))
		}
	}
}
