package migrationintent

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"unicode/utf8"

	anystore "github.com/anyproto/any-store/v2"
	"github.com/anyproto/any-sync-sdk/internal/payloads"
)

const InlineFileKind = "inlineFile"
const inlineFileStage = "inline-file"

// InlineFileSpec contains only ordinary input, never keys or signed bytes.
// The existing payloads tier is strictly smaller than 4096 bytes. Keeping
// this native limit here rejects an oversize request before DAG preparation.
type InlineFileSpec struct {
	OwnerObjectID string `json:"ownerObjectId"`
	Name          string `json:"name"`
	Mime          string `json:"mime"`
	Content       []byte `json:"content"`
	ContentSHA256 string `json:"contentSHA256"`
}

func (s InlineFileSpec) Validate() error {
	if s.OwnerObjectID == "" || len(s.OwnerObjectID) > 256 ||
		!utf8.ValidString(s.Name) || !utf8.ValidString(s.Mime) ||
		len(s.Name) > 1024 || len(s.Mime) > 255 || strings.ContainsRune(s.Name, 0) || strings.ContainsRune(s.Mime, 0) ||
		len(s.Content) >= payloads.InlineMaxSize || s.ContentSHA256 != Digest(s.Content) {
		return ErrScope
	}
	return nil
}

// InlineFile reserves the exact deterministic native derived root AND its
// first signed file row atomically. Neither root registration nor row append
// is allowed before this immutable entry and its checkpoint succeed.
type InlineFile struct {
	Prepared
	RootRaw       []byte `json:"rootRaw"`
	OwnerObjectID string `json:"ownerObjectId"`
	ReadKeyID     string `json:"readKeyId"`
	ACLHeadID     string `json:"aclHeadId"`
	ContentSHA256 string `json:"contentSHA256"`
	Size          int64  `json:"size"`
}

func (s *Store) InlineFileFingerprint(binding Binding, spec, sourceSpec []byte) (string, error) {
	if err := s.Check(binding); err != nil {
		return "", err
	}
	var input InlineFileSpec
	if len(spec) == 0 || len(spec) > 32<<10 || json.Unmarshal(spec, &input) != nil || input.Validate() != nil ||
		len(sourceSpec) == 0 || len(sourceSpec) > 1<<20 || !json.Valid(sourceSpec) || ValidateNumbers(sourceSpec) != nil {
		return "", ErrCorrupt
	}
	h := sha256.New()
	for _, v := range []string{Contract, binding.AccountID, binding.SpaceID, binding.StoreID, binding.PlanID, binding.PlanSHA256, binding.IntentID, binding.SourceKey, InlineFileKind, Digest(spec), Digest(sourceSpec)} {
		var n [8]byte
		binary.BigEndian.PutUint64(n[:], uint64(len(v)))
		h.Write(n[:])
		h.Write([]byte(v))
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func inlineFileKey(intentID string) (string, error) {
	if !validHex(intentID) {
		return "", ErrScope
	}
	// Distinct from root/bootstrap/block; the shared intent identity still
	// rejects reuse of this same intent ID by any other kind in either order.
	return "intent/" + intentID + "/" + inlineFileStage, nil
}

func (s *Store) validateInlineFile(e *InlineFile) error {
	if e == nil || s.Check(e.Binding) != nil || e.Kind != InlineFileKind || e.Stage != inlineFileStage ||
		len(e.RootRaw) == 0 || len(e.RootRaw) > 16<<10 || len(e.Raw) == 0 || len(e.Raw) > 32<<10 ||
		len(e.Payload) == 0 || len(e.Payload) > 24<<10 || e.ObjectID == "" || e.ChangeID == "" ||
		e.OwnerObjectID == "" || e.ReadKeyID == "" || e.ACLHeadID == "" || e.Timestamp <= 0 ||
		len(e.RecordIDs) != 1 || e.RecordIDs[0] == "" || len(e.Dependencies) != 2 ||
		len(e.Dependencies[e.OwnerObjectID]) == 0 || len(e.Dependencies[e.ObjectID]) == 0 {
		return ErrCorrupt
	}
	var spec InlineFileSpec
	if json.Unmarshal(e.Spec, &spec) != nil || spec.Validate() != nil || spec.OwnerObjectID != e.OwnerObjectID ||
		spec.ContentSHA256 != e.ContentSHA256 || int64(len(spec.Content)) != e.Size {
		return ErrCorrupt
	}
	fp, err := s.InlineFileFingerprint(e.Binding, e.Spec, e.SourceSpec)
	if err != nil || fp != e.Fingerprint || e.SpecSHA256 != Digest(e.SourceSpec) {
		return ErrCorrupt
	}
	return nil
}

func (s *Store) LoadInlineFile(ctx context.Context, intentID string) (*InlineFile, error) {
	key, err := inlineFileKey(intentID)
	if err != nil {
		return nil, err
	}
	var e InlineFile
	if err = s.read(ctx, key, &e); err != nil {
		return nil, err
	}
	if e.Binding.IntentID != intentID {
		return nil, ErrCorrupt
	}
	if err = s.validateInlineFile(&e); err != nil {
		return nil, err
	}
	if err = s.checkBindings(ctx, &e.Prepared); err != nil {
		return nil, err
	}
	return &e, nil
}

func (s *Store) ReserveInlineFile(ctx context.Context, proposed *InlineFile) (*InlineFile, error) {
	if err := s.validateInlineFile(proposed); err != nil {
		return nil, err
	}
	tx, err := s.db.WriteTx(ctx)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	txCtx := tx.Context()
	if err = s.bindPlan(txCtx, proposed.Binding); err != nil {
		return nil, err
	}
	if err = s.bindIntent(txCtx, &proposed.Prepared); err != nil {
		return nil, err
	}
	key, _ := inlineFileKey(proposed.Binding.IntentID)
	if err = s.insert(txCtx, key, proposed); err != nil && !errors.Is(err, anystore.ErrDocExists) {
		return nil, err
	}
	stored, err := s.LoadInlineFile(txCtx, proposed.Binding.IntentID)
	if err != nil {
		return nil, err
	}
	if stored.Binding != proposed.Binding || stored.Fingerprint != proposed.Fingerprint ||
		!bytes.Equal(stored.Spec, proposed.Spec) || !bytes.Equal(stored.SourceSpec, proposed.SourceSpec) {
		return nil, ErrCollision
	}
	if err = tx.Commit(); err != nil {
		return nil, err
	}
	if err = s.EnsureDurable(ctx); err != nil {
		return nil, fmt.Errorf("inline file prepared durability: %w", err)
	}
	return stored, nil
}
