package commitguard

import (
	"bytes"
	"context"
	"crypto/sha256"
	"testing"

	"github.com/anyproto/any-store/v2/anyenc"
	"github.com/anyproto/any-sync-sdk/internal/payloads"
	"github.com/anyproto/any-sync/commonspace/object/acl/list"
	"github.com/anyproto/any-sync/commonspace/object/tree/objecttree"
	"github.com/anyproto/any-sync/commonspace/object/tree/treechangeproto"
	"github.com/anyproto/any-sync/commonspace/object/tree/treestorage"
	"github.com/anyproto/any-sync/util/crypto"
	"github.com/stretchr/testify/require"
)

func inlineGuardTree(t *testing.T, f *fixture) objecttree.ObjectTree {
	t.Helper()
	root, err := InlineFileRoot(f.space.Id(), f.tree.Id())
	require.NoError(t, err)
	storage, err := f.space.CreateTreeStorage(context.Background(), treestorage.TreeStorageCreatePayload{RootRawChange: root, Heads: []string{root.Id}})
	require.NoError(t, err)
	tree, err := Builder(nil)(storage, f.acl)
	require.NoError(t, err)
	tree.Lock()
	tree.SetDeferredUpdater(true)
	t.Cleanup(func() { tree.Unlock(); require.NoError(t, tree.Close()) })
	return tree
}

func inlineGuardBytes(t *testing.T, f *fixture, tree objecttree.ObjectTree, author crypto.PrivKey, mode string) (*treechangeproto.RawTreeChangeWithId, InlineFileEnvelope) {
	t.Helper()
	f.acl.RLock()
	kid := f.acl.AclState().CurrentReadKeyId()
	readKey, err := f.acl.AclState().CurrentReadKey()
	f.acl.RUnlock()
	require.NoError(t, err)
	key, err := payloads.DeriveEncKey(readKey)
	require.NoError(t, err)
	body := []byte("native sealed inline file")
	hash := sha256.Sum256(body)
	if mode == "wrong-hash" {
		hash[0] ^= 1
	}
	sealed, err := payloads.SealEnc(key, payloads.EncPayload{Name: "fixture.bin", Mime: "application/octet-stream", SHA256: hash[:], Inline: body})
	require.NoError(t, err)
	if mode == "not-sealed" {
		sealed = []byte("cleartext is forbidden")
	}
	a := &anyenc.Arena{}
	enc := a.NewObject()
	enc.Set("kid", a.NewString(kid))
	enc.Set("ct", a.NewBinary(sealed))
	row := a.NewObject()
	row.Set("size", a.NewNumberFloat64(float64(len(body))))
	row.Set("objectId", a.NewString(f.tree.Id()))
	row.Set("enc", enc)
	if mode == "extra-cleartext" {
		row.Set("name", a.NewString("must never publish"))
	}
	op := a.NewObject()
	op.Set("t", a.NewString("$set"))
	op.Set("v", row)
	ops := a.NewArray()
	ops.SetArrayItem(0, op)
	rec := a.NewObject()
	rec.Set("u", a.NewTrue())
	rec.Set("o", ops)
	recs := a.NewArray()
	recs.SetArrayItem(0, rec)
	wire := a.NewObject()
	wire.Set("d", a.NewString(payloads.Dataset))
	wire.Set("v", a.NewString(payloads.HandlerVersion))
	wire.Set("r", recs)
	data := wire.MarshalTo(nil)
	dataset := payloads.Dataset
	if mode == "wrong-dataset" {
		dataset = "objects"
	}
	raw, err := tree.PrepareChange(objecttree.SignableChangeContent{Key: author, Data: data, DataType: dataset, ShouldBeEncrypted: mode == "encrypted", Timestamp: 17})
	require.NoError(t, err)
	return raw, InlineFileEnvelope{SpaceID: f.space.Id(), OwnerID: f.tree.Id(), ReadKeyID: kid, Payload: data, Timestamp: 17}
}

func TestPreparedInlineGuardDurableStorageBeforeUpdater(t *testing.T) {
	f := newFixture(t)
	tree := inlineGuardTree(t, f)
	raw, proof := inlineGuardBytes(t, f, tree, f.keys.SignKey, "")
	ctx, guard, err := PreparedInlineFileContext(context.Background(), tree, f.keys.SignKey.GetPublic(), raw, proof)
	require.NoError(t, err)
	storage, err := boundNativeCommitStorage(tree)
	require.NoError(t, err)
	writes := 0
	storage.Storage = &observingStorage{Storage: storage.Storage, before: func() { writes++; require.False(t, aclUnlocked(t, f.acl)) }, after: func() { require.False(t, aclUnlocked(t, f.acl)) }}
	callbacks := 0
	_, err = tree.AddRawChangesWithUpdater(ctx, objecttree.RawChangesPayload{NewHeads: []string{raw.Id}, RawChanges: []*treechangeproto.RawTreeChangeWithId{raw}}, func(tr objecttree.ObjectTree, _ objecttree.Mode) error {
		callbacks++
		stored, err := tr.Storage().Get(context.Background(), raw.Id)
		require.NoError(t, err)
		require.Equal(t, raw.RawChange, stored.RawChange)
		require.NotNil(t, guard.committed)
		return nil
	})
	require.NoError(t, err)
	require.Equal(t, 1, writes)
	require.Equal(t, 1, callbacks)
	require.True(t, aclUnlocked(t, f.acl))
	_, err = tree.AddRawChanges(ctx, objecttree.RawChangesPayload{NewHeads: []string{raw.Id}, RawChanges: []*treechangeproto.RawTreeChangeWithId{raw}})
	require.ErrorIs(t, err, ErrNativeCommitGuard)
}

func TestPreparedInlineGuardRejectsClassAndPayloadConfusion(t *testing.T) {
	for _, mode := range []string{"wrong-class", "wrong-dataset", "encrypted", "wrong-hash", "not-sealed", "extra-cleartext", "changed-reserved-payload", "ordinary-token", "encrypted-prepared-token", "missing-deferred"} {
		t.Run(mode, func(t *testing.T) {
			f := newFixture(t)
			tree := inlineGuardTree(t, f)
			if mode == "wrong-class" {
				tree = f.tree
			}
			raw, proof := inlineGuardBytes(t, f, tree, f.keys.SignKey, mode)
			if mode == "changed-reserved-payload" {
				proof.Payload = bytes.Clone(proof.Payload)
				proof.Payload[len(proof.Payload)-2] ^= 1
			}
			ctx, _, err := PreparedInlineFileContext(context.Background(), tree, f.keys.SignKey.GetPublic(), raw, proof)
			switch mode {
			case "ordinary-token":
				require.NoError(t, err)
				ctx, _, err = Context(context.Background(), tree, f.keys.SignKey.GetPublic())
				require.NoError(t, err)
				_, err = tree.AddRawChanges(ctx, objecttree.RawChangesPayload{NewHeads: []string{raw.Id}, RawChanges: []*treechangeproto.RawTreeChangeWithId{raw}})
			case "encrypted-prepared-token":
				require.NoError(t, err)
				_, _, err = PreparedContext(context.Background(), tree, f.keys.SignKey.GetPublic(), raw)
			case "missing-deferred":
				require.NoError(t, err)
				tree.SetDeferredUpdater(false)
				_, err = tree.AddRawChanges(ctx, objecttree.RawChangesPayload{NewHeads: []string{raw.Id}, RawChanges: []*treechangeproto.RawTreeChangeWithId{raw}})
			}
			require.Error(t, err)
			has, readErr := tree.Storage().Has(context.Background(), raw.Id)
			require.NoError(t, readErr)
			require.False(t, has)
		})
	}
}

func TestPreparedInlineGuardCurrentACLRekeyAndRevocationAtStorage(t *testing.T) {
	for _, mode := range []string{"head-advance", "rekey", "revoked-writer", "canceled"} {
		t.Run(mode, func(t *testing.T) {
			f := newFixture(t)
			writer := f.addWriter(t)
			other := f.addWriter(t)
			tree := inlineGuardTree(t, f)
			raw, proof := inlineGuardBytes(t, f, tree, writer, "")
			base, cancel := context.WithCancel(context.Background())
			defer cancel()
			ctx, guard, err := PreparedInlineFileContext(base, tree, writer.GetPublic(), raw, proof)
			require.NoError(t, err)
			switch mode {
			case "head-advance":
				_ = f.addWriter(t)
			case "rekey":
				f.remove(t, other)
			case "revoked-writer":
				f.remove(t, writer)
			case "canceled":
				cancel()
			}
			before := append([]string(nil), tree.Heads()...)
			_, err = tree.AddRawChanges(ctx, objecttree.RawChangesPayload{NewHeads: []string{raw.Id}, RawChanges: []*treechangeproto.RawTreeChangeWithId{raw}})
			switch mode {
			case "revoked-writer":
				require.ErrorIs(t, err, list.ErrInsufficientPermissions)
			case "canceled":
				require.ErrorIs(t, err, context.Canceled)
			default:
				require.ErrorIs(t, err, ErrNativeACLChanged)
			}
			require.Nil(t, guard.committed)
			require.Equal(t, before, tree.Heads())
			has, err := tree.Storage().Has(context.Background(), raw.Id)
			require.NoError(t, err)
			require.False(t, has)
		})
	}
}

func TestPreparedInlineGuardLostAckAndRevokedHistoryRead(t *testing.T) {
	f := newFixture(t)
	writer := f.addWriter(t)
	tree := inlineGuardTree(t, f)
	raw, proof := inlineGuardBytes(t, f, tree, writer, "")
	wrapped, err := boundNativeCommitStorage(tree)
	require.NoError(t, err)
	wrapped.Storage = lostPreparedAckStorage{wrapped.Storage}
	ctx, _, err := PreparedInlineFileContext(context.Background(), tree, writer.GetPublic(), raw, proof)
	require.NoError(t, err)
	_, err = tree.AddRawChanges(ctx, objecttree.RawChangesPayload{NewHeads: []string{raw.Id}, RawChanges: []*treechangeproto.RawTreeChangeWithId{raw}})
	require.ErrorContains(t, err, "lost ACK")
	stored, err := wrapped.Storage.Get(context.Background(), raw.Id)
	require.NoError(t, err)
	require.Equal(t, raw.RawChange, stored.RawChange)
	require.NotZero(t, stored.AddSeq)
	_, err = CheckPreparedInlineFile(context.Background(), f.acl, writer.GetPublic(), tree.Header(), raw, proof, false)
	require.NoError(t, err)
	f.remove(t, writer)
	_, err = CheckPreparedInlineFile(context.Background(), f.acl, writer.GetPublic(), tree.Header(), raw, proof, false)
	require.ErrorIs(t, err, list.ErrInsufficientPermissions)
}
