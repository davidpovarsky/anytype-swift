package commitguard

import (
	"bytes"
	"context"
	"errors"
	"slices"

	"github.com/anyproto/any-sync/commonspace/object/acl/list"
	"github.com/anyproto/any-sync/commonspace/object/tree/objecttree"
	"github.com/anyproto/any-sync/commonspace/object/tree/treechangeproto"
	"github.com/anyproto/any-sync/util/crypto"
)

var (
	ErrNativeCommitGuard = errors.New("guarded local append requires its native commit guard")
	ErrNativeACLChanged  = errors.New("signed ACL head changed before native commit")
)

// nativeCommitTree enforces the private one-call token for SDK guarded writes.
// Ordinary SDK datasets keep their upstream append route. Incoming AddRawChanges
// keeps historical signature/ACL validation; it is not a new local request.
type nativeCommitTree struct {
	objecttree.ObjectTree
	storage  *nativeCommitStorage
	deferred bool
}

type nativeCommitStorage struct {
	objecttree.Storage
	acl    list.AclList
	header *treechangeproto.RawTreeChangeWithId
}

type nativeCommitContextKey struct{}

// All fields belong to one synchronous append while its tree lock is held.
// No token, author, ACL head or guard callback is accepted from an RPC request.
type Guard struct {
	storage   *nativeCommitStorage
	author    crypto.PubKey
	used      bool
	active    bool
	attempted bool
	prepared  *objecttree.StorageChange
	committed *objecttree.StorageChange
	// preparedRaw is set only by the private prepared migration context.
	// Existing local AddContent tokens and incoming replay keep their modes.
	preparedRaw *treechangeproto.RawTreeChangeWithId
	// Only the private original-inline-file route may carry node-readable
	// payloads bytes. Existing encrypted and incoming modes remain separate.
	inlineFile *InlineFileEnvelope
}

func boundNativeCommitStorage(tree objecttree.ObjectTree) (*nativeCommitStorage, error) {
	if tree == nil {
		return nil, ErrNativeCommitGuard
	}
	storage, ok := tree.Storage().(*nativeCommitStorage)
	if !ok || storage == nil || storage.acl == nil || storage.header == nil ||
		storage.Id() != tree.Id() || storage.acl != tree.AclList() ||
		storage.header.Id != tree.Header().Id || !bytes.Equal(storage.header.RawChange, tree.Header().RawChange) {
		return nil, ErrNativeCommitGuard
	}
	return storage, nil
}

func Context(ctx context.Context, tree objecttree.ObjectTree, author crypto.PubKey) (context.Context, *Guard, error) {
	storage, err := boundNativeCommitStorage(tree)
	if ctx == nil || err != nil || author == nil {
		return nil, nil, ErrNativeCommitGuard
	}
	guard := &Guard{storage: storage, author: author}
	return context.WithValue(ctx, nativeCommitContextKey{}, guard), guard, nil
}

// CheckCurrentWrite is the authority linearization point for an exact retry
// which appends nothing. The caller still holds all target/carrier tree locks.
func CheckCurrentWrite(ctx context.Context, tree objecttree.ObjectTree, author crypto.PubKey) error {
	storage, err := boundNativeCommitStorage(tree)
	if err != nil || ctx == nil || author == nil {
		return ErrNativeCommitGuard
	}
	storage.acl.RLock()
	defer storage.acl.RUnlock()
	if err := ctx.Err(); err != nil {
		return err
	}
	if !storage.acl.AclState().Permissions(author).CanWrite() {
		return list.ErrInsufficientPermissions
	}
	return nil
}

func nativeGuard(ctx context.Context) *Guard {
	if ctx == nil {
		return nil
	}
	guard, _ := ctx.Value(nativeCommitContextKey{}).(*Guard)
	return guard
}

func copyNativeStorageChange(change objecttree.StorageChange) *objecttree.StorageChange {
	change.RawChange = bytes.Clone(change.RawChange)
	change.PrevIds = slices.Clone(change.PrevIds)
	return &change
}

func (t *nativeCommitTree) AddContent(ctx context.Context, content objecttree.SignableChangeContent) (objecttree.AddResult, error) {
	return t.AddContentWithValidator(ctx, content, nil)
}

func (t *nativeCommitTree) AddContentWithValidator(ctx context.Context, content objecttree.SignableChangeContent, validate objecttree.ChangeValidator) (objecttree.AddResult, error) {
	guard := nativeGuard(ctx)
	if guard == nil {
		return t.ObjectTree.AddContentWithValidator(ctx, content, validate)
	}
	if guard.preparedRaw != nil || guard.storage != t.storage || guard.used || content.Key == nil ||
		!content.Key.GetPublic().Equals(guard.author) {
		return objecttree.AddResult{}, ErrNativeCommitGuard
	}
	if err := ctx.Err(); err != nil {
		return objecttree.AddResult{}, err
	}
	guard.used, guard.active = true, true
	defer func() { guard.active = false }()
	return t.ObjectTree.AddContentWithValidator(ctx, content, func(change objecttree.StorageChange) error {
		if guard.prepared != nil {
			return ErrNativeCommitGuard
		}
		guard.prepared = copyNativeStorageChange(change)
		if validate != nil {
			return validate(change)
		}
		return nil
	})
}

func (t *nativeCommitTree) AddRawChanges(ctx context.Context, changes objecttree.RawChangesPayload) (objecttree.AddResult, error) {
	if nativeGuard(ctx) != nil {
		return t.addPreparedRaw(ctx, changes, nil)
	}
	return t.ObjectTree.AddRawChanges(ctx, changes)
}

func (t *nativeCommitTree) AddRawChangesWithUpdater(ctx context.Context, changes objecttree.RawChangesPayload, update objecttree.Updater) (objecttree.AddResult, error) {
	if nativeGuard(ctx) != nil {
		return t.addPreparedRaw(ctx, changes, update)
	}
	return t.ObjectTree.AddRawChangesWithUpdater(ctx, changes, update)
}

func (s *nativeCommitStorage) AddAll(ctx context.Context, changes []objecttree.StorageChange, heads []string, snapshot string) error {
	guard := nativeGuard(ctx)
	if guard == nil {
		// Remote/deferred-storage replay has already passed the unchanged native
		// historical verifier. A later revocation must not erase valid history.
		return s.Storage.AddAll(ctx, changes, heads, snapshot)
	}
	if guard.preparedRaw != nil {
		if guard.storage != s || !guard.active || guard.attempted || guard.prepared != nil || len(changes) != 1 ||
			changes[0].Id != guard.preparedRaw.Id || !bytes.Equal(changes[0].RawChange, guard.preparedRaw.RawChange) {
			return ErrNativeCommitGuard
		}
		// OrderId/AddSeq are assigned by the unchanged native raw-DAG path.
		// Only the exact persisted signed envelope is admitted to this mode.
		guard.prepared = copyNativeStorageChange(changes[0])
	}
	if guard.storage != s || !guard.active || guard.attempted || guard.prepared == nil ||
		len(changes) != 1 || len(heads) != 1 || heads[0] != guard.prepared.Id || snapshot != s.header.Id {
		return ErrNativeCommitGuard
	}
	expected, actual := guard.prepared, changes[0]
	if actual.Id != expected.Id || actual.OrderId != expected.OrderId ||
		actual.SnapshotId != expected.SnapshotId || actual.SnapshotCounter != expected.SnapshotCounter ||
		actual.ChangeSize != expected.ChangeSize || !bytes.Equal(actual.RawChange, expected.RawChange) ||
		!slices.Equal(actual.PrevIds, expected.PrevIds) {
		return ErrNativeCommitGuard
	}
	guard.attempted = true
	if err := ctx.Err(); err != nil {
		return err
	}
	change, err := objecttree.NewChangeBuilder(crypto.NewKeyStorage(), s.header).Unmarshall(actual.RawTreeChangeWithId(), true)
	if err != nil {
		return err
	}
	if change.Identity == nil || !change.Identity.Equals(guard.author) || change.IsSnapshot {
		return ErrNativeCommitGuard
	}
	if guard.inlineFile == nil {
		if change.ReadKeyId == "" {
			return ErrNativeCommitGuard
		}
	} else {
		if guard.preparedRaw == nil {
			return ErrNativeCommitGuard
		}
		if _, err = inlineEnvelope(s.header, actual.RawTreeChangeWithId(), guard.author, *guard.inlineFile); err != nil {
			return err
		}
	}

	// prepareBuilderContent and validateTree have released their own ACL locks.
	// Hold this final read lock only across the real native storage transaction,
	// never across SyncTree head-update construction, broadcast or projection.
	s.acl.RLock()
	defer s.acl.RUnlock()
	if err = ctx.Err(); err != nil {
		return err
	}
	if !s.acl.AclState().Permissions(guard.author).CanWrite() {
		return list.ErrInsufficientPermissions
	}
	head := s.acl.Head()
	if head == nil || change.AclHeadId != head.Id {
		return errors.Join(ErrNativeACLChanged, list.ErrInsufficientPermissions)
	}
	readKeyID := change.ReadKeyId
	if guard.inlineFile != nil {
		readKeyID = guard.inlineFile.ReadKeyID
	}
	if guard.preparedRaw != nil && readKeyID != s.acl.AclState().CurrentReadKeyId() {
		return ErrNativeACLChanged
	}
	if guard.inlineFile != nil {
		if _, err = inlinePayloadLocked(s.acl, *guard.inlineFile); err != nil {
			return err
		}
	}
	if err = s.Storage.AddAll(ctx, changes, heads, snapshot); err != nil {
		return err
	}
	// AddAll returns only after its deferred tx.Commit succeeds. The underlying
	// store has also assigned AddSeq in this slice. This is the durable witness
	// even if SyncTree later returns an error while creating its head update.
	guard.committed = copyNativeStorageChange(changes[0])
	return nil
}

func (s *nativeCommitStorage) AddAllNoError(ctx context.Context, changes []objecttree.StorageChange, heads []string, snapshot string) error {
	if nativeGuard(ctx) != nil {
		return ErrNativeCommitGuard
	}
	return s.Storage.AddAllNoError(ctx, changes, heads, snapshot)
}

// Builder preserves AnySync's normal signature and historical ACL validation.
// Only a native guarded local call takes the final ACL/storage fence; incoming
// historical changes are not judged against a later current ACL.
func Builder(validate func(*objecttree.Change, list.AclList) error) objecttree.BuildObjectTreeFunc {
	return func(storage objecttree.Storage, acl list.AclList) (objecttree.ObjectTree, error) {
		root, err := storage.Root(context.Background())
		if err != nil {
			return nil, err
		}
		guarded := &nativeCommitStorage{Storage: storage, acl: acl, header: root.RawTreeChangeWithId()}
		build := objecttree.BuildObjectTree
		if validate != nil {
			build = objecttree.BuildObjectTreeWithContentValidator(validate)
		}
		tree, err := build(guarded, acl)
		if err != nil {
			return nil, err
		}
		return &nativeCommitTree{ObjectTree: tree, storage: guarded}, nil
	}
}
