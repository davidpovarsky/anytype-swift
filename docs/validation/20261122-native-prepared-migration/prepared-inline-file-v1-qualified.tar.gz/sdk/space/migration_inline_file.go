package space

import "context"

// PreparedInlineFileService is an experimental, native-only Files() surface.
// It is deliberately separate from PreparedMigrationService and does not
// enable its File capability. Only one original inline file on an existing
// signed ordinary object is supported; no variants or full-tier uploads.
type PreparedInlineFileService interface {
	PrepareMigrationInlineFile(context.Context, MigrationInput, MigrationInlineFileSpec) (MigrationInlineFileReceipt, error)
	MigrationInlineFileStatus(context.Context, string) (MigrationInlineFileReceipt, error)
	CommitMigrationInlineFile(context.Context, MigrationCommit) (MigrationInlineFileReceipt, error)
}

type MigrationInlineFileSpec struct {
	OwnerObjectID string `json:"ownerObjectId"`
	Name          string `json:"name"`
	Mime          string `json:"mime"`
	Content       []byte `json:"content"`
	ContentSHA256 string `json:"contentSHA256"`
}

// Both native identities are reserved before the first commit. ChangeID is
// always the signed row CID; ObjectID is the deterministic payloads root.
// One commit advances file-prepared -> file-root-committed, the second
// advances to complete. Existing roots start at file-root-committed.
type MigrationInlineFileReceipt struct {
	MigrationReceipt
	OwnerObjectID string `json:"ownerObjectId"`
	FileID        string `json:"fileId"`
	ContentSHA256 string `json:"contentSHA256"`
	Size          int64  `json:"size"`
}
