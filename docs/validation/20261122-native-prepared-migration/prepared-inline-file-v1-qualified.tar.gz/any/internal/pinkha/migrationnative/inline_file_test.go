package migrationnative

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"

	anysyncsdk "github.com/anyproto/any-sync-sdk"
	"github.com/anyproto/any-sync-sdk/handler"
	"github.com/anyproto/any-sync-sdk/space"
	"github.com/stretchr/testify/require"
)

func inlineSpec(owner string, body []byte) space.MigrationInlineFileSpec {
	hash := sha256.Sum256(body)
	return space.MigrationInlineFileSpec{OwnerObjectID: owner, Name: "migration-שלום.bin", Mime: "application/octet-stream", Content: body, ContentSHA256: hex.EncodeToString(hash[:])}
}

// This uses the existing native read snapshot to hold the carrier tree, not
// a product fault hook. The ordinary deletion route writes its real synced
// settings record/queued head while the file call waits for that tree lock.
func TestPreparedInlineFileOwnerQueuedDuringNativeLockWaitRefuses(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	sdk, err := anysyncsdk.Open(ctx, nativeConfig(t.TempDir(), localNetwork(t)), newSeeds(t))
	require.NoError(t, err)
	defer sdk.Close()
	sp, err := sdk.Spaces().Create(ctx, space.CreateRequest{Name: "disposable inline queued-owner race"})
	require.NoError(t, err)
	native := sp.Files().(space.PreparedInlineFileService)
	capabilities, err := sp.Objects().(space.PreparedMigrationService).MigrationCapabilities(ctx)
	require.NoError(t, err)
	var prepared space.MigrationInlineFileReceipt
	var input space.MigrationInput
	// Stable lock order is part of the native route. Choose an actual signed
	// owner that sorts before its deterministic carrier, so a file waiter
	// already holds the owner when it reaches the blocked carrier lock.
	for attempt := 0; attempt < 32; attempt++ {
		owner, err := space.CreateCurrentWriter(ctx, sp, space.CreateObjectOpts{Type: "page"})
		require.NoError(t, err)
		_, err = sp.Files().Attach(ctx, owner.ObjectID, bytes.NewReader([]byte("seed")), space.AttachOpts{Name: "seed.txt"})
		require.NoError(t, err)
		spec := inlineSpec(owner.ObjectID, []byte("must not publish after owner queued"))
		input = nativeInput(t, capabilities, fmt.Sprintf("source/file/queued-owner/%d", attempt), spec)
		prepared, err = native.PrepareMigrationInlineFile(ctx, input, spec)
		require.NoError(t, err)
		if owner.ObjectID < prepared.ObjectID {
			break
		}
	}
	require.Less(t, prepared.OwnerObjectID, prepared.ObjectID)
	type nativeSnapshot interface {
		NativeReadSnapshot(context.Context, []string, func(handler.NativeReadView) error) error
	}
	reader, ok := sp.(nativeSnapshot)
	require.True(t, ok)
	held, release := make(chan struct{}), make(chan struct{})
	var releaseOnce sync.Once
	defer releaseOnce.Do(func() { close(release) })
	snapshotDone := make(chan error, 1)
	go func() {
		snapshotDone <- reader.NativeReadSnapshot(ctx, []string{prepared.ObjectID}, func(handler.NativeReadView) error { close(held); <-release; return nil })
	}()
	select {
	case <-held:
	case <-ctx.Done():
		t.Fatal(ctx.Err())
	}
	type result struct {
		receipt space.MigrationInlineFileReceipt
		err     error
	}
	committed := make(chan result, 1)
	go func() {
		r, e := native.CommitMigrationInlineFile(ctx, commitOf(input, prepared.MigrationReceipt))
		committed <- result{r, e}
	}()
	// Observe the actual call blocked in the native stable-lock helper after
	// preloading its live owner. No artificial append/storage implementation.
	require.Eventually(t, func() bool {
		stack := make([]byte, 1<<20)
		n := runtime.Stack(stack, true)
		for _, goroutine := range strings.Split(string(stack[:n]), "\n\n") {
			if strings.Contains(goroutine, "spaceobjects.(*Store).withInlineFileObjects") && strings.Contains(goroutine, "spaceobjects.(*Store).lockPreparedNativeObjects") {
				return true
			}
		}
		return false
	}, 5*time.Second, 10*time.Millisecond)
	deleted := make(chan error, 1)
	go func() { deleted <- sp.Objects().Delete(ctx, prepared.OwnerObjectID) }()
	require.Eventually(t, func() bool {
		heads, err := sp.TreeHeads(ctx)
		if err != nil {
			return false
		}
		for _, head := range heads {
			if head.TreeId == prepared.OwnerObjectID {
				return false
			}
		}
		return true
	}, 5*time.Second, 10*time.Millisecond, "real native owner head must be queued while its tree is locked")
	select {
	case err := <-deleted:
		t.Fatalf("owner deletion unexpectedly completed while file owns the native owner lock: %v", err)
	default:
	}
	releaseOnce.Do(func() { close(release) })
	require.NoError(t, <-snapshotDone)
	observed := <-committed
	require.NoError(t, observed.err)
	require.Equal(t, "obsolete", observed.receipt.Outcome)
	require.NoError(t, <-deleted)
	_, err = sp.Files().Get(ctx, prepared.FileID)
	require.Error(t, err)
	t.Log("queued_owner_evidence actual_settings_delete=true queued_before_lock_release=true native_preload_completed=true prepared_file_append_refused=true")
}

func readInlineFile(t *testing.T, ctx context.Context, sp space.Space, receipt space.MigrationInlineFileReceipt, spec space.MigrationInlineFileSpec) {
	t.Helper()
	info, err := sp.Files().Get(ctx, receipt.FileID)
	require.NoError(t, err)
	require.Equal(t, receipt.FileID, info.FileId)
	require.Equal(t, spec.OwnerObjectID, info.ObjectId)
	require.Equal(t, spec.Name, info.Name)
	require.Equal(t, spec.Mime, info.Mime)
	require.True(t, info.Inline && info.Cached && info.Durable)
	require.Empty(t, info.RootCid)
	require.Equal(t, int64(len(spec.Content)), info.Size)
	reader, err := sp.Files().Open(ctx, receipt.FileID, space.VariantOriginal)
	require.NoError(t, err)
	actual, err := io.ReadAll(reader)
	require.NoError(t, err)
	require.NoError(t, reader.Close())
	hash := sha256.Sum256(actual)
	require.Equal(t, spec.Content, actual)
	require.Equal(t, spec.ContentSHA256, hex.EncodeToString(hash[:]))
}

func TestPreparedInlineFileProductionSDKStageRestartReadbackAndDelete(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	cfg, provider := nativeConfig(t.TempDir(), localNetwork(t)), newSeeds(t)
	var sdk *anysyncsdk.SDK
	var sp space.Space
	var native space.PreparedInlineFileService
	var spaceID string
	open := func() {
		var err error
		sdk, err = anysyncsdk.Open(ctx, cfg, provider)
		require.NoError(t, err)
		if spaceID == "" {
			sp, err = sdk.Spaces().Create(ctx, space.CreateRequest{Name: "disposable inline migration"})
			if err == nil {
				spaceID = sp.Id()
			}
		} else {
			sp, err = sdk.Spaces().Get(ctx, spaceID)
		}
		require.NoError(t, err)
		var ok bool
		native, ok = sp.Files().(space.PreparedInlineFileService)
		require.True(t, ok)
	}
	closeSDK := func() { require.NoError(t, sdk.Close()); sdk = nil }
	t.Cleanup(func() {
		if sdk != nil {
			_ = sdk.Close()
		}
	})
	open()
	capabilities, err := sp.Objects().(space.PreparedMigrationService).MigrationCapabilities(ctx)
	require.NoError(t, err)
	require.Zero(t, capabilities.File)
	require.False(t, capabilities.NetworkVerified)
	owner, err := space.CreateCurrentWriter(ctx, sp, space.CreateObjectOpts{Type: "page", InitialProperties: map[string]map[string]any{"any": {"name": "file owner"}}})
	require.NoError(t, err)
	// Actual maximum admitted inline payload, including non-text bytes.
	spec := inlineSpec(owner.ObjectID, bytes.Repeat([]byte{0x01, 0xa5, 0x00}, 1365))
	require.Len(t, spec.Content, 4095)
	input := nativeInput(t, capabilities, "source/file/maximum-inline", spec)
	prepared, err := native.PrepareMigrationInlineFile(ctx, input, spec)
	require.NoError(t, err)
	require.Equal(t, "file-prepared", prepared.Stage)
	require.Equal(t, "prepared", prepared.Outcome)
	_, err = sp.Files().Get(ctx, prepared.FileID)
	require.Error(t, err, "prepare must not publish a row")
	_, err = sp.Objects().Get(ctx, prepared.ObjectID)
	require.Error(t, err, "prepare must not register its root")
	closeSDK()
	open()
	recovered, err := native.PrepareMigrationInlineFile(ctx, input, spec)
	require.NoError(t, err)
	require.Equal(t, prepared, recovered)
	commit := commitOf(input, prepared.MigrationReceipt)
	root, err := native.CommitMigrationInlineFile(ctx, commit)
	require.NoError(t, err)
	require.Equal(t, "file-root-committed", root.Stage)
	require.Equal(t, prepared.ChangeID, root.ChangeID)
	require.Equal(t, prepared.Fingerprint, root.Fingerprint)
	_, err = sp.Files().Get(ctx, prepared.FileID)
	require.Error(t, err)
	closeSDK()
	open()
	status, err := native.MigrationInlineFileStatus(ctx, input.IntentID)
	require.NoError(t, err)
	require.Equal(t, root, status)
	// Concurrent explicit commits race through the native route, then actual
	// Files.Get/Open must still read the one known signed change/record.
	var wg sync.WaitGroup
	receipts := make(chan space.MigrationInlineFileReceipt, 6)
	errs := make(chan error, 6)
	for range 6 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r, err := native.CommitMigrationInlineFile(ctx, commit)
			receipts <- r
			errs <- err
		}()
	}
	wg.Wait()
	close(receipts)
	close(errs)
	for err := range errs {
		require.NoError(t, err)
	}
	var complete space.MigrationInlineFileReceipt
	for r := range receipts {
		require.Equal(t, "complete", r.Stage)
		require.Equal(t, "committed", r.Outcome)
		require.Equal(t, prepared.ChangeID, r.ChangeID)
		require.Equal(t, prepared.FileID, r.FileID)
		complete = r
	}
	readInlineFile(t, ctx, sp, complete, spec)
	closeSDK()
	open()
	// Discarded commit acknowledgement recovers known native bytes after
	// actual SDK/database close/reopen; it may not reseal or allocate a row.
	retried, err := native.CommitMigrationInlineFile(ctx, commit)
	require.NoError(t, err)
	require.Equal(t, complete, retried)
	readInlineFile(t, ctx, sp, retried, spec)
	stats, err := sp.Files().Stats(ctx)
	require.NoError(t, err)
	require.Equal(t, 1, stats.Total)
	// A second file shares the existing deterministic carrier. Zero bytes
	// remain a legitimate native inline file and need only the row stage.
	emptySpec := inlineSpec(owner.ObjectID, []byte{})
	emptyInput := nativeInput(t, capabilities, "source/file/empty-existing-carrier", emptySpec)
	emptyPrepared, err := native.PrepareMigrationInlineFile(ctx, emptyInput, emptySpec)
	require.NoError(t, err)
	require.Equal(t, "file-root-committed", emptyPrepared.Stage)
	require.Equal(t, prepared.ObjectID, emptyPrepared.ObjectID)
	emptyDone, err := native.CommitMigrationInlineFile(ctx, commitOf(emptyInput, emptyPrepared.MigrationReceipt))
	require.NoError(t, err)
	require.Equal(t, "committed", emptyDone.Outcome)
	readInlineFile(t, ctx, sp, emptyDone, emptySpec)
	stats, err = sp.Files().Stats(ctx)
	require.NoError(t, err)
	require.Equal(t, 2, stats.Total)
	require.NoError(t, sp.Files().Delete(ctx, prepared.FileID))
	deleted, err := native.CommitMigrationInlineFile(ctx, commit)
	require.NoError(t, err)
	require.Equal(t, "committed_deleted", deleted.Outcome)
	_, err = sp.Files().Get(ctx, prepared.FileID)
	require.Error(t, err)
	closeSDK()
	open()
	deletedAgain, err := native.CommitMigrationInlineFile(ctx, commit)
	require.NoError(t, err)
	require.Equal(t, deleted, deletedAgain)
	_, err = sp.Files().Get(ctx, prepared.FileID)
	require.Error(t, err)
	t.Logf("prepared_inline_native bytes=4095 stages=2 exact_root_row_restart=true concurrent_commit_callers=6 native_get_open_sha256=%s deleted_retry_resurrects=false", spec.ContentSHA256)
}

func TestPreparedInlineFileNativeOversizeAndChangedOwnerRefuseBeforeAppend(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	sdk, err := anysyncsdk.Open(ctx, nativeConfig(t.TempDir(), localNetwork(t)), newSeeds(t))
	require.NoError(t, err)
	defer sdk.Close()
	sp, err := sdk.Spaces().Create(ctx, space.CreateRequest{Name: "disposable inline negative controls"})
	require.NoError(t, err)
	native := sp.Files().(space.PreparedInlineFileService)
	capabilities, err := sp.Objects().(space.PreparedMigrationService).MigrationCapabilities(ctx)
	require.NoError(t, err)
	owner, err := space.CreateCurrentWriter(ctx, sp, space.CreateObjectOpts{Type: "page"})
	require.NoError(t, err)
	for _, size := range []int{4096, 4097} {
		spec := inlineSpec(owner.ObjectID, bytes.Repeat([]byte{byte(size)}, size))
		input := nativeInput(t, capabilities, "source/file/oversize", spec)
		_, err := native.PrepareMigrationInlineFile(ctx, input, spec)
		require.Error(t, err)
		_, err = native.MigrationInlineFileStatus(ctx, input.IntentID)
		require.ErrorIs(t, err, space.ErrMigrationNotFound)
	}
	spec := inlineSpec(owner.ObjectID, []byte("pending owner fence"))
	input := nativeInput(t, capabilities, "source/file/owner-changed", spec)
	prepared, err := native.PrepareMigrationInlineFile(ctx, input, spec)
	require.NoError(t, err)
	require.Equal(t, "file-prepared", prepared.Stage, "oversize attempts must not have registered a payloads root")
	_, err = sp.Properties().Set(ctx, owner.ObjectID, "any", map[string]any{"name": "owner changed after preparation"})
	require.NoError(t, err)
	refused, err := native.CommitMigrationInlineFile(ctx, commitOf(input, prepared.MigrationReceipt))
	require.NoError(t, err)
	require.Equal(t, "obsolete", refused.Outcome)
	_, err = sp.Objects().Get(ctx, prepared.ObjectID)
	require.Error(t, err)
	_, err = sp.Files().Get(ctx, prepared.FileID)
	require.Error(t, err)
	stats, err := sp.Files().Stats(ctx)
	require.NoError(t, err)
	require.Zero(t, stats.Total)
	// The ordinary native Attach route remains available and can advance a
	// carrier while an intent is pending. That intent must not be rebased.
	other, err := space.CreateCurrentWriter(ctx, sp, space.CreateObjectOpts{Type: "page"})
	require.NoError(t, err)
	_, err = sp.Files().Attach(ctx, other.ObjectID, bytes.NewReader([]byte("existing")), space.AttachOpts{Name: "existing.txt"})
	require.NoError(t, err)
	carrierSpec := inlineSpec(other.ObjectID, []byte("must not append after carrier moves"))
	carrierInput := nativeInput(t, capabilities, "source/file/carrier-changed", carrierSpec)
	carrierPending, err := native.PrepareMigrationInlineFile(ctx, carrierInput, carrierSpec)
	require.NoError(t, err)
	require.Equal(t, "file-root-committed", carrierPending.Stage)
	_, err = sp.Files().Attach(ctx, other.ObjectID, bytes.NewReader([]byte("new ordinary attach")), space.AttachOpts{Name: "new.txt"})
	require.NoError(t, err)
	carrierRefused, err := native.CommitMigrationInlineFile(ctx, commitOf(carrierInput, carrierPending.MigrationReceipt))
	require.NoError(t, err)
	require.Equal(t, "obsolete", carrierRefused.Outcome)
	_, err = sp.Files().Get(ctx, carrierPending.FileID)
	require.Error(t, err)
	stats, err = sp.Files().Stats(ctx)
	require.NoError(t, err)
	require.Equal(t, 2, stats.Total)
	// A deleted live owner cannot be resurrected by a reserved file intent.
	deletedOwner, err := space.CreateCurrentWriter(ctx, sp, space.CreateObjectOpts{Type: "page"})
	require.NoError(t, err)
	deletedSpec := inlineSpec(deletedOwner.ObjectID, []byte("owner will be deleted"))
	deletedInput := nativeInput(t, capabilities, "source/file/owner-deleted", deletedSpec)
	deletedPending, err := native.PrepareMigrationInlineFile(ctx, deletedInput, deletedSpec)
	require.NoError(t, err)
	require.NoError(t, sp.Objects().Delete(ctx, deletedOwner.ObjectID))
	deletedRefused, err := native.CommitMigrationInlineFile(ctx, commitOf(deletedInput, deletedPending.MigrationReceipt))
	require.NoError(t, err)
	require.Equal(t, "obsolete", deletedRefused.Outcome)
	_, err = sp.Files().Get(ctx, deletedPending.FileID)
	require.Error(t, err)
}
