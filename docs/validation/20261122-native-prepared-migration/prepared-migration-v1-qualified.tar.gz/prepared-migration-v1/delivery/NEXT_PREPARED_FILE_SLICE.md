# Smallest prepared-file extension: native investigation result

File capability remains `0`. No file implementation or weakened encrypted-object guard is included in this candidate.

## Existing actual APIs

Any at `88fae2e5ae7d0f46d6707567a3123081faa8de9a` already accepts streamed binary bytes through `POST /v1/spaces/:spaceId/objects/:objectId/files`, implemented by `internal/server/handlers_files.go:fileAttach`. Name and variant metadata are query parameters; MIME type is a header. The body is passed to `Space.Files().Attach`. The current Swift migration transport does not expose that raw-binary path. Ordinary attach has no caller-supplied stable intent key or commit-before-ACK reconciliation contract.

SDK at `854df54cdadd76006ae823cbd1b1d923138356d0` implements owner payload rows in `internal/spaceimpl/payloads.go`, public file orchestration in `internal/spaceimpl/files.go`, and upload/GC intent handling in `internal/files/upload/upload.go`. `PayloadsAPI.ObjectId` can resolve a deterministic payload-tree ID without creating it. The shape depends on the owner's signed/derived class; unknown owner class is an explicit refusal. `prepareRows` currently both seals data and calls native `Derive`, so its name does not imply a mutation-free preparation seam.

## Bounded first extension

Start with an inline original file within the existing strict native inline-size bound. Preserve exact payload bytes and their SHA256, filename/MIME, owner identity/class, current native key ID, exact sealed `Enc` bytes, deterministic payload root and exact signed row change before any root/row append. Split validation/sealing from mutation in `prepareRows`; reuse the existing native sealing/schema code. Reserve exact root and row stages in the same native private intent ledger, including immutable plan/entity/digest binding.

This requires a separate native payload-class prepared mode. Payload objects are intentionally a distinct plaintext carrier containing member-key-sealed metadata. The ordinary encrypted-object guard must continue refusing them. The new mode must verify the actual native payload change type, deterministic owner derivation, current ACL/key and owner liveness, exact sealed payload and native schema before committing known reserved bytes. Recovery must distinguish never committed, exact committed, deleted/modified and obsolete envelopes without resealing or choosing new file/record IDs.

Only after that route is qualified should a binary upload API expose an explicit plan/entity/prepared contract. The Swift adapter must perform a reviewed bounded upload and status reconciliation; a client receipt cannot supply missing native deduplication.

## Full-tier work remains separate

Large files additionally require reserving the generated encryption key and content-addressed CAR/UnixFS root, durable local payload/cache state, native payload row and GC/ref/queue lifecycle across restart. Existing random upload attach IDs protect GC bookkeeping; they are not an immutable migration deduplication key. A timeout after remote upload and before row acknowledgement must reconcile exact content and row history without creating another encryption/key/root sequence. Network durability receipts need their own verified result.

Focused acceptance would need actual binary hash readback, preparation/checkpoint failure with no append, row commit-before-ACK recovery, close/reopen at each stage, exact retry/concurrency, owner deletion/modification, rekey/authority obsolescence and payload-class confusion negatives. No current object/block or local-peer pass should be reused as proof that these file guarantees exist.
