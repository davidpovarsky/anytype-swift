# Native prepared migration, contract v1

This is an isolated implementation under review. It extends the exact v10 Any candidate and its v9 SDK source overlay. It is not a published runtime and does not complete MIG-01. The associated evidence files distinguish actual passes, failures, compilation timeouts and pending fixtures.

## Source composition

| Component | Exact base |
|---|---|
| Any | `anyproto/any@88fae2e5ae7d0f46d6707567a3123081faa8de9a` |
| Any retained overlay | v10 authorized-operation candidate; SHA256 `64f7da56fb4f30b78baae8afe850fa0429dccde4b977bd3c7e30fc03d26dfa5e` |
| SDK | `anyproto/any-sync-sdk@854df54cdadd76006ae823cbd1b1d923138356d0` |
| SDK retained overlay | v9 property receipts; SHA256 `b9021dc305ab150501e86243270df73f3d6a27490ec343cf6252e5a214f5a461` |
| any-sync / any-store | Existing dependencies, no patches |

The shared source manifest is `Tools/AnyEngineValidation/evidence/native-authorized-operation-read-v10-candidate-source.json` at App `7f42c6daf270f8e87f789ebc1491b4d8fcc74867`. The isolated full native worktree was checked against all 54 Any and 41 SDK manifest blobs before this additive work. Existing v10 authorized-read and v9 guarded/incoming behavior remain in the source composition.

## HTTP routes

All paths begin with `/v1/spaces/{spaceId}/pinkha/migration`. Requests use the actual server account and Space. Current writer authority is required even for capabilities, status and an exact no-op retry.

| Method and suffix | Request | Successful response |
|---|---|---|
| GET `/capabilities` | No body | Contract, native store/account/Space identity and individual capability flags |
| PUT `/intents/{intentId}/object/prepare` | Preparation envelope and object spec | Native reservation/status receipt |
| PUT `/intents/{intentId}/block/prepare` | Preparation envelope and block spec | Native reservation/status receipt |
| GET `/intents/{intentId}` | No body | Reconciled native status; never a new create |
| POST `/intents/{intentId}/commit` | Commit envelope | One durable stage of progress or a terminal observed outcome |

Capabilities have keys `contract`, `storeId`, `accountId`, `spaceId`, `object`, `editorBlock`, `file`, `networkVerified`. The contract is `pinkha-native-prepared-migration-v1`. Object/editorBlock are separately declared. File remains `0`; `networkVerified` remains `false` in this candidate.

Preparation envelope:

```json
{
  "contract": "pinkha-native-prepared-migration-v1",
  "storeId": "64 lowercase hex",
  "planId": "64 lowercase hex",
  "planSHA256": "64 lowercase hex",
  "sourceKey": "stable original entity key",
  "specBase64": "standard padded base64 of exact UTF-8 JSON bytes",
  "specSHA256": "SHA256 of those exact decoded bytes"
}
```

`intentId` is 64 lowercase hex in the URL. The decoded spec limit is 1 MiB; the wire limit is 2 MiB. The HTTP parser rejects duplicate keys recursively, unknown typed fields, invalid/trailing JSON and excessive depth. Native reservation also rejects JSON numbers whose decimal value would change when represented in the native float64 scalar model. Native recovery retains number tokens and the exact original spec bytes.

Object spec: `type`, optional `collections`, optional `initialProperties`. Template cloning, meta-Type creation and caller-supplied native object IDs are not admitted.

Block spec: `objectId`, `dataset`, `type`, optional `style`, `text`, and `nav` with `parentId` and explicit `pos`. Dataset is exactly `editor_blocks`. Supported semantic block types are `paragraph`, `heading`, `quote`, `code`, `list_item`, `check_list_item`. Actual native Type/dataset/parent/schema policy still decides admissibility.

Commit envelope: `contract`, `storeId`, `planId`, `planSHA256`, `fingerprint`. It never accepts replacement specs or signed DAG bytes.

## Immutable native bindings

The private ledger is in the actual SDK projection database, independently namespaced per Space. It holds a persistent random store generation and exact native account/Space identity.

One private ledger transaction binds the logical plan to its full immutable `planSHA256`, the stable `(planId, sourceKey, kind)` entity to one caller intent ID, the intent to one native fingerprint, and the prepared signed bytes. Alternate IDs for the same entity conflict. A conflicting request rolls back its private metadata transaction. This transaction never surrounds native tree creation, native AddAll, watcher publication or any-sync callbacks.

The native fingerprint is SHA256 over length-framed UTF-8 values in this order: contract, account ID, Space ID, store ID, plan ID, plan SHA256, intent ID, source key, kind, normalized native operation SHA256, exact source spec SHA256. Each length is unsigned 64-bit big endian. It is opaque to the client; the client compares the echoed exact `specSHA256` and all scope fields before committing.

Root and bootstrap retain the same operation fingerprint, source spec hash, plan and object ID. A required native full checkpoint completes before any reserved bytes are admitted to native append. Commit repeats that barrier even if an earlier prepare returned an I/O error after its logical insertion.

## Stage and receipt rules

An object has three explicit POST transitions:

| Before | After | Native effect of this call |
|---|---|---|
| `root-prepared` | `root-committed` | Commit only the previously reserved signed root |
| `root-committed` | `bootstrap-prepared` | Validate and durably reserve exact signed bootstrap bytes; no bootstrap append |
| `bootstrap-prepared` | `complete` | Append only the reserved bootstrap change and verify native readback |

An editor block has one transition: `block-prepared` to `complete`.

Each receipt has `contract`, `intentId`, `storeId`, `accountId`, `spaceId`, `planId`, `planSHA256`, `sourceKey`, `kind`, `fingerprint`, `specSHA256`, `stage`, `outcome`, `objectId`, `changeId`, `recordIds`.

Kinds: `object`, `editorBlock`. Outcomes: `prepared`, `committed`, `committed_deleted`, `committed_modified`, `obsolete`. Incomplete stages are not acceptance. No-progress, obsolete, changed or deleted outcomes stop the executor.

Object `changeId` is the root CID through `root-committed`, then the reserved bootstrap CID through completion. Its record IDs are empty before bootstrap reservation, then exactly `[objectId]`. An editor block has exactly one native derived record ID; its reserved change and record IDs do not change on retry.

A lost acknowledgement requires status reconciliation. An already confirmed stage may advance to the next stage, but cannot recreate/re-sign its own bytes. Actual native raw history and current materialization determine the outcome; a host receipt never proves it.

## Native safety boundaries

The private prepared commit mode verifies signed CID/raw equality, current native writer, ACL/read-key envelope, predecessor heads, definition heads, live parent and native policy. Actual AddAll retains its original transaction and final current-ACL fence. Prepared appends require the production deferred updater configuration so projection callbacks run after storage.

Existing ordinary guard tokens cannot use the prepared raw mode. Incoming historical replay keeps its original mode. Files/payloads, plaintext-class carriers, snapshots and caller raw tokens are not admitted by this encrypted-object route.

Exact block retries compare actual native history and creation version/AddSeq, then current values. A later modification or tombstone is terminal. The object's own bootstrap comparison tolerates later body imports while checking its created property values/versions. A fully purged tree whose original raw history is no longer available is conservatively `obsolete`; the implementation does not fabricate a committed-deleted proof or recreate it.

## Evidence limits

Ledger tests use the real v2 database and opaque test envelopes; signed native append tests separately use real signed ACLs, native SQLite storage and encrypted changes. Clean SDK close/reopen is distinct from abrupt OS process kill or physical power-loss testing. The checkpoint source performs WAL and DB synchronization, but no physical-media survival claim is made.

The focused peer fixture uses two actual SDK instances, independent empty data directories and distinct device keys, with real loopback peer transport and virtual discovery only. Coordinator/node endpoints are unreachable. This can prove local P2P head delivery and ordinary receiver materialization; it does not prove WAN/coordinator, real mDNS, separate-process, Apple or physical-device behavior. A pass is only recorded when the fixture actually executes successfully.

Whole-Space snapshot consistency, complete source census/mapping, unsupported native schema or markup, files and a reviewed full archive plan remain independent migration gates.
