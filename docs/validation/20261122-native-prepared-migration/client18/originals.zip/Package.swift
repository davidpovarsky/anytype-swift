// swift-tools-version: 6.0
import PackageDescription
let package = Package(
 name: "PinkhaPreparedMigrationControls",
 dependencies: [
  .package(path: "Modules/PinkhaAnyHost"),
  .package(path: "C:/Users/DAVID/AppData/Local/Temp/pinkha-history-components-j1o7h7i6/Modules/PinkhaAnyEngine"),
  .package(path: "C:/Users/DAVID/AppData/Local/Temp/pinkha-history-components-j1o7h7i6/Modules/PinkhaAnyIntegration"),
  .package(path: "C:/Users/DAVID/AppData/Local/Temp/pinkha-history-components-j1o7h7i6/Modules/PinkhaKit")
 ],
 targets: [
  .testTarget(name: "PinkhaPreparedMigrationControls", dependencies: [
   .product(name: "PinkhaAnyHost", package: "PinkhaAnyHost"),
   .product(name: "PinkhaAnyIntegration", package: "PinkhaAnyIntegration"),
   .product(name: "PinkhaAnyEngine", package: "PinkhaAnyEngine"),
   .product(name: "PinkhaKit", package: "PinkhaKit")
  ])
 ]
)
