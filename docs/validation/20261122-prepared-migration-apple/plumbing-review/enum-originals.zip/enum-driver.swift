let expected = CommandLine.arguments[1]
let prefix = CommandLine.arguments[2]
precondition(AnyEmbeddedBuild.linked.rawValue == expected)
precondition(AnyEmbeddedBuild.linked.versionPrefix == prefix)
print(AnyEmbeddedBuild.linked.rawValue)
print(AnyEmbeddedBuild.linked.versionPrefix)
