// swift-tools-version: 6.0
import PackageDescription
let package = Package(
 name: "PinkhaHistoryPortableControls",
 dependencies: [
  .package(path: "Modules/PinkhaAnyHost"), .package(path: "Modules/PinkhaAnyEngine"),
  .package(path: "Modules/PinkhaAnyIntegration"), .package(path: "Modules/PinkhaKit")
 ],
 targets: [
  .target(name: "PinkhaAnyUI", dependencies: [
   .product(name: "PinkhaAnyHost", package: "PinkhaAnyHost"),
   .product(name: "PinkhaAnyEngine", package: "PinkhaAnyEngine"),
   .product(name: "PinkhaAnyIntegration", package: "PinkhaAnyIntegration"),
   .product(name: "PinkhaKit", package: "PinkhaKit")
  ]),
  .testTarget(name: "PinkhaHistoryControls", dependencies: [
   "PinkhaAnyUI", .product(name: "PinkhaAnyHost", package: "PinkhaAnyHost"),
   .product(name: "PinkhaAnyEngine", package: "PinkhaAnyEngine"),
   .product(name: "PinkhaAnyIntegration", package: "PinkhaAnyIntegration"),
   .product(name: "PinkhaKit", package: "PinkhaKit")
  ])
 ])
