module pinkha.invalid/metadata-reverification

go 1.27.4

require (
	github.com/kballard/go-shellquote v0.0.0-20180428030007-95032a82bc51
	lukechampine.com/uint128 v1.2.0
	modernc.org/cc/v3 v3.41.0
	modernc.org/ccgo/v3 v3.17.0
	modernc.org/ccorpus2 v1.5.4
	modernc.org/lex v1.1.1
	modernc.org/lexer v1.0.4
	modernc.org/scannertest v1.0.2
)
