#!/usr/bin/env python3
"""Run one finite Properties regression phase in the handed-off component cache."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path('/var/lib/pinkha-wave2-property-lifecycle-20261127')
SHARED = Path('/var/lib/pinkha-wave2-native-block-menu-20261127')
COMPONENT = SHARED / 'component'
INPUTS = ROOT / 'inputs'
HANDOFF = SHARED / 'attempt1/cache-handoff.json'
HANDOFF_SHA = '493a7d628bdce5642f54b3b3f99deedfe24b28f6d8e68267c18c7629f227367b'
ORIGINAL_RESULT_SHA = 'bbf101c3821fafca51f6d6e9a0bef009f1f415ff935ab4e2606ca0feb599e231'
MODEL_SHA = 'aa40239c5ba749b20974735337c0af11ba477c9aac870261f4ae5ae76f76c731'
TEST_SHA = '7df1a45aa85cd71bc7ec8353b98150609bc2d2fb07a2aa1ebf08f7fb40fdab61'
BASELINE_SHA = 'c5935470e1c515461ad11b764e0169297eeb645a3ba4a522d0a7111070437dfb'
PREPARE_SHA = 'ef7b3195584ee599737ec86cef5da49bff1946f2fc0bc0a4d491915f1a829cff'
NEW_METHODS = ['currentReadFailureDiscardsDisplayedValuesAndUndoUntilReviewed',
               'deactivationDiscardsDisplayedValuesAndUndoBeforeNewOwnerRead']


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def group_members(pgid):
    rows = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            stat = (p / 'stat').read_text()
            fields = stat[stat.rindex(')') + 2:].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                rows.append(int(p.name))
        except (OSError, ValueError, IndexError):
            pass
    return sorted(rows)


def resource_sample():
    memory = {line.split(':', 1)[0]: int(line.split()[1]) * 1024
              for line in Path('/proc/meminfo').read_text().splitlines()
              if line.startswith(('MemAvailable:', 'SwapFree:'))}
    return {'atUTC': now(), 'freeBytes': shutil.disk_usage(SHARED).free,
            'memAvailableBytes': memory['MemAvailable'],
            'swapFreeBytes': memory['SwapFree'], 'load': os.getloadavg()}


def pinned_inputs(handoff):
    for name, expected in [('AnyNativePropertyPresentation.swift', MODEL_SHA),
                           ('AnyNativePropertyPresentation.original.swift', BASELINE_SHA),
                           ('AnyNativePropertyPresentationTests.swift', TEST_SHA),
                           ('prepare_component_sources.py', PREPARE_SHA)]:
        assert sha((INPUTS / name).read_bytes()) == expected, name
    original = SHARED / 'attempt1/receipt.json'
    assert sha(original.read_bytes()) == ORIGINAL_RESULT_SHA
    for row in handoff['originalComponentSourceCopies']:
        assert sha((COMPONENT / row['path']).read_bytes()) == row['sha256'], row['path']
        assert sha((SHARED / 'attempt1/compiled-source' / row['path']).read_bytes()) == row['sha256'], row['path']
    original_deps = SHARED / 'attempt1/dependency-sources-after.json'
    closure = json.loads(original_deps.read_bytes())
    dependency_root = Path(handoff['sourceDependencyRoot']).parent
    for row in closure['files']:
        raw = (dependency_root / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    for checkout in handoff['completeDependencies']:
        args = ['git', '--no-optional-locks', '-C', checkout['path']]
        head = subprocess.run(args + ['rev-parse', 'HEAD'], check=True, capture_output=True, text=True).stdout.strip()
        dirty = subprocess.run(args + ['status', '--porcelain', '--untracked-files=no'], check=True, capture_output=True, text=True).stdout
        assert head == checkout['head'] and not dirty, checkout['path']
    return {'dependencyClosureSHA256': sha(original_deps.read_bytes()),
            'dependencySourceFiles': len(closure['files']),
            'componentResolvedSHA256': sha((COMPONENT / 'Package.resolved').read_bytes()),
            'originalAddBlockReceiptSHA256': ORIGINAL_RESULT_SHA,
            'originalAddBlockSourceAndResultsRetained': True}


def main():
    variant, attempt = sys.argv[1:]
    assert variant in ('baseline', 'fixed')
    assert re.fullmatch(r'[a-z]+[0-9]+', attempt)
    evidence = ROOT / attempt
    assert not evidence.exists(), 'Never replace an original phase'
    evidence.mkdir()
    started = time.monotonic()
    receipt = {'schema': 'pinkha.wave2.properties.actual-model-component.v1',
               'variant': variant, 'startedAtUTC': now(), 'status': 'FAIL',
               'runnerSHA256': sha(Path(__file__).read_bytes()),
               'AppleCompilation': 'NOT_RUN', 'UIAcceptance': 'NOT_RUN',
               'nativeAcceptance': 'NOT_RUN', 'nativeServiceCalls': 0,
               'shippingSourceMutationsByRunner': 0, 'originalAddBlockMethodsRerun': 0}
    process = None
    try:
        assert sha(HANDOFF.read_bytes()) == HANDOFF_SHA
        handoff = json.loads(HANDOFF.read_bytes())
        assert handoff['nextOwner'] == 'wave2-root-properties' and handoff['noOwnedProcessGroupRemains']
        old_process = json.loads((SHARED / 'attempt1/process.json').read_bytes())
        assert not group_members(old_process['processGroup'])
        # Only three small sources and their test binary are added to an already
        # compiled exact dependency cache. No full dependency rebuild is planned.
        admission = resource_sample()
        # This is a conservative incremental estimate, not a measured peak.
        # Keep the coordinated host's 2 GiB live disk floor and use one job.
        receipt['resourceAdmission'] = {**admission, 'incrementalAllowanceBytes': 256 * 1024**2,
            'liveDiskFloorBytes': 2 * 1024**3, 'minimumAvailableMemoryBytes': 1536 * 1024**2,
            'jobs': 1, 'allowanceIsEstimate': True}
        assert admission['freeBytes'] >= 2 * 1024**3 + 256 * 1024**2, 'Incremental allowance and coordinated live disk floor do not fit'
        assert admission['memAvailableBytes'] >= 1536 * 1024**2, 'Available memory below one-job component admission'
        before = pinned_inputs(handoff)
        write(evidence / 'dependency-and-custody-before.json', before)
        prepare = ['/usr/bin/python3', str(INPUTS / 'prepare_component_sources.py'),
                   '--inputs', str(INPUTS), '--output', str(COMPONENT), '--variant', variant]
        result = subprocess.run(prepare, check=True, capture_output=True, text=True)
        (evidence / 'prepare.original.log').write_text(result.stdout + result.stderr)
        envelope_path = COMPONENT / (variant + '-component-envelope.json')
        envelope = json.loads(envelope_path.read_bytes())
        shutil.copyfile(envelope_path, evidence / 'component-envelope.json')
        for relative, row in envelope['outputs'].items():
            raw = (COMPONENT / relative).read_bytes()
            assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
            target = evidence / 'compiled-source' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
        test_filter = '(' + '|'.join(NEW_METHODS) + ')' if variant == 'baseline' else 'AnyNativePropertyPresentationTests'
        argv = ['/usr/local/bin/swift', 'test', '--package-path', str(COMPONENT),
                '--scratch-path', handoff['scratchPath'], '--cache-path', handoff['cachePath'],
                '--jobs', '1', '--no-parallel', '--disable-experimental-prebuilts', '-v', '--filter', test_filter]
        environment = dict(os.environ)
        environment['CLANG_MODULE_CACHE_PATH'] = handoff['clangModuleCachePath']
        environment['GIT_TERMINAL_PROMPT'] = '0'
        write(evidence / 'invocation.json', {'argv': argv, 'timeoutSeconds': 300,
              'componentEnvelopeSHA256': sha(envelope_path.read_bytes()), 'startedAtUTC': now()})
        receipt['argv'] = argv
        with (evidence / 'stdout.original.log').open('wb') as stdout, (evidence / 'stderr.original.log').open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=COMPONENT, env=environment, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            write(evidence / 'process.json', {'pid': process.pid, 'processGroup': process.pid, 'startedAtUTC': now()})
            deadline = time.monotonic() + 300
            samples = []
            while process.poll() is None:
                sample = resource_sample()
                samples.append(sample)
                if sample['freeBytes'] < 2 * 1024**3 or sample['memAvailableBytes'] < 512 * 1024**2:
                    receipt['resourceStop'] = sample
                    break
                if time.monotonic() >= deadline:
                    receipt['timedOut'] = True
                    break
                try:
                    process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
            code = process.returncode
            samples.append(resource_sample())
            write(evidence / 'resource-samples.json', samples)
        receipt['processExit'] = code
        receipt['remainingOwnedProcessGroup'] = group_members(process.pid)
        assert not receipt['remainingOwnedProcessGroup'], 'Owned compiler process group has not drained'
        after = pinned_inputs(handoff)
        write(evidence / 'dependency-and-custody-after.json', after)
        assert after == before
        for relative, row in envelope['outputs'].items():
            assert sha((COMPONENT / relative).read_bytes()) == row['sha256']
        text = (evidence / 'stdout.original.log').read_text(errors='replace') + '\n' + (evidence / 'stderr.original.log').read_text(errors='replace')
        receipt['observedTestOutcomeLines'] = [line for line in text.splitlines()
            if (' Test ' in line and (' passed after ' in line or ' failed after ' in line)) or 'Test run with ' in line]
        assert not receipt.get('timedOut')
        assert not receipt.get('resourceStop')
        if variant == 'baseline':
            assert code != 0 and re.search(r'Test run with 2 tests in .* failed', text), 'Require actual two-method assertion failures, not a build failure or zero-test run'
            assert all(name + '() failed after ' in text for name in NEW_METHODS)
            receipt['status'] = 'REPRODUCED_TWO_REGRESSION_FAILURES_ON_ORIGINAL_MODEL'
        else:
            assert code == 0 and re.search(r'Test run with 9 tests in .* passed', text), 'All nine Properties methods must actually pass'
            assert all(name + '() passed after ' in text for name in NEW_METHODS)
            receipt['status'] = 'PASS_NINE_PROPERTIES_METHODS_COMPONENT_ONLY'
    except Exception:
        receipt['failure'] = traceback.format_exc()
    finally:
        receipt['finishedAtUTC'] = now()
        receipt['elapsedSeconds'] = round(time.monotonic() - started, 3)
        receipt['freeBytesAfter'] = shutil.disk_usage(SHARED).free
        receipt['artifacts'] = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in sorted(evidence.iterdir()) if p.is_file() and p.name != 'receipt.json']
        write(evidence / 'receipt.json', receipt)
        print(json.dumps({'status': receipt['status'], 'receipt': str(evidence / 'receipt.json'),
              'receiptSHA256': sha((evidence / 'receipt.json').read_bytes()),
              'processExit': receipt.get('processExit'), 'elapsedSeconds': receipt['elapsedSeconds'],
              'failure': receipt.get('failure', '')[-1800:]}), flush=True)
    raise SystemExit(1 if receipt['status'] == 'FAIL' else 0)


if __name__ == '__main__':
    main()
