module gobind

go 1.27.4

require golang.org/x/mobile v0.0.0-20260508232728-bebd421c7fa8
