# Bookmark6 complete source inputs

This is the source-only handoff for the six new Bookmark methods. It contains **82 complete production Swift files and two complete test files, totaling 980,531 bytes**, copied without edits from the exact published source or byte-equal retained originals. It contains no component Package, runner, stager, compiler output or runtime admission.

The plan is the sealed `wave2-bookmark6-execution-assessment/assessment.json` (`7ef169a2e90afc978208c0157a78f831c43d6c61ae774bff766def7ad396e3ab`) and its README (`6858b461262e3251c06035e6c5c67af4c5c38efbb1957ea12b8af6caa7a7a239`). The App source is published commit **3d2abbf8b1017204e2b93b53ea83ff6f053e67b3**, tree **2eca933c726346da539b378180f20da56cdef2a0**, whose sole parent is **2fcfecefaa3d99d63c47e34823d18a45e13f11f9**. The eight external Core files are the exact **26beca175d64a4d34e3567f2bbb4bf308d714478** TorahInspectorKit bodies; that pin is present in the actual published App Package primary response. The Package was inspected, not copied into or modified for this component.

## Materialized inputs

| Original module | Whole files | Swift bytes |
|---|---:|---:|
| TorahInspectorCore | 8 | 52,276 |
| PinkhaKit | 12 | 81,574 |
| PinkhaAnyEngine | 15 | 160,054 |
| PinkhaAnyIntegration | 19 | 194,036 |
| PinkhaAnyHost | 28 | 426,723 |
| **Production total** | **82** | **914,663** |
| PinkhaAnyHostTests | 1 | 20,663 |
| PinkhaAnyIntegrationTests | 1 | 45,205 |
| **Complete source total** | **84** | **980,531** |

The files are under `source/Sources/<module>/` and `source/Tests/<original test module>/`. Their flat component filenames follow the already assessed source layout; `whole-source-closure.json` preserves every original repository path, immutable commit, Git blob, byte count, SHA-256, local donor and primary binding. Copies are regular 0644 files. No declaration was extracted, protocol stub introduced, conditional compilation guard removed or source body rewritten. The original assessment, publication, Property4 inputs and hierarchy inputs remain unchanged.

Relative to the completed Property4 input set, this retains 73 production bodies, replaces four whole production files, and adds five whole production files. The full Property4 test remains in its original location and is absent from this new input set. Both Bookmark test files are included in full, rather than projected into a new suite.

## Source and primary provenance

`source-evidence.json` binds the actual published commit/parent responses and records 14 complete, independently recomputed Git tree objects. These give the current root-to-leaf identities for the selected Host and Integration files. The four changed production/test leaves in this closure also match their full published primary readbacks byte-for-byte.

The Engine and PinkhaKit module subtree hashes are unchanged between 2fc and 3d2. Their retained exact-2fc primary directories bind the selected Engine bodies and current Kit subdirectories. Each complete retained Hierarchy, Editor and Torah directory reconstructs its exact current Kit subtree hash. The separate immutable Kit26 Core primary directory binds all eight Core bodies. Six primary directory listings are recorded in total. Every copied body independently matches its expected SHA-256 and Git blob. The preparation reread 106 reused local inputs after copying and found their bytes unchanged.

No new remote fetch was needed. The evidence references the retained primary responses by exact path/hash and immutable URLs; it does not duplicate the 1.8 MB publication tree-response archive. The small initial read-only metadata-display parsing stop is retained in `inspection-stops.json`; it was not a source, compiler or test failure and occurred before the output directory was created.

## Six source-declared methods only

| Original target and suite | New method | Expected framework cases |
|---|---|---:|
| PinkhaAnyHostTests / NativeBookmarkPresentationTests | `testBookmarkCreationRetainsEmptyNameAndOneExactMappedURL` | 1 XCTest |
| Same | `testBookmarkCreationRefusesHiddenManagedAndChangedBindings` | 1 XCTest |
| Same | `testBookmarkCreationReadbackRequiresExactSourceAndOriginalIdentity` | 1 XCTest |
| Same | `testBookmarkCreationRefusesFramesOutsideTheSelectedBinding` | 1 XCTest |
| PinkhaAnyIntegrationTests / AnyHierarchyTests | `creationOverrideRejectsAnotherWorkspaceBeforeDispatch` | 1 Swift Testing |
| Same | `creationOverrideAndDefaultCreatorShareTheExistingMutationQueue` | 1 Swift Testing |

The Host file is exact `b80f20ccf77b4b0bb42043d18449f2b63d8001757e389a047011e6e3b43ba3b0`. Its original **10,518-byte, seven-method prefix** is byte-equal to the retained original. The new four methods contain 17 literal scenarios; those rows are not 17 enumerated XCTest cases.

The Integration file is exact `4274837b7e8176bc7f768149f842b31e56765716f5219c2a7e6412378c43e75c`. Its published **38,951-byte, 27-method prefix** remains exact, including the four separate rename methods/eight cases. The new Bookmark suffix contains two methods/two cases. The old seven Host methods and 27 Integration methods are not selected by this handoff. Whole-class filters would include unrelated work.

All six methods remain **NOT_RUN**. These are source declaration names, not compiled discovery IDs. Later execution preparation must preserve both original test targets and qualify positive results from both frameworks: four XCTest starts/passes and a four-test/zero-failure summary, plus two Swift Testing starts/passes and a two-test summary. Command exit zero or an empty framework footer cannot replace either set. No new generated-source count or compiled filter spelling is asserted here.

## Exact existing Crypto dependency

`dependency/retained-crypto-closure.json` is a byte-identical copy of the existing manifest, SHA-256 **10c98c4192acba640c401586fb84ef9aa227e6d52bdde7198f251a0498146c2c**. It describes **102 artifacts / 19,775,715 logical bytes**: four Swift import files, 94 retained headers/module maps, and four aggregated Products object files. No binary dependency was copied, refreshed or probed in this task. Current availability, physical source/alias identity and eventual isolated copy still require the original future admission checks.

The assessment's later execution boundary remains unchanged: preserve the original five production modules, use the original two test targets, and qualify the real final link so the exact four Crypto objects are included correctly. This source handoff creates no Package or linker flags. It also makes no resource-fit claim for the larger mixed-framework component; no limits, runtime window, upload or reservation were changed.

## Coverage boundary

The proposed six-method component addresses the actual Host binding/value/frame handling and the Integration creation queue through the existing controlled fixtures. It does not establish genuine native frame signatures, current account authorization, real Bookmark creation, protected-journal lifecycle, process-death rehydration, mounted UI behavior, Apple compilation or visual acceptance. The selected methods need no account or HTTP/native server, but that source feasibility is not an executed compiler/result claim. Editor retains the later execution-preparation ownership.
