import Foundation

public enum Anytype_Model_Block {
    public enum Content {
        public enum Text {
            public struct Marks: Equatable, Sendable {
                public var retainedFixtureMarks: [String] = []
                public init() {}
            }
        }
    }
}
public enum BlockText {
    public enum Style: Sendable, Equatable { case text, quote }
}
public enum Anytype_Rpc {
    public enum Block {
        public enum Split {
            public enum Request {
                public enum Mode: Sendable, Equatable { case fixture }
            }
        }
    }
}
enum ObjectHeaderEmptyUsecase: Hashable, Codable { case full }
enum ObjectHeaderExpectedLayout: Hashable, Codable { case fixture }
protocol InfoContainerProtocol: AnyObject, Sendable {}
final class FixtureInfo: InfoContainerProtocol {}
final class ObjectDetailsStorage: Sendable {}
struct BlockInformation: Sendable {}
struct ParsedProperties: Sendable {}
struct SpaceSyncStatus: Sendable {}
struct AnyPublisher<Output, Failure: Error>: Sendable {}
actor DocumentLifecycleProbe {
    private var operations: [String] = []
    func record(_ operation: String) { operations.append(operation) }
    func snapshot() -> [String] { operations }
}
final class DocumentProbe: BaseDocumentProtocol, @unchecked Sendable {
    let objectId: String
    let spaceId: String
    let mode: DocumentMode
    let isOpened: Bool
    let lifecycle: DocumentLifecycleProbe
    let infoContainer: any InfoContainerProtocol = FixtureInfo()
    let detailsStorage = ObjectDetailsStorage()
    var children: [BlockInformation] { [] }
    var parsedProperties: ParsedProperties { ParsedProperties() }
    var isLocked: Bool { false }
    var isEmpty: Bool { false }
    var details: ObjectDetails? { nil }
    var permissions: ObjectPermissions { ObjectPermissions() }
    var syncStatus: SpaceSyncStatus? { nil }
    var syncPublisher: AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    init(_ object: String = "object", space: String = "space", mode: DocumentMode = .handling,
         opened: Bool = true, lifecycle: DocumentLifecycleProbe = DocumentLifecycleProbe()) {
        objectId = object; spaceId = space; self.mode = mode; isOpened = opened; self.lifecycle = lifecycle
    }
    func subscibeFor(update: [BaseDocumentUpdate]) -> AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    @MainActor func open() async throws { await lifecycle.record("open") }
    @MainActor func update() async throws { await lifecycle.record("update") }
    @MainActor func close() async throws { await lifecycle.record("close") }
}
struct TextCall: Sendable {
    let operation: String
    let context: String
    let block: String
    var body: MiddlewareString?
    var payload: [String] = []
    var range: NSRange?
    var style: TextServiceProtocol.Style?
    var mode: TextServiceProtocol.SplitMode?
}
enum TextProbeFailure: Error, Equatable, Sendable { case deliberate, cancel }
actor TextProbe: TextServiceProtocol {
    let failure: TextProbeFailure?
    private var calls: [TextCall] = []
    init(failure: TextProbeFailure? = nil) { self.failure = failure }
    func snapshot() -> [TextCall] { calls }
    private func record(_ call: TextCall) throws {
        calls.append(call)
        if failure == .cancel { throw CancellationError() }
        if let failure { throw failure }
    }
    func setText(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try record(.init(operation: "text", context: contextId, block: blockId, body: middlewareString))
    }
    func setTextForced(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try record(.init(operation: "forced", context: contextId, block: blockId, body: middlewareString))
    }
    func setStyle(contextId: String, blockId: String, style: Style) async throws {
        try record(.init(operation: "style", context: contextId, block: blockId, style: style))
    }
    func split(contextId: String, blockId: String, range: NSRange, style: Style, mode: SplitMode) async throws -> String {
        try record(.init(operation: "split", context: contextId, block: blockId, range: range, style: style, mode: mode))
        return "injected-created-block"
    }
    func checked(contextId: String, blockId: String, newValue: Bool) async throws {
        try record(.init(operation: "checked", context: contextId, block: blockId, payload: [String(newValue)]))
    }
    func merge(contextId: String, firstBlockId: String, secondBlockId: String) async throws {
        try record(.init(operation: "merge", context: contextId, block: firstBlockId, payload: [secondBlockId]))
    }
    func setTextIcon(contextId: String, blockId: String, imageObjectId: String, emojiUnicode: String) async throws {
        try record(.init(operation: "icon", context: contextId, block: blockId, payload: [imageObjectId, emojiUnicode]))
    }
}
enum LocalEvent: Sendable {
    case general
    case setStyle(blockId: String)
    case setToggled(blockId: String)
    case setText(blockId: String, text: MiddlewareString)
    case setLoadingState(blockId: String)
}
actor EventProbe {
    static let shared = EventProbe()
    private var events: [[String]] = []
    private var detailed: [TextCall] = []
    func record(_ context: String, _ block: String) { events.append([context, block]) }
    func recordDetailed(_ call: TextCall) { detailed.append(call) }
    func snapshot() -> [[String]] { events }
    func detailedSnapshot() -> [TextCall] { detailed }
}
struct EventsBunch: Sendable {
    let contextId: String
    let localEvents: [LocalEvent]
    func send() async {
        for event in localEvents {
            let call: TextCall
            switch event {
            case .general: call = .init(operation: "general", context: contextId, block: "")
            case .setStyle(let block):
                await EventProbe.shared.record(contextId, block)
                call = .init(operation: "style", context: contextId, block: block)
            case .setToggled(let block): call = .init(operation: "toggle", context: contextId, block: block)
            case .setText(let block, let text): call = .init(operation: "text", context: contextId, block: block, body: text)
            case .setLoadingState(let block): call = .init(operation: "loading", context: contextId, block: block)
            }
            await EventProbe.shared.recordDetailed(call)
        }
    }
}
actor LocalPublisherProbe: EditorLocalEventPublishing {
    private var calls: [TextCall] = []
    let service: TextProbe?
    init(service: TextProbe? = nil) { self.service = service }
    func snapshot() -> [TextCall] { calls }
    func refresh(contextId: String) { calls.append(.init(operation: "general", context: contextId, block: "")) }
    func setStyle(contextId: String, blockId: String) async {
        let completed = await service?.snapshot().map(\.operation) ?? []
        calls.append(.init(operation: "style", context: contextId, block: blockId, payload: completed))
    }
    func setToggled(contextId: String, blockId: String) { calls.append(.init(operation: "toggle", context: contextId, block: blockId)) }
    func setText(contextId: String, blockId: String, text: MiddlewareString) {
        calls.append(.init(operation: "text", context: contextId, block: blockId, body: text))
    }
    func setLoadingState(contextId: String, blockId: String) {
        calls.append(.init(operation: "loading", context: contextId, block: blockId))
    }
}
protocol ObjectActionsServiceProtocol: AnyObject, Sendable {}
protocol BlockServiceProtocol: AnyObject, Sendable {}
protocol BookmarkServiceProtocol: AnyObject, Sendable {}
protocol FileActionsServiceProtocol: AnyObject, Sendable {}
protocol ObjectTypeProviderProtocol: AnyObject, Sendable {}
@MainActor protocol KeyboardInsertedBlocksStorageProtocol: AnyObject {}
final class ServiceMarker: ObjectActionsServiceProtocol, BlockServiceProtocol, BookmarkServiceProtocol,
    FileActionsServiceProtocol, ObjectTypeProviderProtocol, Sendable {
    let name: String
    init(_ name: String) { self.name = name }
}
@MainActor final class KeyboardMarker: KeyboardInsertedBlocksStorageProtocol {
    let name: String
    init(_ name: String) { self.name = name }
}
struct Container: Sendable {
    static let shared = Container()
    let nativeText = TextProbe()
    let nativeHandler: TextServiceHandler
    let object = ServiceMarker("original-object")
    let block = ServiceMarker("original-block")
    let bookmark = ServiceMarker("original-bookmark")
    let file = ServiceMarker("original-file")
    let types = ServiceMarker("original-types")
    @MainActor static let originalKeyboard = KeyboardMarker("original-keyboard")
    @MainActor var keyboard: KeyboardMarker { Self.originalKeyboard }
    init() { nativeHandler = TextServiceHandler(textService: nativeText) }
    func textService() -> any TextServiceProtocol { nativeText }
    func textServiceHandler() -> any TextServiceProtocol { nativeHandler }
    func objectActionsService() -> any ObjectActionsServiceProtocol { object }
    func blockService() -> any BlockServiceProtocol { block }
    func bookmarkService() -> any BookmarkServiceProtocol { bookmark }
    func fileActionsService() -> any FileActionsServiceProtocol { file }
    func objectTypeProvider() -> any ObjectTypeProviderProtocol { types }
    @MainActor func keyboardInsertedBlocksStorage() -> any KeyboardInsertedBlocksStorageProtocol { keyboard }
}
@MainActor protocol BlockActionServiceProtocol {}
@MainActor final class EditorMainItemModelsHolder {}
@MainActor final class EditorCursorManager {}
struct BoundaryCheck: Codable { let name: String; let passed: Bool }
@MainActor final class BoundaryChecks {
    private(set) var checks: [BoundaryCheck] = []
    func expect(_ condition: Bool, _ name: String) { checks.append(.init(name: name, passed: condition)) }
    func validate(_ name: String, data: EditorPageObject, document: DocumentProbe,
                  expected: PreparedEditorPageDocumentError? = nil) {
        do {
            try PreparedEditorPageDocument.validate(data: data, document: document)
            expect(expected == nil, name)
        } catch {
            expect((error as? PreparedEditorPageDocumentError) == expected && expected != nil, name)
        }
    }
}
enum BoundaryFixtureError: Error { case failed }
import Foundation

final class OwnershipDocumentProbe: BaseDocumentProtocol, @unchecked Sendable {
    private struct State {
        var object: String
        var space: String
        var mode: DocumentMode
        var opened = true
        var locked = false
        var editable = true
    }
    private let lock = NSLock()
    private var state: State
    let lifecycle = DocumentLifecycleProbe()
    let infoContainer: any InfoContainerProtocol = FixtureInfo()
    let detailsStorage = ObjectDetailsStorage()
    init(object: String = "owned", space: String = "owned-space", mode: DocumentMode = .handling) {
        state = State(object: object, space: space, mode: mode)
    }
    private func read<Value>(_ body: (State) -> Value) -> Value {
        lock.lock(); defer { lock.unlock() }; return body(state)
    }
    func change(object: String? = nil, space: String? = nil, mode: DocumentMode? = nil,
                opened: Bool? = nil, locked: Bool? = nil, editable: Bool? = nil) {
        lock.lock(); defer { lock.unlock() }
        if let object { state.object = object }
        if let space { state.space = space }
        if let mode { state.mode = mode }
        if let opened { state.opened = opened }
        if let locked { state.locked = locked }
        if let editable { state.editable = editable }
    }
    var objectId: String { read { $0.object } }
    var spaceId: String { read { $0.space } }
    var mode: DocumentMode { read { $0.mode } }
    var isOpened: Bool { read { $0.opened } }
    var isLocked: Bool { read { $0.locked } }
    var permissions: ObjectPermissions { read { state in
        var value = ObjectPermissions(); value.canEditBlocks = state.editable; return value
    } }
    var children: [BlockInformation] { [] }
    var parsedProperties: ParsedProperties { ParsedProperties() }
    var isEmpty: Bool { false }
    var details: ObjectDetails? { nil }
    var syncStatus: SpaceSyncStatus? { nil }
    var syncPublisher: AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    func subscibeFor(update: [BaseDocumentUpdate]) -> AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    @MainActor func open() async throws { await lifecycle.record("open") }
    @MainActor func update() async throws { await lifecycle.record("update") }
    @MainActor func close() async throws { await lifecycle.record("close") }
}

actor OwnershipGate {
    private var entered = false
    private var released = false
    private var waiters: [CheckedContinuation<Void, Never>] = []
    private var pending: [CheckedContinuation<Void, Never>] = []
    func hold() async {
        entered = true
        let notices = waiters; waiters = []
        for notice in notices { notice.resume() }
        if !released { await withCheckedContinuation { pending.append($0) } }
    }
    func waitForEntry() async {
        if entered { return }
        await withCheckedContinuation { waiters.append($0) }
    }
    func release() {
        released = true
        let values = pending; pending = []
        for value in values { value.resume() }
    }
}

final class HeldOwnershipTextService: TextServiceProtocol {
    let gate: OwnershipGate
    let target: TextProbe
    init(gate: OwnershipGate, target: TextProbe) { self.gate = gate; self.target = target }
    func setText(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        await gate.hold()
        try await target.setText(contextId: contextId, blockId: blockId, middlewareString: middlewareString)
    }
    func setTextForced(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try await target.setTextForced(contextId: contextId, blockId: blockId, middlewareString: middlewareString)
    }
    func setStyle(contextId: String, blockId: String, style: Style) async throws {
        try await target.setStyle(contextId: contextId, blockId: blockId, style: style)
    }
    func split(contextId: String, blockId: String, range: NSRange, style: Style, mode: SplitMode) async throws -> String {
        try await target.split(contextId: contextId, blockId: blockId, range: range, style: style, mode: mode)
    }
    func merge(contextId: String, firstBlockId: String, secondBlockId: String) async throws {
        try await target.merge(contextId: contextId, firstBlockId: firstBlockId, secondBlockId: secondBlockId)
    }
    func checked(contextId: String, blockId: String, newValue: Bool) async throws {
        try await target.checked(contextId: contextId, blockId: blockId, newValue: newValue)
    }
    func setTextIcon(contextId: String, blockId: String, imageObjectId: String, emojiUnicode: String) async throws {
        try await target.setTextIcon(contextId: contextId, blockId: blockId, imageObjectId: imageObjectId, emojiUnicode: emojiUnicode)
    }
}

struct HeldOwnershipPublication: EditorLocalEventPublishing {
    let gate: OwnershipGate
    let target: LocalPublisherProbe
    func setStyle(contextId: String, blockId: String) async {
        await gate.hold()
        await target.setStyle(contextId: contextId, blockId: blockId)
    }
    func refresh(contextId: String) async { await target.refresh(contextId: contextId) }
    func setToggled(contextId: String, blockId: String) async { await target.setToggled(contextId: contextId, blockId: blockId) }
    func setText(contextId: String, blockId: String, text: MiddlewareString) async {
        await target.setText(contextId: contextId, blockId: blockId, text: text)
    }
    func setLoadingState(contextId: String, blockId: String) async {
        await target.setLoadingState(contextId: contextId, blockId: blockId)
    }
}

@MainActor
private func ownershipData(_ document: OwnershipDocumentProbe) -> EditorPageObject {
    .init(objectId: document.objectId, spaceId: document.spaceId, mode: document.mode)
}

@MainActor
private func ownerFailure(_ operation: () async throws -> Void) async -> EditorDocumentWriteError? {
    do { try await operation(); return nil }
    catch { return error as? EditorDocumentWriteError }
}


extension String { var isNotEmpty: Bool { !isEmpty } }
enum ObjectRestriction: Sendable { case typeChange, delete, duplicate, template, details, relations, blocks }
struct PermissionLayout: Sendable {
    let isFileOrMedia = false, isChat = false, isList = false, isParticipant = false
    let haveIcon = true, haveCover = true, isEditorLayout = true
}
struct ObjectDetails: Sendable {
    var id: String = ""
    var isArchived = false
    var isTemplate = false
    var isObjectType = false
    var canMakeTemplate = true
    var resolvedLayoutValue = PermissionLayout()
}
final class CallbackRecorder: @unchecked Sendable {
    private let lock = NSLock()
    private var count = 0
    func add() { lock.lock(); count += 1; lock.unlock() }
    var value: Int { lock.lock(); defer { lock.unlock() }; return count }
}
@MainActor
struct BlockActionHandlerDependencies {
    let blockService: any BlockServiceProtocol
    let blockTableService: any BlockTableServiceProtocol
    let fileService: any FileActionsServiceProtocol
    let objectService: any ObjectActionsServiceProtocol
    let pasteboardBlockService: any PasteboardBlockServiceProtocol
    let bookmarkService: any BookmarkServiceProtocol
    let objectTypeProvider: any ObjectTypeProviderProtocol
}

@MainActor
struct KeyboardActionHandlerDependencies {
    let blockService: any BlockServiceProtocol
    let keyboardInsertedBlocksStorage: any KeyboardInsertedBlocksStorageProtocol
}

@MainActor
struct EditorPageBlocksStateManagerDependencies {
    let blockService: any BlockServiceProtocol
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let documentsProvider: any DocumentsProviderProtocol
    let objectActionsService: any ObjectActionsServiceProtocol
    let toastPresenter: any ToastPresenterProtocol
}

@MainActor
struct BlockViewModelBuilderDependencies {
    let tableService: any BlockTableServiceProtocol
    let detailsService: any DetailsServiceProtocol
    let audioSessionService: any AudioSessionServiceProtocol
    let objectTypeProvider: any ObjectTypeProviderProtocol
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let blockService: any BlockServiceProtocol
}

@MainActor
struct SimpleTableServiceDependencies {
    let tableService: any BlockTableServiceProtocol
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let defaultObjectService: any DefaultObjectCreationServiceProtocol
    let typesService: any TypesServiceProtocol
}

@MainActor
struct SlashMenuActionHandlerDependencies {
    let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    let objectDateByTimestampService: any ObjectDateByTimestampServiceProtocol
}

@MainActor
struct ObjectHeaderViewModelDependencies {
    let objectHeaderUploadingService: any ObjectHeaderUploadingServiceProtocol
}

@MainActor
struct EditorRouterDependencies {
    let navigationContext: any NavigationContextProtocol
    let templatesCoordinator: any TemplatesCoordinatorProtocol
    let setObjectCreationSettingsCoordinator: any SetObjectCreationSettingsCoordinatorProtocol
    let toastPresenter: any ToastPresenterProtocol
    let templateService: any TemplatesServiceProtocol
}

@MainActor
struct EditorPageViewModelDependencies {
    let objectActionsService: any ObjectActionsServiceProtocol
    let objectTypeProvider: any ObjectTypeProviderProtocol
    let searchService: any SearchServiceProtocol
    let templatesSubscriptionService: any TemplatesSubscriptionServiceProtocol
    let accountManager: any AccountManagerProtocol
    let publishingService: any PublishingServiceProtocol
    let participantStorage: any ParticipantsStorageProtocol
    let publishedUrlBuilder: any PublishedUrlBuilderProtocol
    let keyboardInsertedBlocksStorage: any KeyboardInsertedBlocksStorageProtocol
    let blockService: any BlockServiceProtocol
}
@MainActor protocol AccountManagerProtocol: AnyObject {}
@MainActor protocol AudioSessionServiceProtocol: AnyObject {}
@MainActor protocol BlockTableServiceProtocol: AnyObject {}
@MainActor protocol DefaultObjectCreationServiceProtocol: AnyObject {}
@MainActor protocol DetailsServiceProtocol: AnyObject {}
@MainActor protocol DocumentsProviderProtocol: AnyObject {}
@MainActor protocol NavigationContextProtocol: AnyObject {}
@MainActor protocol ObjectDateByTimestampServiceProtocol: AnyObject {}
@MainActor protocol ObjectHeaderUploadingServiceProtocol: AnyObject {}
@MainActor protocol ParticipantsStorageProtocol: AnyObject {}
@MainActor protocol PasteboardBlockDocumentServiceProtocol: AnyObject {}
@MainActor protocol PasteboardBlockServiceProtocol: AnyObject {}
@MainActor protocol PublishedUrlBuilderProtocol: AnyObject {}
@MainActor protocol PublishingServiceProtocol: AnyObject {}
@MainActor protocol SearchServiceProtocol: AnyObject {}
@MainActor protocol SetObjectCreationSettingsCoordinatorProtocol: AnyObject {}
@MainActor protocol TemplatesCoordinatorProtocol: AnyObject {}
@MainActor protocol TemplatesServiceProtocol: AnyObject {}
@MainActor protocol TemplatesSubscriptionServiceProtocol: AnyObject {}
@MainActor protocol ToastPresenterProtocol: AnyObject {}
@MainActor protocol TypesServiceProtocol: AnyObject {}
@MainActor final class LifetimeServiceMarker: AccountManagerProtocol, AudioSessionServiceProtocol, BlockServiceProtocol, BlockTableServiceProtocol, BookmarkServiceProtocol, DefaultObjectCreationServiceProtocol, DetailsServiceProtocol, DocumentsProviderProtocol, FileActionsServiceProtocol, KeyboardInsertedBlocksStorageProtocol, NavigationContextProtocol, ObjectActionsServiceProtocol, ObjectDateByTimestampServiceProtocol, ObjectHeaderUploadingServiceProtocol, ObjectTypeProviderProtocol, ParticipantsStorageProtocol, PasteboardBlockDocumentServiceProtocol, PasteboardBlockServiceProtocol, PublishedUrlBuilderProtocol, PublishingServiceProtocol, SearchServiceProtocol, SetObjectCreationSettingsCoordinatorProtocol, TemplatesCoordinatorProtocol, TemplatesServiceProtocol, TemplatesSubscriptionServiceProtocol, ToastPresenterProtocol, TypesServiceProtocol {}
@MainActor let fixtureMarker = LifetimeServiceMarker()
@MainActor func fixtureServices(events: any EditorLocalEventPublishing) -> EditorPageServiceDependencies {
    .init(
        blockActionService: .init(objectActionService: fixtureMarker, textServiceHandler: TextProbe(), blockService: fixtureMarker, bookmarkService: fixtureMarker, fileService: fixtureMarker, objectTypeProvider: fixtureMarker, keyboardInsertedBlocksStorage: fixtureMarker),
        blockActionHandler: .init(blockService: fixtureMarker, blockTableService: fixtureMarker, fileService: fixtureMarker, objectService: fixtureMarker, pasteboardBlockService: fixtureMarker, bookmarkService: fixtureMarker, objectTypeProvider: fixtureMarker),
        keyboardHandler: .init(blockService: fixtureMarker, keyboardInsertedBlocksStorage: fixtureMarker),
        blocksStateManager: .init(blockService: fixtureMarker, pasteboardService: fixtureMarker, documentsProvider: fixtureMarker, objectActionsService: fixtureMarker, toastPresenter: fixtureMarker),
        blockBuilder: .init(tableService: fixtureMarker, detailsService: fixtureMarker, audioSessionService: fixtureMarker, objectTypeProvider: fixtureMarker, pasteboardService: fixtureMarker, blockService: fixtureMarker),
        simpleTable: .init(tableService: fixtureMarker, pasteboardService: fixtureMarker, defaultObjectService: fixtureMarker, typesService: fixtureMarker),
        slashMenu: .init(pasteboardService: fixtureMarker, objectDateByTimestampService: fixtureMarker),
        header: .init(objectHeaderUploadingService: fixtureMarker),
        router: .init(navigationContext: fixtureMarker, templatesCoordinator: fixtureMarker, setObjectCreationSettingsCoordinator: fixtureMarker, toastPresenter: fixtureMarker, templateService: fixtureMarker),
        viewModel: .init(objectActionsService: fixtureMarker, objectTypeProvider: fixtureMarker, searchService: fixtureMarker, templatesSubscriptionService: fixtureMarker, accountManager: fixtureMarker, publishingService: fixtureMarker, participantStorage: fixtureMarker, publishedUrlBuilder: fixtureMarker, keyboardInsertedBlocksStorage: fixtureMarker, blockService: fixtureMarker),
        localEvents: events
    )
}
