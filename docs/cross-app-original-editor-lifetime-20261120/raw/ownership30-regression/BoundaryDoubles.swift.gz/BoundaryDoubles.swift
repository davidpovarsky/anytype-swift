import Foundation

public enum Anytype_Model_Block {
    public enum Content {
        public enum Text {
            public struct Marks: Equatable, Sendable {
                public var retainedFixtureMarks: [String] = []
                public init() {}
            }
        }
    }
}
public enum BlockText {
    public enum Style: Sendable, Equatable { case text, quote }
}
public enum Anytype_Rpc {
    public enum Block {
        public enum Split {
            public enum Request {
                public enum Mode: Sendable, Equatable { case fixture }
            }
        }
    }
}
enum ObjectHeaderEmptyUsecase: Hashable, Codable { case full }
enum ObjectHeaderExpectedLayout: Hashable, Codable { case fixture }
protocol InfoContainerProtocol: AnyObject, Sendable {}
final class FixtureInfo: InfoContainerProtocol {}
final class ObjectDetailsStorage: Sendable {}
struct BlockInformation: Sendable {}
struct ParsedProperties: Sendable {}
struct ObjectDetails: Sendable {}
struct SpaceSyncStatus: Sendable {}
enum BaseDocumentUpdate: Sendable { case fixture }
struct AnyPublisher<Output, Failure: Error>: Sendable {}
actor DocumentLifecycleProbe {
    private var operations: [String] = []
    func record(_ operation: String) { operations.append(operation) }
    func snapshot() -> [String] { operations }
}
final class DocumentProbe: BaseDocumentProtocol, @unchecked Sendable {
    let objectId: String
    let spaceId: String
    let mode: DocumentMode
    let isOpened: Bool
    let lifecycle: DocumentLifecycleProbe
    let infoContainer: any InfoContainerProtocol = FixtureInfo()
    let detailsStorage = ObjectDetailsStorage()
    var children: [BlockInformation] { [] }
    var parsedProperties: ParsedProperties { ParsedProperties() }
    var isLocked: Bool { false }
    var isEmpty: Bool { false }
    var details: ObjectDetails? { nil }
    var permissions: ObjectPermissions { ObjectPermissions() }
    var syncStatus: SpaceSyncStatus? { nil }
    var syncPublisher: AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    init(_ object: String = "object", space: String = "space", mode: DocumentMode = .handling,
         opened: Bool = true, lifecycle: DocumentLifecycleProbe = DocumentLifecycleProbe()) {
        objectId = object; spaceId = space; self.mode = mode; isOpened = opened; self.lifecycle = lifecycle
    }
    func subscibeFor(update: [BaseDocumentUpdate]) -> AnyPublisher<[BaseDocumentUpdate], Never> { AnyPublisher() }
    @MainActor func open() async throws { await lifecycle.record("open") }
    @MainActor func update() async throws { await lifecycle.record("update") }
    @MainActor func close() async throws { await lifecycle.record("close") }
}
struct TextCall: Sendable {
    let operation: String
    let context: String
    let block: String
    var body: MiddlewareString?
    var payload: [String] = []
    var range: NSRange?
    var style: TextServiceProtocol.Style?
    var mode: TextServiceProtocol.SplitMode?
}
enum TextProbeFailure: Error, Equatable, Sendable { case deliberate, cancel }
actor TextProbe: TextServiceProtocol {
    let failure: TextProbeFailure?
    private var calls: [TextCall] = []
    init(failure: TextProbeFailure? = nil) { self.failure = failure }
    func snapshot() -> [TextCall] { calls }
    private func record(_ call: TextCall) throws {
        calls.append(call)
        if failure == .cancel { throw CancellationError() }
        if let failure { throw failure }
    }
    func setText(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try record(.init(operation: "text", context: contextId, block: blockId, body: middlewareString))
    }
    func setTextForced(contextId: String, blockId: String, middlewareString: MiddlewareString) async throws {
        try record(.init(operation: "forced", context: contextId, block: blockId, body: middlewareString))
    }
    func setStyle(contextId: String, blockId: String, style: Style) async throws {
        try record(.init(operation: "style", context: contextId, block: blockId, style: style))
    }
    func split(contextId: String, blockId: String, range: NSRange, style: Style, mode: SplitMode) async throws -> String {
        try record(.init(operation: "split", context: contextId, block: blockId, range: range, style: style, mode: mode))
        return "injected-created-block"
    }
    func checked(contextId: String, blockId: String, newValue: Bool) async throws {
        try record(.init(operation: "checked", context: contextId, block: blockId, payload: [String(newValue)]))
    }
    func merge(contextId: String, firstBlockId: String, secondBlockId: String) async throws {
        try record(.init(operation: "merge", context: contextId, block: firstBlockId, payload: [secondBlockId]))
    }
    func setTextIcon(contextId: String, blockId: String, imageObjectId: String, emojiUnicode: String) async throws {
        try record(.init(operation: "icon", context: contextId, block: blockId, payload: [imageObjectId, emojiUnicode]))
    }
}
enum LocalEvent: Sendable {
    case general
    case setStyle(blockId: String)
    case setToggled(blockId: String)
    case setText(blockId: String, text: MiddlewareString)
    case setLoadingState(blockId: String)
}
actor EventProbe {
    static let shared = EventProbe()
    private var events: [[String]] = []
    private var detailed: [TextCall] = []
    func record(_ context: String, _ block: String) { events.append([context, block]) }
    func recordDetailed(_ call: TextCall) { detailed.append(call) }
    func snapshot() -> [[String]] { events }
    func detailedSnapshot() -> [TextCall] { detailed }
}
struct EventsBunch: Sendable {
    let contextId: String
    let localEvents: [LocalEvent]
    func send() async {
        for event in localEvents {
            let call: TextCall
            switch event {
            case .general: call = .init(operation: "general", context: contextId, block: "")
            case .setStyle(let block):
                await EventProbe.shared.record(contextId, block)
                call = .init(operation: "style", context: contextId, block: block)
            case .setToggled(let block): call = .init(operation: "toggle", context: contextId, block: block)
            case .setText(let block, let text): call = .init(operation: "text", context: contextId, block: block, body: text)
            case .setLoadingState(let block): call = .init(operation: "loading", context: contextId, block: block)
            }
            await EventProbe.shared.recordDetailed(call)
        }
    }
}
actor LocalPublisherProbe: EditorLocalEventPublishing {
    private var calls: [TextCall] = []
    let service: TextProbe?
    init(service: TextProbe? = nil) { self.service = service }
    func snapshot() -> [TextCall] { calls }
    func refresh(contextId: String) { calls.append(.init(operation: "general", context: contextId, block: "")) }
    func setStyle(contextId: String, blockId: String) async {
        let completed = await service?.snapshot().map(\.operation) ?? []
        calls.append(.init(operation: "style", context: contextId, block: blockId, payload: completed))
    }
    func setToggled(contextId: String, blockId: String) { calls.append(.init(operation: "toggle", context: contextId, block: blockId)) }
    func setText(contextId: String, blockId: String, text: MiddlewareString) {
        calls.append(.init(operation: "text", context: contextId, block: blockId, body: text))
    }
    func setLoadingState(contextId: String, blockId: String) {
        calls.append(.init(operation: "loading", context: contextId, block: blockId))
    }
}
protocol ObjectActionsServiceProtocol: AnyObject, Sendable {}
protocol BlockServiceProtocol: AnyObject, Sendable {}
protocol BookmarkServiceProtocol: AnyObject, Sendable {}
protocol FileActionsServiceProtocol: AnyObject, Sendable {}
protocol ObjectTypeProviderProtocol: AnyObject, Sendable {}
@MainActor protocol KeyboardInsertedBlocksStorageProtocol: AnyObject {}
final class ServiceMarker: ObjectActionsServiceProtocol, BlockServiceProtocol, BookmarkServiceProtocol,
    FileActionsServiceProtocol, ObjectTypeProviderProtocol, Sendable {
    let name: String
    init(_ name: String) { self.name = name }
}
@MainActor final class KeyboardMarker: KeyboardInsertedBlocksStorageProtocol {
    let name: String
    init(_ name: String) { self.name = name }
}
struct Container: Sendable {
    static let shared = Container()
    let nativeText = TextProbe()
    let nativeHandler: TextServiceHandler
    let object = ServiceMarker("original-object")
    let block = ServiceMarker("original-block")
    let bookmark = ServiceMarker("original-bookmark")
    let file = ServiceMarker("original-file")
    let types = ServiceMarker("original-types")
    @MainActor static let originalKeyboard = KeyboardMarker("original-keyboard")
    @MainActor var keyboard: KeyboardMarker { Self.originalKeyboard }
    init() { nativeHandler = TextServiceHandler(textService: nativeText) }
    func textService() -> any TextServiceProtocol { nativeText }
    func textServiceHandler() -> any TextServiceProtocol { nativeHandler }
    func objectActionsService() -> any ObjectActionsServiceProtocol { object }
    func blockService() -> any BlockServiceProtocol { block }
    func bookmarkService() -> any BookmarkServiceProtocol { bookmark }
    func fileActionsService() -> any FileActionsServiceProtocol { file }
    func objectTypeProvider() -> any ObjectTypeProviderProtocol { types }
    @MainActor func keyboardInsertedBlocksStorage() -> any KeyboardInsertedBlocksStorageProtocol { keyboard }
}
@MainActor protocol BlockActionServiceProtocol {}
@MainActor final class EditorMainItemModelsHolder {}
@MainActor final class EditorCursorManager {}
struct BoundaryCheck: Codable { let name: String; let passed: Bool }
@MainActor final class BoundaryChecks {
    private(set) var checks: [BoundaryCheck] = []
    func expect(_ condition: Bool, _ name: String) { checks.append(.init(name: name, passed: condition)) }
    func validate(_ name: String, data: EditorPageObject, document: DocumentProbe,
                  expected: PreparedEditorPageDocumentError? = nil) {
        do {
            try PreparedEditorPageDocument.validate(data: data, document: document)
            expect(expected == nil, name)
        } catch {
            expect((error as? PreparedEditorPageDocumentError) == expected && expected != nil, name)
        }
    }
}
enum BoundaryFixtureError: Error { case failed }
