import Foundation

// Explicit disposable document model for exercising the actual production
// owner/lifetime code on a non-Apple host. This is not an editor or a backend.
enum DocumentMode: Equatable, Sendable {
    case handling
    case preview
    case version(String)
}

struct EditorPageObject: Sendable {
    let objectId: String
    let spaceId: String
    let mode: DocumentMode
}

// Explicit minimal details values consumed by the unchanged original permission evaluator.
// These are portable value inputs, not a backend document or an editor implementation.
enum ObjectRestriction: Sendable { case typeChange, delete, duplicate, template, details, relations, blocks }
struct PermissionLayout: Sendable {
    let isFileOrMedia = false, isList = false, isParticipant = false, isChat = false
    let haveIcon = true, haveCover = false, isEditorLayout = false
}
struct ObjectDetails: Sendable {
    let isArchived = false, isTemplate = false, isObjectType = true, canMakeTemplate = false
    let resolvedLayoutValue = PermissionLayout()
    let restrictionsValue: [ObjectRestriction]
}

enum BlocksReadonlyReason: Equatable {
    case locked
    case archived
    case spaceIsReadonly
    case restrictions
}

enum EditBlocksPermission: Equatable {
    case edit
    case readonly(BlocksReadonlyReason)
}

extension EditBlocksPermission {
    var canEdit: Bool {
        switch self {
        case .edit:
            return true
        case .readonly:
            return false
        }
    }
}

extension BlocksReadonlyReason: Sendable {}
extension EditBlocksPermission: Sendable {}

struct ObjectPermissions: Equatable {
    var canChangeType: Bool = false
    var canDelete: Bool = false
    var canRestore: Bool = false
    var canTemplateSetAsDefault: Bool = false
    var canArchive: Bool = false
    var canDuplicate: Bool = false
    var canUndoRedo: Bool = false
    var canMakeAsTemplate: Bool = false
    var canFavorite: Bool = false
    var canLinkItself: Bool = false
    var canLock: Bool = false
    var canChangeIcon: Bool = false
    var canChangeCover: Bool = false
    var canChangeLayout: Bool = false
    var canEditRelationValues: Bool = false
    var canEditPropertiesList: Bool = false
    var canApplyTemplates: Bool = false
    var canShare: Bool = false
    var canPublish: Bool = false
    var canEditBlocks: Bool = false
    var canEditMessages: Bool = false
    var canRestoreVersionHistory: Bool = false
    var canEditDetails: Bool = false
    var canShowRelations: Bool = false
    var canToggleDescription: Bool = false
    var canApplyUneditableActions: Bool = false
    var editBlocks: EditBlocksPermission = .readonly(.restrictions)
}

extension ObjectPermissions {
    init(
        details: ObjectDetails,
        isLocked: Bool,
        participantCanEdit: Bool,
        isVersionMode: Bool,
        objectRestrictions: [ObjectRestriction]
    ) {
        let isArchive = details.isArchived
        let isTemplate = details.isTemplate
        let isObjectType = details.isObjectType
        
        let canEditRelations = !isLocked && !isArchive && participantCanEdit && !isVersionMode
        let canEdit = canEditRelations && !details.resolvedLayoutValue.isFileOrMedia
        
        let isChat = details.resolvedLayoutValue.isChat
        let specificTypes = !details.resolvedLayoutValue.isList && !details.resolvedLayoutValue.isParticipant && !isChat && !isObjectType
        
        self.canApplyUneditableActions = participantCanEdit && !isArchive
        self.canChangeType = !objectRestrictions.contains(.typeChange) && canEdit && !isTemplate
        self.canDelete = isArchive && participantCanEdit
        self.canRestore = canDelete
        self.canTemplateSetAsDefault = isTemplate && canEdit
        self.canArchive = !objectRestrictions.contains(.delete) && participantCanEdit
        self.canDuplicate = !objectRestrictions.contains(.duplicate) && canApplyUneditableActions && !isObjectType
        
        self.canUndoRedo = specificTypes && canEdit
        
        self.canMakeAsTemplate = details.canMakeTemplate
                                && !objectRestrictions.contains(.template)
                                && canApplyUneditableActions

        self.canFavorite = canApplyUneditableActions && !isTemplate && !isObjectType
        self.canLinkItself = canApplyUneditableActions && !isTemplate && !isObjectType && !isChat
        self.canLock = specificTypes && canApplyUneditableActions && !isTemplate
        self.canChangeIcon = details.resolvedLayoutValue.haveIcon && canEdit
        self.canChangeCover = details.resolvedLayoutValue.haveCover && canEdit && !isObjectType
        self.canChangeLayout = details.resolvedLayoutValue.isEditorLayout && canEdit // && !objectRestrictions.contains(.layoutChange)
        self.canEditDetails = !objectRestrictions.contains(.details) && participantCanEdit
        self.canEditRelationValues = canEditRelations && canEditDetails
        self.canEditPropertiesList = canEditRelationValues && !objectRestrictions.contains(.relations)
        self.canShare = !isTemplate && !isObjectType
        self.canPublish = canShare && specificTypes && !isArchive
        self.canApplyTemplates = canEdit && !isTemplate
        self.canEditMessages = canEdit
        self.canShowRelations = !isObjectType
        
        if isLocked || isVersionMode {
            self.editBlocks = .readonly(.locked)
        } else if isArchive {
            self.editBlocks = .readonly(.archived)
        } else if !participantCanEdit {
            self.editBlocks = .readonly(.spaceIsReadonly)
        } else if objectRestrictions.contains(.blocks) {
            self.editBlocks = .readonly(.restrictions)
        } else {
            self.editBlocks = .edit
        }
        
        self.canEditBlocks = editBlocks.canEdit
        self.canRestoreVersionHistory = !isLocked && !isArchive && participantCanEdit
        self.canToggleDescription = !isChat
    }
}

extension ObjectDetails {
    
    func permissions(participant: Participant?) -> ObjectPermissions {
        permissions(participantCanEdit: participant?.canEdit ?? false)
    }
    
    func permissions(participantCanEdit: Bool) -> ObjectPermissions {
        ObjectPermissions(
            details: self,
            isLocked: false,
            participantCanEdit: participantCanEdit, 
            isVersionMode: false,
            objectRestrictions: restrictionsValue
        )
    }
}
extension ObjectPermissions: Sendable { }
typealias PortablePermissions = ObjectPermissions

protocol BaseDocumentProtocol: AnyObject, Sendable {
    var objectId: String { get }
    var spaceId: String { get }
    var mode: DocumentMode { get }
    var isOpened: Bool { get }
    var isLocked: Bool { get }
    var permissions: PortablePermissions { get }
}


final class CompositionDocument: BaseDocumentProtocol, EditorDocumentWriteLifetimeProviding, Sendable {
    let objectId: String
    let spaceId: String
    let mode = DocumentMode.handling
    let isOpened = true
    let isLocked = false
    let permissions = ObjectDetails(restrictionsValue: []).permissions(participantCanEdit: true)
    let editorWriteLifetime = EditorDocumentWriteLifetime()
    init(objectId: String = "native-target", spaceId: String = "space-A") {
        self.objectId = objectId
        self.spaceId = spaceId
    }
}
