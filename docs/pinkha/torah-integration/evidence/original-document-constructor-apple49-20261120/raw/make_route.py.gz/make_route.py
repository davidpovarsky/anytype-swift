from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import re
import yaml

HERE = Path(__file__).resolve().parent
BASE, OUT = HERE / 'base', HERE / 'candidate'
BRANCH = 'codex/otzaria-original-document-constructor49-reviewed-20261120'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def put(path, raw):
    target = OUT / path; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw if isinstance(raw, bytes) else raw.encode())
old = json.loads((BASE / 'Tools/Hanlin/original_editor_profile.json').read_text())
constructor = OUT / 'AnytypeTests/Markdown/PreparedDocumentConstructorTests.swift'
data = {
    'profile': 'original-constructors', 'required_methods': 49,
    'source_base': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383',
    'constructor_packet_sha256': '09dc98cd7784b87aca1c520b9cd11c22249b346ba962a4c120ce3ac9c3f5814d',
    'application_trees': json.loads((HERE / 'APPLICATION_TREE_PROJECTION.json').read_text())['application_after_three_source_changes'],
    'original_profile_module_sha256': sha((BASE / 'Tools/Hanlin/original_editor_profile.py').read_bytes()),
    'original_profile_manifest_sha256': sha((BASE / 'Tools/Hanlin/original_editor_profile.json').read_bytes()),
    'original_suites': old['suites'], 'heart': old['heart'],
    'constructor_sources': {path: sha((OUT / path).read_bytes()) for path in (
        'Anytype/Sources/Models/Documents/Document/BaseDocument.swift',
        'Anytype/Sources/Models/Documents/Events/DocumentViewModelSetter.swift')},
    'constructor_suite': {'name': 'PreparedDocumentConstructorTests',
        'path': str(constructor.relative_to(OUT)), 'sha256': sha(constructor.read_bytes()),
        'methods': re.findall(r'    func (test\w+)\(', constructor.read_text())},
}
put('Tools/Hanlin/original_document_constructor_profile.json', json.dumps(data, indent=2, sort_keys=True)+'\n')

path = 'Tools/Hanlin/run_host_tests.py'
text = (BASE / path).read_text()
changes = []
def change(before, after):
    global text
    assert text.count(before) == 1, before
    text = text.replace(before, after, 1)
    changes.append({'before': before, 'after': after})
change('import original_editor_profile as original_profile\n',
       'import original_editor_profile as original_profile\nimport original_document_constructor_profile as constructor_profile\n')
change('    ORIGINAL_EDITOR = "original-editor"\n',
       '    ORIGINAL_EDITOR = "original-editor"\n    ORIGINAL_CONSTRUCTORS = "original-constructors"\n')
change('    def suites(self):\n',
       '    def suites(self):\n        if self is self.ORIGINAL_CONSTRUCTORS:\n            return constructor_profile.suite_counts()\n')
change('self.ORIGINAL_EDITOR: "original-editor"}[self]',
       'self.ORIGINAL_EDITOR: "original-editor",\n                self.ORIGINAL_CONSTRUCTORS: "original-constructors"}[self]')
change('self.ORIGINAL_EDITOR: "ORIGINAL_EDITOR_COMPONENT_PASS"}[self]',
       'self.ORIGINAL_EDITOR: "ORIGINAL_EDITOR_COMPONENT_PASS",\n                self.ORIGINAL_CONSTRUCTORS: "ORIGINAL_CONSTRUCTORS_COMPONENT_PASS"}[self]')
change('    if profile is HostTestProfile.ORIGINAL_EDITOR:\n        return original_profile.expected_methods(app)\n',
       '    if profile is HostTestProfile.ORIGINAL_EDITOR:\n        return original_profile.expected_methods(app)\n    if profile is HostTestProfile.ORIGINAL_CONSTRUCTORS:\n        return constructor_profile.expected_methods(app)\n')
change('        result.update(original_profile.validate_execution(tree, expected))\n',
       '        result.update(original_profile.validate_execution(tree, expected))\n    if profile is HostTestProfile.ORIGINAL_CONSTRUCTORS:\n        require(counts["totalTestCount"] == 49, "Constructor profile must execute exactly original43 plus new6")\n        result.update(constructor_profile.validate_execution(tree, expected))\n')
change('        identity_check = (original_profile.require_identity if profile is HostTestProfile.ORIGINAL_EDITOR\n                          else require_identity)\n',
       '        identity_check = (original_profile.require_identity if profile is HostTestProfile.ORIGINAL_EDITOR\n                          else require_identity)\n        if profile is HostTestProfile.ORIGINAL_CONSTRUCTORS:\n            constructor_profile.require_workflow_environment(os.environ)\n            identity_check = constructor_profile.require_identity\n')
change('HostTestProfile.ORIGINAL_EDITOR: "OriginalEditor.xcresult"}[profile]',
       'HostTestProfile.ORIGINAL_EDITOR: "OriginalEditor.xcresult",\n                         HostTestProfile.ORIGINAL_CONSTRUCTORS: "OriginalConstructors.xcresult"}[profile]')
change('    receipt.update(status=profile.pass_status, phase="COMPLETE", release_accepted=False, limitations=[limitation])\n',
       '    if profile is HostTestProfile.ORIGINAL_CONSTRUCTORS:\n        receipt["constructor_manifest_sha256"] = sha256(constructor_profile.MANIFEST_PATH)\n        limitation = ("Original43 ownership/lifetime components plus six actual document-constructor/projection methods; "\n                      "explicit service doubles, no object-open, account, Heart RPC, mounted editor, "\n                      "annotation persistence or physical acceptance")\n    receipt.update(status=profile.pass_status, phase="COMPLETE", release_accepted=False, limitations=[limitation])\n')
change('choices=APPROVED_BRANCHES + (original_profile.BRANCH,)',
       'choices=APPROVED_BRANCHES + (original_profile.BRANCH, constructor_profile.BRANCH)')
put(path, text)
inverse = text
for item in reversed(changes):
    assert inverse.count(item['after']) == 1
    inverse = inverse.replace(item['after'], item['before'], 1)
assert inverse == (BASE / path).read_text()

installer_path = 'Tools/PinkhaNativeDerived/install_verified_heart.py'
installer_before = (BASE / installer_path).read_text()
old_branch = "'codex/otzaria-original-editor-owned43-apple-reviewed-20261120']"
new_branch = "'codex/otzaria-original-editor-owned43-apple-reviewed-20261120',\n                             '"+BRANCH+"']"
assert installer_before.count(old_branch) == 1
installer_after = installer_before.replace(old_branch, new_branch, 1)
put(installer_path, installer_after)

workflow_path = '.github/workflows/pinkha-original-editor.yml'
original_workflow = yaml.safe_load((BASE / workflow_path).read_text())
workflow = copy.deepcopy(original_workflow)
workflow['name'] = 'Original document constructor Apple49 acceptance'
workflow.pop(True, None); workflow.pop('on', None)
workflow['on'] = {'push': {'branches': [BRANCH]}}
workflow['concurrency']['group'] = 'original-constructors-${{ github.ref }}'
job = workflow['jobs'].pop('original-editor')
workflow['jobs']['original-constructors'] = job
job['if'] = "${{ github.event_name == 'push' && github.repository == 'davidpovarsky/anytype-swift' && github.ref == 'refs/heads/"+BRANCH+"' }}"
job['env']['EXPECTED_APP_BRANCH'] = BRANCH
job['env']['HEART_SOURCE_RUN_ID'] = '44203168617'
job['env']['EDITOR_EVIDENCE'] = 'build/original-constructors-evidence'
job['env']['EDITOR_DERIVED'] = 'build/original-constructors-derived-${{ github.run_id }}-${{ github.run_attempt }}'
steps = job['steps']
steps[2]['name'] = 'Bind original application trees and all forty-nine target declarations'
steps[2]['run'] = steps[2]['run'].replace('codex/otzaria-original-editor-owned43-apple-reviewed-20261120', BRANCH).replace('Tools/Hanlin/original_editor_profile.py', 'Tools/Hanlin/original_document_constructor_profile.py')
steps.insert(3, {'name': 'Checkout exact original43 source for unchanged baseline-profile controls',
    'uses': 'actions/checkout@v4', 'with': {
        'ref': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383',
        'path': '.ci/original-editor43-controls', 'persist-credentials': False,
        'sparse-checkout': '/Tools/Hanlin/\n/AnytypeTests/Markdown/\n/Tools/PinkhaNativeDerived/build_native_ipa.py\n/Tools/PinkhaNativeDerived/build_custom_heart.py\n/Tools/PinkhaNativeDerived/install_verified_heart.py\n',
        'sparse-checkout-cone-mode': False}})
control = next(s for s in steps if s.get('name') == 'Prepare the existing SDK and execute all original host-gate controls')
control['run'] = control['run'].replace("python3 -m unittest discover -s Tools/Hanlin -p 'test_run_host*.py' -v",
    'python3 Tools/Hanlin/run_original_document_constructor_controls.py --app "$GITHUB_WORKSPACE" \\\n  --baseline "$GITHUB_WORKSPACE/.ci/original-editor43-controls" --evidence "$EDITOR_EVIDENCE/controls"')
build = next(s for s in steps if s.get('name') == 'Build original Debug-Anytype and execute exact editor component tests')
build['name'] = 'Build original Debug-Anytype and execute original43 plus constructor6'
build['run'] = build['run'].replace('--profile original-editor', '--profile original-constructors')
steps[-1]['name'] = 'Upload original document constructor Apple evidence'
steps[-1]['with']['name'] = 'Otzaria-Original-Constructors-Apple-${{ github.sha }}-${{ github.run_id }}-${{ github.run_attempt }}'
put('.github/workflows/pinkha-original-document-constructor.yml', yaml.safe_dump(workflow, sort_keys=False, width=140))

proof = {'host_exact_inverse': changes,
         'installer_exact_inverse': {'before': old_branch, 'after': new_branch},
         'source_base': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383',
         'existing_workflows_modified': False, 'original_43_profile_files_modified': False,
         'original_74_control_files_modified': False,
         'new_job_minutes': job['timeout-minutes'], 'new_execution_step_minutes': build['timeout-minutes']}
(HERE / 'RUNTIME_PRESERVATION.json').write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n')
patch = ''.join(difflib.unified_diff((BASE/path).read_text().splitlines(True), (OUT/path).read_text().splitlines(True), fromfile='a/'+path,tofile='b/'+path))
patch += ''.join(difflib.unified_diff(installer_before.splitlines(True), installer_after.splitlines(True),fromfile='a/'+installer_path,tofile='b/'+installer_path))
(HERE / 'RUNTIME_PROPOSED.patch').write_text(patch)

baseline = HERE / 'fixture-baseline74'
baseline_paths = []
for directory in ['Tools/Hanlin', 'AnytypeTests/Markdown', 'Tools/PinkhaNativeDerived']:
    baseline_paths += [p.relative_to(baseline).as_posix() for p in (baseline / directory).rglob('*')
                       if p.is_file() and '__pycache__' not in p.parts]
def unittest_names(path):
    tree = ast.parse(path.read_text())
    return [path.stem + '.' + node.name + '.' + method.name for node in tree.body if isinstance(node, ast.ClassDef)
            for method in node.body if isinstance(method, ast.FunctionDef) and method.name.startswith('test')]
old_names = sorted(name for p in sorted((baseline / 'Tools/Hanlin').glob('test_run_host*.py'))
                   for name in unittest_names(p))
new_names = sorted(unittest_names(OUT / 'Tools/Hanlin/test_document_constructor_profile.py'))
assert len(old_names) == len(set(old_names)) == 74
controls = {'schema': 1, 'baseline_sha': data['source_base'],
    'baseline_inputs': {path: sha((baseline / path).read_bytes()) for path in sorted(baseline_paths)},
    'existing_modified_paths': ['Tools/Hanlin/run_host_tests.py', installer_path],
    'baseline_overlay_new_paths': ['Tools/Hanlin/original_document_constructor_profile.py',
                                   'Tools/Hanlin/original_document_constructor_profile.json'],
    'host_inverse': changes, 'original74_methods': old_names, 'candidate_control_methods': new_names,
    'candidate_runtime': ['Tools/Hanlin/original_document_constructor_profile.py',
        'Tools/Hanlin/original_document_constructor_profile.json',
        'Tools/Hanlin/original_document_constructor_controls.json',
        'Tools/Hanlin/run_original_document_constructor_controls.py',
        'Tools/Hanlin/test_document_constructor_profile.py',
        '.github/workflows/pinkha-original-document-constructor.yml',
        'Anytype/Sources/Models/Documents/Document/BaseDocument.swift',
        'Anytype/Sources/Models/Documents/Events/DocumentViewModelSetter.swift',
        'AnytypeTests/Markdown/PreparedDocumentConstructorTests.swift']}
put('Tools/Hanlin/original_document_constructor_controls.json', json.dumps(controls, indent=2, sort_keys=True)+'\n')
print(json.dumps({'original_app_trees': data['application_trees'], 'new_profile': data['profile'],
    'methods': data['required_methods'], 'host_hunks': len(changes), 'job_minutes': job['timeout-minutes'],
    'execution_minutes': build['timeout-minutes']}, sort_keys=True))
