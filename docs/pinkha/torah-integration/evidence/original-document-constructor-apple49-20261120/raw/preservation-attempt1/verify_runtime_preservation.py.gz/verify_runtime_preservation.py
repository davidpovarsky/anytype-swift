"""Offline exact inverse of the additive constructor route, not Apple execution."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import subprocess
import yaml

HERE = Path(__file__).resolve().parent
BASE, CANDIDATE = HERE / 'base', HERE / 'candidate'
proof = json.loads((HERE / 'RUNTIME_PRESERVATION.json').read_text())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def invert_host(text):
    for item in reversed(proof['host_exact_inverse']):
        assert text.count(item['after']) == 1
        text = text.replace(item['after'], item['before'], 1)
    assert text == (BASE / 'Tools/Hanlin/run_host_tests.py').read_text()

invert_host((CANDIDATE / 'Tools/Hanlin/run_host_tests.py').read_text())
try:
    invert_host((CANDIDATE / 'Tools/Hanlin/run_host_tests.py').read_text() + '\n# unreviewed control mutation\n')
except AssertionError:
    pass
else:
    raise AssertionError('Inverse accepted unrelated host changes')
installer = 'Tools/PinkhaNativeDerived/install_verified_heart.py'
item = proof['installer_exact_inverse']
text = (CANDIDATE / installer).read_text()
assert text.count(item['after']) == 1
assert text.replace(item['after'], item['before'], 1) == (BASE / installer).read_text()

def workflow(path):
    result = yaml.safe_load(path.read_text())
    if True in result:
        result['on'] = result.pop(True)
    return result
original = workflow(BASE / '.github/workflows/pinkha-original-editor.yml')
candidate = workflow(CANDIDATE / '.github/workflows/pinkha-original-document-constructor.yml')
branch = 'codex/otzaria-original-document-constructor49-reviewed-20261120'
assert candidate['on'] == {'push': {'branches': [branch]}}
assert candidate['permissions'] == original['permissions'] == {'contents': 'read', 'actions': 'read'}
assert candidate['concurrency']['cancel-in-progress'] is False
job = candidate['jobs']['original-constructors']
old_job = original['jobs']['original-editor']
assert job['runs-on'] == old_job['runs-on'] == 'xcode-27'
assert job['timeout-minutes'] == old_job['timeout-minutes'] == 120
assert job['if'] == "${{ github.event_name == 'push' && github.repository == 'davidpovarsky/anytype-swift' && github.ref == 'refs/heads/" + branch + "' }}"
restored = copy.deepcopy(candidate)
restored['name'] = original['name']; restored['on'] = original['on']
restored['concurrency']['group'] = original['concurrency']['group']
restored_job = restored['jobs'].pop('original-constructors')
restored['jobs']['original-editor'] = restored_job
if 'if' in old_job:
    restored_job['if'] = old_job['if']
else:
    restored_job.pop('if')
for key in ['EXPECTED_APP_BRANCH', 'HEART_SOURCE_RUN_ID', 'EDITOR_EVIDENCE', 'EDITOR_DERIVED']:
    restored_job['env'][key] = old_job['env'][key]
steps = restored_job['steps']
baseline_checkout = steps.pop(3)
assert baseline_checkout['with'] == {
    'ref': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383', 'path': '.ci/original-editor43-controls',
    'persist-credentials': False, 'sparse-checkout-cone-mode': False,
    'sparse-checkout': '/Tools/Hanlin/\n/AnytypeTests/Markdown/\n/Tools/PinkhaNativeDerived/build_native_ipa.py\n/Tools/PinkhaNativeDerived/build_custom_heart.py\n/Tools/PinkhaNativeDerived/install_verified_heart.py\n'}
steps[2]['name'] = old_job['steps'][2]['name']
steps[2]['run'] = steps[2]['run'].replace(branch, 'codex/otzaria-original-editor-owned43-apple-reviewed-20261120').replace(
    'Tools/Hanlin/original_document_constructor_profile.py', 'Tools/Hanlin/original_editor_profile.py')
control = next(x for x in steps if x.get('name') == 'Prepare the existing SDK and execute all original host-gate controls')
control['run'] = control['run'].replace(
    'python3 Tools/Hanlin/run_original_document_constructor_controls.py --app "$GITHUB_WORKSPACE" \\\n+  --baseline "$GITHUB_WORKSPACE/.ci/original-editor43-controls" --evidence "$EDITOR_EVIDENCE/controls"',
    "python3 -m unittest discover -s Tools/Hanlin -p 'test_run_host*.py' -v")
build = next(x for x in steps if x.get('name') == 'Build original Debug-Anytype and execute original43 plus constructor6')
assert build['timeout-minutes'] == 100
build['name'] = 'Build original Debug-Anytype and execute exact editor component tests'
build['run'] = build['run'].replace('--profile original-constructors', '--profile original-editor')
steps[-1]['name'] = old_job['steps'][-1]['name']
steps[-1]['with']['name'] = old_job['steps'][-1]['with']['name']
assert restored == original

controls = json.loads((CANDIDATE / 'Tools/Hanlin/original_document_constructor_controls.json').read_text())
assert len(controls['original74_methods']) == len(set(controls['original74_methods'])) == 74
assert len(controls['candidate_control_methods']) == len(set(controls['candidate_control_methods'])) == 23
for path, expected in controls['baseline_inputs'].items():
    raw = (HERE / 'fixture-baseline74' / path).read_bytes()
    assert sha(raw) == expected
    assert raw == subprocess.check_output(['git', '-C', str(HERE / 'fixture-baseline74'), 'show', 'b4ece8c2129124f6ec8ed00143e156b9d0e11383:' + path])
constructor = json.loads((CANDIDATE / 'Tools/Hanlin/original_document_constructor_profile.json').read_text())
old_profile = json.loads((BASE / 'Tools/Hanlin/original_editor_profile.json').read_text())
assert constructor['original_suites'] == old_profile['suites'] and constructor['heart'] == old_profile['heart']
assert sum(len(x['methods']) for x in constructor['original_suites'].values()) == 43
assert len(constructor['constructor_suite']['methods']) == 6
result = {'status': 'PASS_SOURCE_PRESERVATION_APPLE_NOT_RUN', 'host_exact_inverse_hunks': 11,
    'unrelated_host_delta_negative_control': 'REJECTED', 'installer_inverse_hunks': 1,
    'original_workflow_semantic_inverse': True, 'original_workflow_source_untouched': True,
    'original74_methods_and_inputs_unchanged': True, 'baseline_inputs': len(controls['baseline_inputs']),
    'original43_tests_and_validator_unchanged': True, 'candidate_python_controls': 23,
    'apple_method_selection': 49, 'apple_execution': 'NOT_RUN',
    'job_minutes': 120, 'execution_step_minutes': 100,
    'frozen_framework_dc3_modified': False}
(HERE / 'FINAL_PRESERVATION.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
