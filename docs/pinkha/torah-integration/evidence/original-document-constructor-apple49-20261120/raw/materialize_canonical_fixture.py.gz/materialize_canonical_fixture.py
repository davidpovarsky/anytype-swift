"""Reconstruct authenticated Git trees/commit in owned partial fixtures, not source blobs."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zlib

HERE = Path(__file__).resolve().parent
tree_api_path = HERE.parent / 'anytype-importable-editor-v2-20261120/ROOT_CANONICAL_B4_TREE.json'
tree_api = json.loads(tree_api_path.read_text())
commit_api = json.loads((HERE / 'B4_COMMIT_API.json').read_text())
assert tree_api['truncated'] is False and tree_api['sha'] == commit_api['tree']['sha']

def git_object(kind, raw):
    full = kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw
    return hashlib.sha1(full).hexdigest(), zlib.compress(full)

groups = {'': []}
for item in tree_api['tree']:
    parent, _, name = item['path'].rpartition('/')
    groups.setdefault(parent, []).append((name, item))
    if item['type'] == 'tree':
        groups.setdefault(item['path'], [])
expected = {item['path']: item['sha'] for item in tree_api['tree'] if item['type'] == 'tree'}
expected[''] = tree_api['sha']
objects = {}
for parent, items in groups.items():
    raw = b''
    for name, item in sorted(items, key=lambda x: x[0].encode() + (b'/' if x[1]['type'] == 'tree' else b'')):
        mode = item['mode'].lstrip('0')
        raw += mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(item['sha'])
    oid, packed = git_object('tree', raw)
    assert oid == expected[parent], (parent, oid, expected[parent])
    objects[oid] = packed

lines = ['tree ' + commit_api['tree']['sha']]
lines += ['parent ' + x['sha'] for x in commit_api['parents']]
for field in ['author', 'committer']:
    actor = commit_api[field]
    seconds = int(datetime.datetime.fromisoformat(actor['date'].replace('Z', '+00:00')).timestamp())
    lines.append(f"{field} {actor['name']} <{actor['email']}> {seconds} +0200")
# GitHub normalizes actor dates to UTC in its API. The exact original object
# retains +0200 and has no terminal LF; its actual Git SHA is required below.
raw = ('\n'.join(lines) + '\n\n' + commit_api['message']).encode()
oid, packed = git_object('commit', raw)
assert oid == commit_api['sha'], (oid, commit_api['sha'])
objects[oid] = packed
receipts = []
for name in ['fixture-baseline74', 'fixture-candidate49']:
    root = HERE / name
    for oid, packed in objects.items():
        target = root / '.git/objects' / oid[:2] / oid[2:]
        if target.exists():
            assert zlib.decompress(target.read_bytes()) == zlib.decompress(packed)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(packed)
    def git(*args, input=None):
        result = subprocess.run(['git', '-C', str(root), *args], input=input, capture_output=True)
        assert result.returncode == 0, result.stderr.decode()
        return result.stdout
    git('update-ref', 'refs/heads/local-fixture-b4', commit_api['sha'])
    git('symbolic-ref', 'HEAD', 'refs/heads/local-fixture-b4')
    git('read-tree', commit_api['sha'])
    paths = git('ls-files', '-z').split(b'\0')
    absent = [x for x in paths if x and not (root / x.decode()).exists()]
    git('update-index', '--skip-worktree', '-z', '--stdin', input=b'\0'.join(absent) + b'\0')
    receipts.append({'path': name, 'head': git('rev-parse', 'HEAD').decode().strip(),
                     'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
                     'materialized_original_source_files': 26, 'unmaterialized_tracked_paths': len(absent)})
(HERE / 'CANONICAL_FIXTURE_GIT.json').write_text(json.dumps({
    'schema': 1, 'canonical_commit': commit_api['sha'], 'authenticated_tree_entries': len(tree_api['tree']),
    'reconstructed_tree_objects': len(objects) - 1, 'fixtures': receipts,
    'scope': 'Actual Git object identities reconstructed from authenticated API; no missing source blob fabricated. Owned sparse fixture only.'}, indent=2) + '\n')
print(json.dumps(receipts, indent=2))
