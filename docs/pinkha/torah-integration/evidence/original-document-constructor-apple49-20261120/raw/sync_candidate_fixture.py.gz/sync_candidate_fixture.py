from pathlib import Path
import hashlib
import json
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE, TARGET = HERE / 'candidate', HERE / 'fixture-candidate49'
paths = []
for source in SOURCE.rglob('*'):
    if source.is_file() and '__pycache__' not in source.parts and 'docs' not in source.relative_to(SOURCE).parts:
        relative = source.relative_to(SOURCE)
        target = TARGET / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        paths.append(relative.as_posix())
def git(*args, input=None):
    result = subprocess.run(['git', '-C', str(TARGET), *args], input=input, capture_output=True)
    assert result.returncode == 0, result.stderr.decode()
    return result.stdout.decode().strip()
git('add', '--sparse', '--', *sorted(paths))
tree = git('write-tree', '--missing-ok')
commit = git('-c', 'user.name=Otzaria local acceptance fixture', '-c', 'user.email=fixture@example.invalid',
             'commit-tree', tree, '-p', 'b4ece8c2129124f6ec8ed00143e156b9d0e11383',
             input=b'Local source-bound constructor49 control fixture; not published source.\n')
git('update-ref', 'refs/heads/local-constructor49-fixture', commit)
git('symbolic-ref', 'HEAD', 'refs/heads/local-constructor49-fixture')
expected = json.loads((SOURCE / 'Tools/Hanlin/original_document_constructor_profile.json').read_text())['application_trees']
actual = {path: git('rev-parse', 'HEAD:' + path) for path in expected}
assert expected == actual
receipt = {'scope': 'Local real Git object fixture only; not Apple source activation', 'head': commit, 'tree': tree,
           'parent': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383', 'candidate_paths': sorted(paths),
           'application_trees': actual, 'source_bytes': {path: hashlib.sha256((TARGET / path).read_bytes()).hexdigest() for path in paths}}
(HERE / 'LOCAL_CANDIDATE_FIXTURE.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'fixture_head': commit, 'candidate_files': len(paths), 'application_trees_exact': True}))
