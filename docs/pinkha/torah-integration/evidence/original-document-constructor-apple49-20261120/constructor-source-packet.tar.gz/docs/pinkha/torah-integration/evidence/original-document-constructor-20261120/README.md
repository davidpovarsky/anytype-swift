# Original document constructor dependencies

This candidate adds two internal dependency bundles to the original Anytype document constructors. It changes exactly two production files and adds six actual-class XCTest methods. It does not expose an editing API, open an object, start an account, mount an editor, change a codec, or change the active framework acceptance branch.

## Source and reason

The reviewed source is `davidpovarsky/anytype-swift` at `b4ece8c2129124f6ec8ed00143e156b9d0e11383`. The subsequently activated framework candidate `dc3ac07cec63692c8b84877a56e3e3fd60a4c667` preserves the entire original `Anytype/Sources` tree, so these two baseline blobs are also the framework candidate's originals.

`BaseDocument` already accepts several services, but its private `@Injected` properties eagerly resolve the global properties builder, sync storage and history service. Its user-info storage also resolves globally at construction. `DocumentViewModelSetter` eagerly resolves the global mention updater. Factory 2.3.1 at `8ca11a7bd1ede031e8e6d7a912bb116e2e43961b` explicitly implements `Injected.init` by resolving its factory immediately; its stored wrapped value does not resolve on every access.

An external wrapper cannot stop those private initializers. The original classes are final, and supplying a different document implementation would not exercise their original document/projection logic. Two optional internal constructor parameters are the narrow injection point. Supplying a bundle avoids all five implicit resolutions. Omitting it or explicitly supplying nil resolves the same original factories once, before the existing initializer assignments and setup. No original call site changes.

The whole original `BaseDocument` body from `deinit` onward is byte-identical, including open/close, permission observation, lifetime invalidation, update projection and subscription handling. The setter's entire projection implementation is byte-identical. The new bundles carry services; they grant no Object/Space identity, open state, permission or ownership. All existing prepared-session validation and owned-writer requirements remain necessary.

## Changes

| Path | Change | Classification |
| --- | --- | --- |
| `Anytype/Sources/Models/Documents/Document/BaseDocument.swift` | Four private stored services and optional `BaseDocumentDependencies`; same original default factories | Narrow hook in upstream-owned source |
| `Anytype/Sources/Models/Documents/Events/DocumentViewModelSetter.swift` | One private stored service and optional `DocumentViewModelSetterDependencies`; same original default updater | Narrow hook in upstream-owned source |
| `AnytypeTests/Markdown/PreparedDocumentConstructorTests.swift` | Six actual-class constructor/projection cases | Test-only addition |

The new test is in the original synchronized `AnytypeTests` folder. The original project assigns that folder to target `03C5C53F22DFD90C00DD91DE`, and its exclusions do not include this new file. No project, package pin, generated source, resource, Heart, app launch, or original 43-test file is changed by this packet.

## Six runtime assertions prepared for Apple

1. A supplied bundle reaches the actual `BaseDocument` without resolving any of the five registered default factories; original identity/mode/closed state and handling listener setup are checked.
2. A real original-style caller omits the new argument and resolves exactly the same four factories once in order. Stored service identity is checked before and after further reads.
3. An explicit nil argument follows that same default path. It is a separate real initializer call, rather than a helper that always forwards nil.
4. A supplied preview document preserves the original callback installation, no listener start and closed state.
5. The real setter runs original protobuf-to-`InfoContainer` projection with an explicitly supplied updater, preserving the exact container/storage references and making no default resolution.
6. The real default setter resolves its original updater exactly once and performs that same original projection.

Protocol doubles fail on unused service operations. The tests never call `open`, invoke Heart, create accounts, or deliver synthetic engine events. They use Factory's original test `push`/`pop` pair for scoped registration/cache restoration. All cases are synchronous on MainActor and must run under the original nonparallel host configuration; these tests do not establish safety of concurrent global Factory mutation. No production global registration is introduced.

## Executed evidence and limits

The local Python verification checks exact Git blob provenance, complete two-file inverses, unchanged original projection/lifecycle bodies, the source-backed default factory list and the six unique declarations. The source evidence includes the full pinned Factory implementation and actual protocol/projection inputs used to prepare the tests.

**Swift compilation: NOT_RUN. Apple XCTest execution: 0. UI/Native acceptance: NOT_RUN. Editor mount: not exposed.** The original 43-method acceptance belongs to its previously tested source; it is not transferred to these new classes. A separate, source-bound Apple selection of all original 43 plus these six is the next validation step. No active workflow or immutable framework ref is altered by this source packet.

## Codec and ownership boundary

The genuine Heart `.pb` export is a `SnapshotWithType` containing a `Change.Snapshot` and `SmartBlockSnapshotBase`. It is not the original editor's `ObjectView` response. The original reverse `BlockInformationConverter` recreates restrictions and uses a fixed vertical alignment, so it is not a lossless persistence codec. This candidate does not serialize or translate either representation.

The intended later route requires an owned disposable LocalOnly Heart context, actual imported/created Object and Space identities, original document opening, qualified reachable writers, the prepared-session owner, and genuine export into the annotation store's existing compare-and-save boundary. The native-derived original fixture already demonstrates LocalOnly account/workspace creation using an owned temporary work directory and disabled telemetry, but no such operation was run here. No annotation UUID is treated as an Anytype Space, no live account is used, and the opaque acceptance-only annotation format is not described as an Anytype format.

## Review and rollback

The standing owner authorization and Root's scoped constructor assignment cover this isolated prerequisite. Root remains the integration/activation owner. `PROPOSED.patch` describes both source hooks; restoring the two recorded base blobs and removing the added test fully reverses this packet. The active framework branch remains immutable. No Asana completion or runtime credit is requested from source verification alone.
