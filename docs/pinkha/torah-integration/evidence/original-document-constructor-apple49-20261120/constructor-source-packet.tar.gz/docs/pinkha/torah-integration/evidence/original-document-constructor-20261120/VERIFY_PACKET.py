"""Verify canonical source evidence and exact inverse; no Swift execution."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

DOC = Path('docs/pinkha/torah-integration/evidence/original-document-constructor-20261120')

def record(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()}

def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    packet = json.loads((root / DOC / 'PACKET_INDEX.json').read_text())
    paths = [item['path'] for item in packet['payloads']]
    assert len(paths) == len(set(paths))
    for item in packet['payloads']:
        path = root / item['path']
        assert path.is_file() and not path.is_symlink()
        assert path.resolve().is_relative_to(root)
        assert record(path.read_bytes()) == {k: item[k] for k in ('bytes', 'sha256', 'git_blob')}, item['path']
    records = json.loads((root / DOC / 'SOURCE_RECORDS.json').read_text())
    raw = {}
    for item in records:
        contents = gzip.decompress((root / item['archive']).read_bytes())
        assert record(contents) == {k: item[k] for k in ('bytes', 'sha256', 'git_blob')}, item['path']
        assert item['path'] not in raw
        raw[item['path']] = contents
    changes = json.loads((root / DOC / 'SOURCE_CHANGE_INDEX.json').read_text())
    assert len(changes) == 3
    for item in changes:
        actual = record((root / item['path']).read_bytes())
        assert actual['sha256'] == item['candidate_sha256']
        assert actual['git_blob'] == item['candidate_git_blob']
    with tempfile.TemporaryDirectory(prefix='original-constructor-source-') as tmp:
        local = Path(tmp)
        for item in changes:
            target = local / 'candidate' / item['path']
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(root / item['path'], target)
            if 'base_git_blob' in item:
                target = local / 'base' / item['path']
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw[item['path']])
        shutil.copyfile(root / DOC / 'INVERSE_DRIVER.py', local / 'VERIFY_SOURCE.py')
        result = subprocess.run([sys.executable, str(local / 'VERIFY_SOURCE.py')],
                                capture_output=True, text=True, timeout=20)
        assert result.returncode == 0, (result.stdout, result.stderr)
        verified = json.loads((local / 'SOURCE_PRESERVATION.json').read_text())
        assert verified == json.loads((root / DOC / 'SOURCE_PRESERVATION.json').read_text())
    tests = (root / changes[2]['path']).read_text()
    assert tests.count('private func makeDocument(') == 2
    assert 'dependencies: BaseDocumentDependencies? = nil' not in tests
    assert 'private final class ConstructorResolutionRecord {' in tests
    project = raw['Anytype.xcodeproj/project.pbxproj'].decode()
    assert '3D0DC0E12DFC9BC000E555FD /* AnytypeTests */' in project
    assert 'PreparedDocumentConstructorTests.swift' not in project
    pins = json.loads(raw['Anytype.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved'])['pins']
    assert len(pins) == 44
    assert [p['state']['revision'] for p in pins if p['identity'] == 'factory'] == ['8ca11a7bd1ede031e8e6d7a912bb116e2e43961b']
    assert packet['executed']['Swift_compile'] == 'NOT_RUN'
    assert packet['executed']['XCTest_cases'] == packet['executed']['Native_cases'] == 0
    print(json.dumps({'status': 'SOURCE_PACKET_VERIFIED', 'payloads': len(paths),
                      'exact_original_blobs': len(records), 'source_changes': 3,
                      'new_XCTest_declarations': len(verified['new_XCTest_declarations']),
                      'Swift_compile': 'NOT_RUN', 'XCTest_executed': 0,
                      'Native_executed': 0}, sort_keys=True))

if __name__ == '__main__':
    main()
