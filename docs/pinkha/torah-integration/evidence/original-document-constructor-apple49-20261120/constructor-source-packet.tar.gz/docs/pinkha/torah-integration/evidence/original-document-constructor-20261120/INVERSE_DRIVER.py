"""Exact source-bound preservation; does not compile or execute Swift."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'base'
CANDIDATE = ROOT / 'candidate'

def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def one(raw, newer, older):
    assert raw.count(newer) == 1
    return raw.replace(newer, older, 1)

document = 'Anytype/Sources/Models/Documents/Document/BaseDocument.swift'
setter = 'Anytype/Sources/Models/Documents/Events/DocumentViewModelSetter.swift'
original = (BASE / document).read_text()
candidate = (CANDIDATE / document).read_text()
assert git_blob(original.encode()) == '69885350d5dfd53f727b50018981d405ca8ef044'
start = candidate.index('\n/// Constructor dependencies for an already owned document context.')
new_bundle = candidate[start:]
inverse = candidate[:start]
inverse = one(inverse,
'''    private let relationBuilder: any PropertiesBuilderProtocol
    private let syncStatusStorage: any SyncStatusStorageProtocol
    private let historyVersionsService: any HistoryVersionsServiceProtocol
''',
'''    @Injected(\\.propertiesBuilder)
    private var relationBuilder: any PropertiesBuilderProtocol
    @Injected(\\.syncStatusStorage)
    private var syncStatusStorage: any SyncStatusStorageProtocol
    @Injected(\\.historyVersionsService)
    private var historyVersionsService: any HistoryVersionsServiceProtocol
''')
inverse = one(inverse, '    private let basicUserInfoStorage: any BasicUserInfoStorageProtocol\n',
              '    private let basicUserInfoStorage: any BasicUserInfoStorageProtocol = Container.shared.basicUserInfoStorage()\n')
inverse = one(inverse,
'''        detailsStorage: ObjectDetailsStorage,
        dependencies: BaseDocumentDependencies? = nil
    ) {
        let resolvedDependencies = dependencies ?? .original()
        self.relationBuilder = resolvedDependencies.relationBuilder
        self.syncStatusStorage = resolvedDependencies.syncStatusStorage
        self.historyVersionsService = resolvedDependencies.historyVersionsService
        self.basicUserInfoStorage = resolvedDependencies.basicUserInfoStorage
''',
'''        detailsStorage: ObjectDetailsStorage
    ) {
''')
assert inverse == original
assert re.findall(r'Container\.shared\.(\w+)\(\)', new_bundle) == [
    'propertiesBuilder', 'syncStatusStorage', 'historyVersionsService', 'basicUserInfoStorage']
assert '@Injected' not in candidate[:start] and 'Container.shared' not in candidate[:start]
assert candidate[candidate.index('    deinit {'):start] == original[original.index('    deinit {'):]

original_setter = (BASE / setter).read_text()
candidate_setter = (CANDIDATE / setter).read_text()
assert git_blob(original_setter.encode()) == '28dbf990775fbbc5fe1c08cf047f77766e54fac1'
start_setter = candidate_setter.index('\n/// Preserve the original mention updater while allowing an owned document')
inverse_setter = candidate_setter[:start_setter]
inverse_setter = one(inverse_setter,
    '    private let mentionTextUpdateHandler: any MentionTextUpdateHandlerProtocol\n',
    '    @Injected(\\.mentionTextUpdateHandler)\n    private var mentionTextUpdateHandler: any MentionTextUpdateHandlerProtocol\n')
inverse_setter = one(inverse_setter,
'''        infoContainer: some InfoContainerProtocol,
        dependencies: DocumentViewModelSetterDependencies? = nil
    ) {
        self.mentionTextUpdateHandler = (dependencies ?? .original()).mentionTextUpdateHandler
''',
'''        infoContainer: some InfoContainerProtocol
    ) {
''')
assert inverse_setter == original_setter
assert re.findall(r'Container\.shared\.(\w+)\(\)', candidate_setter[start_setter:]) == ['mentionTextUpdateHandler']
assert '@Injected' not in candidate_setter[:start_setter] and 'Container.shared' not in candidate_setter[:start_setter]
marker = '    // MARK: - ObjectViewModelSetterProtocol'
assert candidate_setter[candidate_setter.index(marker):start_setter] == original_setter[original_setter.index(marker):]

tests = (CANDIDATE / 'AnytypeTests/Markdown/PreparedDocumentConstructorTests.swift').read_text()
names = re.findall(r'    func (test\w+)\(', tests)
assert len(names) == len(set(names)) == 6
assert tests.count('container.manager.push()') == tests.count('defer { container.manager.pop() }') == 1
assert 'try await' not in tests and '.open()' not in tests
result = {
    'base': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383',
    'exact_original_file_inverse': {document: True, setter: True},
    'original_document_methods_after_initializer_byte_identical': True,
    'original_setter_projection_byte_identical': True,
    'original_default_factory_names_order_preserved': True,
    'implicit_factory_resolution_absent_from_supplied_constructor_path': 'SOURCE_PROVEN_RUNTIME_NOT_RUN',
    'new_XCTest_declarations': names,
    'Swift_compile': 'NOT_RUN', 'XCTest_executed': 0,
    'original_Heart_account_or_object_operations': 0, 'editor_mount': 'NOT_EXPOSED'
}
(ROOT / 'SOURCE_PRESERVATION.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
