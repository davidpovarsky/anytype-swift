from pathlib import Path
import os, json, subprocess, sys, tempfile, hashlib, datetime

root = Path(__file__).resolve().parent
native = json.loads((root.parent / 'anytype_v10_evidence_44955835428/evidence/source-controls-result.json').read_text())
failed = [row['id'] for key in ('failures', 'errors') for row in native[key]]
assert len(failed) == len(set(failed)) == 9
reports = []
for phase in ('base', 'candidate'):
    for index, case in enumerate(failed):
        prior = root / 'validation' / phase / str(index)
        if phase == 'base' and index < 5 and prior.is_dir():
            traces = [json.loads(p.read_text()) for p in prior.glob('*.json')]
            assert len(traces) == 1
            receipt = traces[0]['receipt']
            assert receipt['error'] == 'Symbol graph import context is not from the successful original build'
            stderr = (prior / 'stderr.log').read_bytes()
            assert b'FAILED (' in stderr
            reports.append({'phase': phase, 'case': case, 'exit': 1,
                            'receipt_error': receipt['error'], 'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
                            'real_directory_alias': True, 'reused_existing_reproduction': True,
                            'apple_builds_executed': 0, 'native_tests_executed': 0})
            continue
        with tempfile.TemporaryDirectory() as temporary:
            parent = Path(temporary).resolve()
            actual = parent / 'actual'
            actual.mkdir()
            alias = parent / 'alias'
            alias.symlink_to(actual, target_is_directory=True)
            assert alias != alias.resolve() and alias.samefile(actual)
            evidence = root / 'validation' / phase / str(index)
            evidence.mkdir(parents=True, exist_ok=False)
            command = [sys.executable, '-m', 'unittest', case, '-v']
            env = {**os.environ, 'TMPDIR': str(alias), 'PYTHONDONTWRITEBYTECODE': '1',
                   'FRAMEWORK_FLOW_EVIDENCE': str(evidence)}
            result = subprocess.run(command, cwd=root / phase / 'Tools/OriginalEditor', env=env,
                                    capture_output=True, timeout=30)
            (evidence / 'stdout.log').write_bytes(result.stdout)
            (evidence / 'stderr.log').write_bytes(result.stderr)
            traces = [json.loads(p.read_text()) for p in evidence.glob('*.json')]
            assert len(traces) == 1
            receipt = traces[0]['receipt']
            if phase == 'base':
                assert result.returncode != 0
                assert receipt['error'] == 'Symbol graph import context is not from the successful original build'
            else:
                assert result.returncode == 0, result.stderr.decode()
                assert 'Ran 1 test in ' in result.stderr.decode() and result.stderr.rstrip().endswith(b'OK')
                assert receipt['error'] != 'Symbol graph import context is not from the successful original build'
            assert list(actual.iterdir()) == []
            reports.append({'phase': phase, 'case': case, 'exit': result.returncode,
                            'receipt_error': receipt['error'], 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(),
                            'real_directory_alias': True, 'apple_builds_executed': 0, 'native_tests_executed': 0})

case = 'test_framework_temporary_paths.TemporaryRootAliasControls.test_original_driver_import_context_reaches_consumer_under_directory_alias'
result = subprocess.run([sys.executable, '-m', 'unittest', case, '-v'],
                        cwd=root / 'candidate/Tools/OriginalEditor', capture_output=True, timeout=30,
                        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
(root / 'validation/new-alias-control.stderr.log').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode()
summary = {'status': 'PASS_NINE_REPRODUCTIONS_NINE_REPAIRS_ONE_NEW_ALIAS_CONTROL',
           'scope': 'Real filesystem alias; original Python driver and original assertions; explicit Apple-tool doubles. No Apple build/runtime credit.',
           'native_failed_run': 44955835428, 'native_source_sha': '2b8cb06eede49af0b3f09aa91d87686cb28abe82',
           'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'results': reports,
           'new_regression': {'id': case, 'exit': result.returncode},
           'unchanged_native_passed_cases_not_rerun': 183}
(root / 'validation/RESULT.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'results'}))
