import SwiftUI
import Services
import AnytypeCore
import PinkhaKit


@MainActor
@Observable
final class PropertyCreationViewModel: PropertyInfoCoordinatorViewOutput {

    var rows: [SearchDataSection<PropertySearchData>] = []
    var newPropertyData: PropertyInfoData?
    var nativeLookupFailed = false
    var preparedRouteUnavailable = false
    private var lastSearchText = ""
    private var ownedSearchResults: [PropertyDetails] = []
    private var ownedSearchID = UUID()

    @ObservationIgnored
    var dismiss: DismissAction?

    @ObservationIgnored
    @Injected(\.searchService)
    private var searchService: any SearchServiceProtocol
    @ObservationIgnored
    @Injected(\.workspaceService)
    private var workspaceService: any WorkspaceServiceProtocol
    @ObservationIgnored
    @Injected(\.dataviewService)
    private var dataviewService: any DataviewServiceProtocol
    @ObservationIgnored
    @Injected(\.propertiesService)
    private var propertiesService: any PropertiesServiceProtocol
    @ObservationIgnored
    @Injected(\.objectActionsService)
    private var objectActionsService: any ObjectActionsServiceProtocol

    @ObservationIgnored
    private let data: PropertiesSearchData
    @ObservationIgnored
    @Injected(\.propertyDetailsStorage)
    private var propertyDetailsStorage: any PropertyDetailsStorageProtocol
    
    init(data: PropertiesSearchData) {
        self.data = data
    }

    private var searchExcludedIds: [String] {
        data.excludedRelationsIds.filter { !data.hiddenRelationsIds.contains($0) }
    }

    func isInstalledButHidden(_ relationId: String) -> Bool {
        data.hiddenRelationsIds.contains(relationId)
    }
    
    func search(text: String) async {
        if let scope = data.originalEditorScope {
            await searchOriginalProperties(text: text, scope: scope)
            return
        }
        lastSearchText = text
        let propertyFormats = SupportedPropertyFormat.allCases.filter {
            if text.isEmpty { return true }
            return $0.title.lowercased().contains(text.lowercased())
        }

        // Await settled internal identity (canonical + order) before filtering to prevent leaks on cold start
        let internalIdentity = await PinkhaTorahPropertyPolicy.shared.awaitInternalIdentity(spaceId: data.spaceId)

        let isEligibleForNative = await PinkhaTorahPropertyPolicy.shared.canAddPropertyAsync(
            propertyId: "", key: TorahNativePropertyDefinition.all[0].key, target: data.target, spaceId: data.spaceId
        )

        let rawExistingProperties = (try? await searchService.searchRelations(text: text, excludedIds: searchExcludedIds, spaceId: data.spaceId)) ?? []
        let existingProperties = rawExistingProperties.filter {
            if PinkhaTorahPropertyPolicy.shared.isInternalProperty(propertyId: $0.id, key: $0.key, spaceId: data.spaceId) {
                return false
            }
            if TorahNativePropertyDefinition.definition(for: $0.key) != nil {
                return false
            }
            return true
        }

        let nativeProperties = await PinkhaTorahNativePropertyCatalog.shared.searchNativeProperties(
            text: text,
            excludedIds: searchExcludedIds,
            target: data.target,
            spaceId: data.spaceId
        )

        if case .unavailable = internalIdentity {
            nativeLookupFailed = true
        } else {
            nativeLookupFailed = isEligibleForNative && !PinkhaTorahNativePropertyCatalog.shared.lastLookupDiagnostics(spaceId: data.spaceId).isEmpty
        }

        // Deduplicate by real Property ID and key so native descriptors and existing properties do not collide
        var seenIds = Set<String>()
        var seenKeys = Set<String>()
        var deduplicated: [PropertyDetails] = []

        for prop in (nativeProperties + existingProperties) {
            if seenIds.contains(prop.id) || (!prop.key.isEmpty && seenKeys.contains(prop.key)) {
                continue
            }
            seenIds.insert(prop.id)
            if !prop.key.isEmpty { seenKeys.insert(prop.key) }
            deduplicated.append(prop)
        }
        let combinedExisting = deduplicated
        
        rows = .builder {
            if propertyFormats.isNotEmpty {
                SearchDataSection(
                    searchData: propertyFormats.map{ PropertySearchData.new($0) },
                    sectionName: Loc.propertiesFormats
                )
            }
            
            if combinedExisting.isNotEmpty {
                SearchDataSection(
                    searchData: combinedExisting.map{ PropertySearchData.existing($0) },
                    sectionName: Loc.existingProperties
                )
            }
        }
    }
    
    func retryNativeLookup() async {
        if data.originalEditorScope != nil {
            await search(text: lastSearchText)
            return
        }
        PinkhaTorahNativePropertyCatalog.shared.invalidate(spaceId: data.spaceId)
        await search(text: lastSearchText)
    }

    func onRowTap(_ row: PropertySearchData) {
        if let scope = data.originalEditorScope {
            onOriginalRowTap(row, scope: scope)
            return
        }
        Task {
            switch row {
            case .existing(let details):
                guard await PinkhaTorahPropertyPolicy.shared.canAddPropertyAsync(
                    propertyId: details.id, key: details.key, target: data.target, spaceId: data.spaceId
                ) else { return }
                try await onExistingPropertyTap(details)
                try? await objectActionsService.updateBundledDetails(contextID: details.id, details: [ .lastUsedDate(Date.now)])
                
                data.onRelationSelect(details, false) // isNew = false
                dismiss?()
            case .new(let format):
                newPropertyData = PropertyInfoData(
                    name: "",
                    objectId: data.objectId,
                    spaceId: data.spaceId,
                    target: data.target,
                    mode: .create(format: format),
                    isReadOnly: false
                )
            }
        }
    }
    
    func onNewPropertyTap(name: String) {
        if let scope = data.originalEditorScope {
            presentOriginalProperty(name: name, format: .text, scope: scope)
            return
        }
        newPropertyData = PropertyInfoData(
            name: name,
            objectId: data.objectId,
            spaceId: data.spaceId,
            target: data.target,
            mode: .create(format: .text),
            isReadOnly: false
        )
    }
    
    // MARK: - PropertyInfoCoordinatorViewOutput
    func didPressConfirm(_ relation: PropertyDetails) {
        if let scope = data.originalEditorScope {
            do {
                try scope.withActionCallback(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                    guard !relation.id.isEmpty, !relation.key.isEmpty,
                          relation.spaceId.utf8.elementsEqual(scope.spaceId.utf8) else {
                        throw OriginalEditorPropertyModalError.invalidPropertyIdentity
                    }
                    data.onRelationSelect(relation, true)
                    dismiss?()
                }
            } catch { reportPreparedFailure(scope) }
            return
        }
        data.onRelationSelect(relation, true) // isNew = true
        dismiss?()
    }
    
    // MARK: - Private
    
    private func onExistingPropertyTap(_ details: PropertyDetails) async throws {
        switch data.target {
        case let .type(typeData):
            try await addPropertyToType(relation: details, typeData: typeData)
        case let .dataview(objectId, activeViewId, typeDetails):
            try await addPropertyToDataview(objectId: objectId, relation: details, activeViewId: activeViewId, typeDetails: typeDetails)
        case .object(let objectId):
            try await addPropertyToObject(objectId: objectId, relation: details)
        case .library:
            break
        }
    }
    
    private func addPropertyToType(relation: PropertyDetails, typeData: PropertiesModuleTypeData) async throws {
        if isInstalledButHidden(relation.id) {
            switch typeData {
            case .recommendedFeaturedRelations(let type):
                try await propertiesService.revealTypeHiddenProperty(type: type, property: relation, featured: true)
            case .recommendedRelations(let type):
                try await propertiesService.revealTypeHiddenProperty(type: type, property: relation, featured: false)
            }
            return
        }
        switch typeData {
        case .recommendedFeaturedRelations(let type):
            try await propertiesService.addTypeFeaturedRecommendedProperty(type: type, property: relation)
        case .recommendedRelations(let type):
            try await propertiesService.addTypeRecommendedProperty(type: type, property: relation)
        }
    }
    
    private func addPropertyToDataview(objectId: String, relation: PropertyDetails, activeViewId: String, typeDetails: ObjectDetails?) async throws {
        let doc = Container.shared.openedDocumentProvider().document(objectId: objectId, spaceId: data.spaceId)
        let dataviewBlock: BlockDataview? = {
            guard let blockInfo = doc.infoContainer.get(id: SetConstants.dataviewBlockId),
                  case .dataView(let dv) = blockInfo.content else {
                return nil
            }
            return dv
        }()
        let alreadyInDataviewLinks = dataviewBlock?.relationLinks.contains(where: { $0.key == relation.key }) ?? false
        let activeView = dataviewBlock?.views.first(where: { $0.id == activeViewId })
        let alreadyInViewOptions = activeView?.options.contains(where: { $0.key == relation.key }) ?? false

        if !isInstalledButHidden(relation.id) && !alreadyInDataviewLinks {
            if let typeDetails {
                let type = ObjectType(details: typeDetails)
                try await addPropertyToType(relation: relation, typeData: .recommendedRelations(type))
            } else {
                try await dataviewService.addRelation(objectId: objectId, blockId: SetConstants.dataviewBlockId, relationDetails: relation)
            }
        } else if let typeDetails, isInstalledButHidden(relation.id) {
            let type = ObjectType(details: typeDetails)
            if type.recommendedHiddenRelations.contains(relation.id) {
                try await propertiesService.revealTypeHiddenProperty(type: type, property: relation, featured: false)
            }
        }
        
        let visibleOption = DataviewRelationOption(key: relation.key, isVisible: true).asMiddleware
        if alreadyInViewOptions {
            try await dataviewService.replaceViewRelation(
                objectId: objectId,
                blockId: SetConstants.dataviewBlockId,
                key: relation.key,
                with: visibleOption,
                viewId: activeViewId
            )
        } else {
            try await dataviewService.addViewRelation(
                objectId: objectId,
                blockId: SetConstants.dataviewBlockId,
                relation: visibleOption,
                viewId: activeViewId
            )
        }
    }
    
    func addPropertyToObject(objectId: String, relation: PropertyDetails) async throws {
        if let scope = data.originalEditorScope {
            try scope.requireModalTarget(.object(objectId: objectId), spaceId: data.spaceId)
            let identity = try await scope.loadModalPropertyIdentity()
            try scope.requireModalProperty(relation, identity: identity)
            let original = try scope.originalProperties(propertiesService)
            return try await scope.perform(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                try await original.addProperties(objectId: objectId, propertiesDetails: [relation])
            }
        }
        try await propertiesService.addProperties(objectId: objectId, propertiesDetails: [relation])
    }

    private func searchOriginalProperties(text: String, scope: OriginalEditorPropertyScope) async {
        let searchID = UUID()
        do {
            try scope.requireModalTarget(data.target, spaceId: data.spaceId)
            try scope.withCurrent(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                ownedSearchID = searchID
                lastSearchText = text
                ownedSearchResults = []
                rows = []
                preparedRouteUnavailable = false
            }
            let identity = try await scope.loadModalPropertyIdentity()
            guard let original = searchService as? SearchService else {
                throw OriginalEditorPropertyModalError.unsupportedOriginalDelegate
            }
            let excludedIds = searchExcludedIds
            let result = try await scope.owner.performRead(
                contextId: scope.objectId, spaceId: scope.spaceId,
                rpcNames: ["ObjectSearch"], requiredPermissions: OriginalEditorPropertyScope.listPermissions
            ) {
                try await original.searchRelations(text: text, excludedIds: excludedIds, spaceId: scope.spaceId)
            }
            try Task.checkCancellation()
            try scope.withCurrent(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                guard ownedSearchID == searchID else { return }
                let existing = result.filter { (try? scope.requireModalProperty($0, identity: identity)) != nil }
                let formats = SupportedPropertyFormat.allCases.filter {
                    text.isEmpty || $0.title.lowercased().contains(text.lowercased())
                }
                ownedSearchResults = existing
                rows = .builder {
                    if formats.isNotEmpty {
                        SearchDataSection(searchData: formats.map { PropertySearchData.new($0) }, sectionName: Loc.propertiesFormats)
                    }
                    if existing.isNotEmpty {
                        SearchDataSection(searchData: existing.map { PropertySearchData.existing($0) }, sectionName: Loc.existingProperties)
                    }
                }
            }
        } catch {
            guard ownedSearchID == searchID else { return }
            reportPreparedFailure(scope)
        }
    }

    private func presentOriginalProperty(name: String, format: SupportedPropertyFormat,
                                         scope: OriginalEditorPropertyScope) {
        do {
            try scope.requireModalTarget(data.target, spaceId: data.spaceId)
            try scope.withCurrent(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                newPropertyData = PropertyInfoData(
                    name: name, objectId: data.objectId, spaceId: data.spaceId,
                    target: data.target, mode: .create(format: format), isReadOnly: false,
                    originalEditorScope: scope
                )
            }
        } catch { reportPreparedFailure(scope) }
    }

    private func onOriginalRowTap(_ row: PropertySearchData, scope: OriginalEditorPropertyScope) {
        switch row {
        case .new(let format):
            presentOriginalProperty(name: "", format: format, scope: scope)
        case .existing(let selected):
            // Reserve before Task creation. Selection comes from this current
            // native search result; its property document is then opened anew.
            let action = scope.prepareAction(requiredPermissions: OriginalEditorPropertyScope.listPermissions) { [self] in
                try scope.requireModalTarget(data.target, spaceId: data.spaceId)
                guard ownedSearchResults.contains(where: {
                    $0.id.utf8.elementsEqual(selected.id.utf8) &&
                    $0.key.utf8.elementsEqual(selected.key.utf8) &&
                    $0.spaceId.utf8.elementsEqual(selected.spaceId.utf8)
                }) else { throw OriginalEditorPropertyModalError.invalidPropertyIdentity }
                let original = try OriginalObjectActionsServiceBinding.requireOriginal(objectActionsService)
                let originalProperties = try scope.originalProperties(propertiesService)
                let actual = try await scope.withSelectedModalProperty(
                    id: selected.id, requiredPermissions: [.editDetails],
                    beforeMutation: { [self] actual in
                        guard actual.key.utf8.elementsEqual(selected.key.utf8), actual.format == selected.format else {
                            throw OriginalEditorPropertyModalError.invalidPropertyIdentity
                        }
                        try await scope.perform(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                            try await originalProperties.addProperties(objectId: scope.objectId, propertiesDetails: [actual])
                        }
                    }
                ) { _, actual, _ in
                    try await original.updateBundledDetails(contextID: actual.id, details: [.lastUsedDate(Date.now)])
                    return actual
                }
                try scope.withActionCallback(requiredPermissions: OriginalEditorPropertyScope.listPermissions) {
                    data.onRelationSelect(actual, false)
                    dismiss?()
                }
            }
            Task { [self] in
                do { try await action() }
                catch { reportPreparedFailure(scope) }
            }
        }
    }

    private func reportPreparedFailure(_ scope: OriginalEditorPropertyScope) {
        try? scope.withCurrent {
            preparedRouteUnavailable = true
        }
    }
}
