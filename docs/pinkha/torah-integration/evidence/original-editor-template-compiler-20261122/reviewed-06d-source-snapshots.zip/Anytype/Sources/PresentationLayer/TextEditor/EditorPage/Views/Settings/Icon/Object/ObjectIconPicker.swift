import SwiftUI
import AnytypeCore

struct ObjectIconPicker: View {

    @State var viewModel: ObjectIconPickerViewModel

    init(data: ObjectIconPickerData, dependencies: ObjectHeaderViewModelDependencies = .original()) {
        _viewModel = State(initialValue: ObjectIconPickerViewModel(data: data, dependencies: dependencies))
    }

    var body: some View {
        Group {
            switch viewModel.detailsLayout {
            case .basic, .set, .collection, .file, .image, .chatDerived:
                ObjectBasicIconPicker(
                    isRemoveButtonAvailable: viewModel.isRemoveButtonAvailable,
                    mediaPickerContentType: viewModel.mediaPickerContentType,
                    onSelectItemProvider: { itemProvider in
                        viewModel.uploadImage(from: itemProvider)
                    },
                    onSelectEmoji: { emoji in
                        viewModel.setEmoji(emoji.emoji)
                    },
                    removeIcon: {
                        viewModel.removeIcon()
                    }
                )
            case .objectType:
                ObjectTypeIconPicker(
                    isRemoveButtonAvailable: viewModel.isRemoveButtonAvailable,
                    onIconSelect: { icon, color in
                        viewModel.setIcon(icon, color: color)
                    }, removeIcon: {
                        viewModel.removeIcon()
                    })
            case .profile, .participant:
                ObjectProfileIconPicker(
                    isRemoveEnabled: viewModel.isRemoveEnabled,
                    mediaPickerContentType: viewModel.mediaPickerContentType,
                    onSelectItemProvider: { itemProvider in
                        viewModel.uploadImage(from: itemProvider)
                    },
                    removeIcon: {
                        viewModel.removeIcon()
                    }
                )
            case nil:
                EmptyView()
            case .todo, .note, .bookmark, .UNRECOGNIZED, .relation, .relationOption,
                    .dashboard, .relationOptionsList, .audio, .video, .pdf, .date, .space,
                    .spaceView, .tag, .chatDeprecated, .notification, .missingObject, .devices,
                    .discussion:
                EmptyView()
                    .onAppear {
                        anytypeAssertionFailure("Not supported layout")
                    }
            }
        }
        .task {
            await viewModel.startSubscription()
        }
    }
}
