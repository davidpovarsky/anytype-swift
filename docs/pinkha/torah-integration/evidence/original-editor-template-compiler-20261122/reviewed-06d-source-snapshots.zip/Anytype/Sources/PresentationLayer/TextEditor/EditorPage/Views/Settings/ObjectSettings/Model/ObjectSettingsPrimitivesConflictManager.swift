import Services


// Manages edje-cases of primitives project migration
protocol ObjectSettingsPrimitivesConflictManagerProtocol: Sendable {
    func haveLayoutConflicts(details: ObjectDetails) -> Bool
    func resolveConflicts(details: ObjectDetails) async throws
}

final class ObjectSettingsPrimitivesConflictManager: ObjectSettingsPrimitivesConflictManagerProtocol {
    private let objectTypeProvider: any ObjectTypeProviderProtocol = Container.shared.objectTypeProvider()
    private let propertyDetailsStorage: any PropertyDetailsStorageProtocol = Container.shared.propertyDetailsStorage()
    private let propertiesService: any PropertiesServiceProtocol = Container.shared.propertiesService()
    
    func haveLayoutConflicts(details: ObjectDetails) -> Bool {
        guard !details.isObjectType else { return false }
        
        let typeId = details.isTemplate ? details.targetObjectType : details.type
        guard let type = try? objectTypeProvider.objectType(id: typeId) else { return false }
        let layoutsInObjectAndTypeAreDifferent = details.resolvedLayoutValue != type.recommendedLayout
        let layoutAlignInObjectAndTypeAreDifferent = details.layoutAlignValue != type.layoutAlign
        if layoutsInObjectAndTypeAreDifferent || layoutAlignInObjectAndTypeAreDifferent { return true }
        
        let typeFeaturedRelationKeys = details.objectType.recommendedFeaturedRelationsDetails
            .map(\.key)
            .filter { $0 != BundledPropertyKey.description.rawValue } // Filter out description - currently we use object featured relation to store its visibility
        let objectFeaturedRelationKeys = propertyDetailsStorage
            .relationsDetails(keys: details.featuredRelations, spaceId: details.spaceId)
            .map(\.key)
            .filter { $0 != BundledPropertyKey.description.rawValue } // Filter out description - currently we use object featured relation to store its visibility
            
        let featuredRelationsInObjectAndTypeAreDifferent = typeFeaturedRelationKeys != objectFeaturedRelationKeys
        
        if objectFeaturedRelationKeys.isNotEmpty && featuredRelationsInObjectAndTypeAreDifferent { return true }
        
        return false
    }
    
    func resolveConflicts(details: ObjectDetails) async throws {
        // Remove legacy relations
        try await propertiesService.removeProperty(objectId: details.id, propertyKey: BundledPropertyKey.layout.rawValue)
        try await propertiesService.removeProperty(objectId: details.id, propertyKey: BundledPropertyKey.layoutAlign.rawValue)
        try await propertiesService.removeProperty(objectId: details.id, propertyKey: BundledPropertyKey.layoutWidth.rawValue)
        
        // Remove all legacy relations except for description if present (description uses legacy mechanism to preserve its visibility)
        let featuredRelationIds = propertyDetailsStorage
            .relationsDetails(keys: details.featuredRelations, spaceId: details.spaceId)
                .filter { $0.key == BundledPropertyKey.description.rawValue }
                .map(\.id)
        try await propertiesService.setFeaturedProperty(objectId: details.id, featuredPropertyIds: featuredRelationIds)
    }
}

/// A prepared Host keeps the original migration implementation and its captured
/// original Properties delegate. This validates identity; it grants no authority.
enum OriginalObjectSettingsConflictManagerBinding {
    static func requireOriginal(
        _ manager: any ObjectSettingsPrimitivesConflictManagerProtocol
    ) throws -> any ObjectSettingsPrimitivesConflictManagerProtocol {
        guard let original = manager as? ObjectSettingsPrimitivesConflictManager else {
            throw EditorDocumentWriteError.rejected(.unqualifiedDispatch)
        }
        try original.validateOriginalPropertiesDelegate()
        return original
    }
}

private extension ObjectSettingsPrimitivesConflictManager {
    func validateOriginalPropertiesDelegate() throws {
        _ = try OriginalPropertiesServiceBinding.requireOriginal(propertiesService)
    }
}

extension Container {
    var objectSettingsConflictManager: Factory<any ObjectSettingsPrimitivesConflictManagerProtocol> {
        self { ObjectSettingsPrimitivesConflictManager() }.shared
    }
}
