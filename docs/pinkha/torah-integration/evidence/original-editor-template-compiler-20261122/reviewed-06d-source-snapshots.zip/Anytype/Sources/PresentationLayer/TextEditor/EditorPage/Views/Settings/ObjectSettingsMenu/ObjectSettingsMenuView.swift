import SwiftUI
import AnytypeCore
import Services

struct ObjectSettingsMenuView<LabelView: View, AdditionalMenuItems: View>: View {

    @State private var viewModel: ObjectSettingsMenuViewModel
    private let labelView: LabelView
    private let additionalMenuItems: AdditionalMenuItems

    init(
        objectId: String,
        spaceId: String,
        output: some ObjectSettingsModelOutput,
        quickCapture: Bool = false,
        preparedSession: PreparedEditorPageSession? = nil,
        @ViewBuilder labelView: () -> LabelView,
        @ViewBuilder additionalMenuItems: () -> AdditionalMenuItems
    ) {
        let vm = ObjectSettingsViewModel(objectId: objectId, spaceId: spaceId, output: output,
                                        quickCapture: quickCapture, preparedSession: preparedSession)
        self._viewModel = State(wrappedValue: ObjectSettingsMenuViewModel(viewModel: vm, quickCapture: quickCapture))
        self.labelView = labelView()
        self.additionalMenuItems = additionalMenuItems()
    }

    var body: some View {
        Menu {
            let sections = viewModel.menuConfig.sections
            let additionalItemsIndex = sections.firstIndex { $0.layout != .horizontal }
            ForEach(Array(sections.enumerated()), id: \.element.id) { index, section in
                if section.showDividerBefore {
                    Divider()
                }
                if index == additionalItemsIndex {
                    additionalMenuItems
                }
                renderSection(section)
            }
            if additionalItemsIndex == nil {
                additionalMenuItems
            }
        } label: {
            labelView
        }
        .task {
            await viewModel.startTasks()
        }
        .anytypeSheet(isPresented: viewModel.showConflictAlert) {
            ObjectSettingsResolveConflictAlert(
                prepareAction: viewModel.viewModel.hasPreparedSource ? { viewModel.prepareConflictReset() } : nil,
                publish: viewModel.viewModel.hasPreparedSource ? { action in
                    try viewModel.viewModel.withCurrentSource(action)
                } : nil
            ) {
                try await viewModel.onTapResolveConflictApprove()
            }
        }
        .anytypeSheet(isPresented: viewModel.showDeleteChatConfirmation) {
            ChatDeleteChatAlert(
                prepareAction: viewModel.viewModel.hasPreparedSource ? { viewModel.prepareArchiveConfirmation() } : nil,
                publish: viewModel.viewModel.hasPreparedSource ? { action in
                    try viewModel.viewModel.withCurrentSource(action)
                } : nil
            ) {
                try await viewModel.viewModel.changeArchiveState()
            }
        }
        .snackbar(toastBarData: viewModel.toastData)
    }

    @ViewBuilder
    private func renderSection(_ section: ObjectMenuSection) -> some View {
        switch section.layout {
        case .horizontal:
            ControlGroup {
                ForEach(section.items) { item in
                    renderMenuItem(item)
                }
            }
            .controlGroupStyle(.menu)
        case .collapsible:
            Menu {
                ForEach(section.items) { item in
                    renderMenuItem(item)
                }
            } label: {
                Label {
                    Text(Loc.more)
                } icon: {
                    Image(asset: .X24.more)
                        .renderingMode(.template)
                        .foregroundStyle(Color.Text.primary)
                }
            }
        case .vertical:
            ForEach(section.items) { item in
                renderMenuItem(item)
            }
        }
    }

    @ViewBuilder
    private func renderMenuItem(_ item: ObjectMenuItem) -> some View {
        switch item {
        case .setting(let setting):
            settingMenuItem(setting)
        case .action(let action):
            Button(role: viewModel.isDestructiveAction(action) ? .destructive : nil) {
                viewModel.scheduleAction(action)
            } label: {
                Label {
                    Text(action.title)
                } icon: {
                    if viewModel.isDestructiveAction(action) {
                        menuIconImage(action.menuIcon)
                    } else {
                        menuIconImage(action.menuIcon)
                            .foregroundStyle(Color.Text.primary)
                    }
                }
            }
            .accessibilityIdentifier("editor-object-action-\(action.id)")
        }
    }

    @ViewBuilder
    private func settingMenuItem(_ setting: ObjectSetting) -> some View {
        switch setting {
        case .notifications(let mode):
            notificationsMenuItem(mode: mode)
        default:
            defaultSettingMenuItem(setting)
        }
    }

    private func notificationsMenuItem(mode: SpacePushNotificationsMode) -> some View {
        NotificationModeMenu(
            currentMode: mode,
            onModeChange: viewModel.handleNotificationModeChange,
            useMuteAndHideLabel: true
        )
    }

    private func defaultSettingMenuItem(_ setting: ObjectSetting) -> some View {
        Button {
            viewModel.scheduleSetting(setting)
        } label: {
            Label {
                Text(setting.title)
            } icon: {
                menuIconImage(setting.menuIcon)
                    .foregroundStyle(Color.Text.primary)
            }
        }
    }

    @ViewBuilder
    private func menuIconImage(_ icon: MenuIcon) -> some View {
        switch icon {
        case .asset(let asset):
            Image(asset: asset).renderingMode(.template)
        case .system(let name):
            Image(systemName: name)
        }
    }

}
