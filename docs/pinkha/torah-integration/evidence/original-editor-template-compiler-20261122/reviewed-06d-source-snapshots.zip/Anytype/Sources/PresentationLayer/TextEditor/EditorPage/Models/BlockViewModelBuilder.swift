import Services
import Combine
import UniformTypeIdentifiers
import AnytypeCore

@MainActor
final class BlockViewModelBuilder {
    private let document: any BaseDocumentProtocol
    private let handler: any BlockActionHandlerProtocol
    private let router: any EditorRouterProtocol
    private let subjectsHolder: FocusSubjectsHolder
    private let markdownListener: any MarkdownListener
    private let simpleTableDependenciesBuilder: SimpleTableDependenciesBuilder
    private let infoContainer: any InfoContainerProtocol
    private let modelsHolder: EditorMainItemModelsHolder
    // Fork aliases for this page; consulted at build time so a stale id resolves to the
    // block living on its row and a rebuilt model lands on the replaced row's identity.
    private let rowIdentityMap: BlockRowIdentityMap
    // Applies/reverts the empty-block identity fork on the live row; handed to every text
    // block handler, which initiates the fork synchronously at the first keystroke.
    private let forkRebinder: BlockForkRebinder
    private let blockCollectionController: EditorBlockCollectionController
    private let accessoryStateManager: any AccessoryViewStateManager
    private let cursorManager: EditorCursorManager
    private let keyboardActionHandler: any KeyboardActionHandlerProtocol
    private let editorPageBlocksStateManager: EditorPageBlocksStateManager
    private let markupChanger: any BlockMarkupChangerProtocol
    private let slashMenuActionHandler: SlashMenuActionHandler
    private let mediaBlockActionsProvider: any MediaBlockActionsProviderProtocol
    private weak var output: (any EditorPageModuleOutput)?
    private weak var torahSession: TorahEditorSession?
    private var documentMetadataRow: PinkhaDocumentMetadataRowModel?
    
    private let tableService: any BlockTableServiceProtocol
    private let detailsService: any DetailsServiceProtocol
    private let audioSessionService: any AudioSessionServiceProtocol
    private let objectTypeProvider: any ObjectTypeProviderProtocol
    private let pasteboardService: any PasteboardBlockDocumentServiceProtocol
    private let blockService: any BlockServiceProtocol
    
    init(
        document: some BaseDocumentProtocol,
        handler: some BlockActionHandlerProtocol,
        router: some EditorRouterProtocol,
        markdownListener: some MarkdownListener,
        simpleTableDependenciesBuilder: SimpleTableDependenciesBuilder,
        subjectsHolder: FocusSubjectsHolder,
        infoContainer: some InfoContainerProtocol,
        modelsHolder: EditorMainItemModelsHolder,
        rowIdentityMap: BlockRowIdentityMap,
        forkRebinder: BlockForkRebinder,
        blockCollectionController: EditorBlockCollectionController,
        accessoryStateManager: some AccessoryViewStateManager,
        cursorManager: EditorCursorManager,
        keyboardActionHandler: some KeyboardActionHandlerProtocol,
        markupChanger: some BlockMarkupChangerProtocol,
        slashMenuActionHandler: SlashMenuActionHandler,
        mediaBlockActionsProvider: some MediaBlockActionsProviderProtocol,
        editorPageBlocksStateManager: EditorPageBlocksStateManager,
        torahSession: TorahEditorSession? = nil,
        output: (any EditorPageModuleOutput)?,
        dependencies: BlockViewModelBuilderDependencies = .original()
    ) {
        self.document = document
        self.handler = handler
        self.router = router
        self.markdownListener = markdownListener
        self.simpleTableDependenciesBuilder = simpleTableDependenciesBuilder
        self.subjectsHolder = subjectsHolder
        self.infoContainer = infoContainer
        self.modelsHolder = modelsHolder
        self.rowIdentityMap = rowIdentityMap
        self.forkRebinder = forkRebinder
        self.blockCollectionController = blockCollectionController
        self.accessoryStateManager = accessoryStateManager
        self.cursorManager = cursorManager
        self.keyboardActionHandler = keyboardActionHandler
        self.markupChanger = markupChanger
        self.slashMenuActionHandler = slashMenuActionHandler
        self.mediaBlockActionsProvider = mediaBlockActionsProvider
        self.editorPageBlocksStateManager = editorPageBlocksStateManager
        self.torahSession = torahSession
        self.output = output
        self.tableService = dependencies.tableService
        self.detailsService = dependencies.detailsService
        self.audioSessionService = dependencies.audioSessionService
        self.objectTypeProvider = dependencies.objectTypeProvider
        self.pasteboardService = dependencies.pasteboardService
        self.blockService = dependencies.blockService
    }
    
    func buildEditorItems(infos: [String], ignoreCache: Bool) -> [EditorItem] {
        let viewModels = build(infos, ignoreCache: ignoreCache)
        return buildEditorItems(viewModels)
    }
    
    func buildEditorItems(_ viewModels: [any BlockViewModelProtocol]) -> [EditorItem] {
        var items = viewModels.map(EditorItem.block)
        
        items = removeBlockFileIfNeeded(items)
        let featureRelationsIndex = viewModels.firstIndex { $0.content == .featuredRelations }
        let openFileButton = createOpenFileButtonIfNeeded()
        let spacer = SpacerBlockViewModel(usage: .firstRowOffset)
        
        if let featureRelationsIndex, let openFileButton  {
            items.insert(openFileButton, at: featureRelationsIndex + 1)
            items.insert(.system(spacer), at: featureRelationsIndex + 2)
        } else if let featureRelationsIndex  {
            items.insert(.system(spacer), at: featureRelationsIndex + 1)
        } else if let openFileButton, items.count > 0 {
            items.insert(openFileButton, at: 1)
            items.insert(.system(spacer), at: 2)
        }
        
        if let torahSession, let index = PinkhaDocumentMetadataRowModel.insertionIndex(in: items) {
            let row: PinkhaDocumentMetadataRowModel
            if let existing = documentMetadataRow {
                row = existing
            } else {
                row = PinkhaDocumentMetadataRowModel(document: document, session: torahSession) { [weak self] relation in
                    self?.handleFeaturedRelationTap(relation)
                }
                documentMetadataRow = row
            }
            items.insert(.system(row), at: index)
            if !items.contains(where: { $0.blockId == spacer.blockId }) {
                items.insert(.system(spacer), at: index + 1)
            }
        }

        return items
    }
    
    // temporary hack to display open button for files
    // remove after https://linear.app/anytype/issue/IOS-3806/%5Bepic%5D-release-x-or-ios-or-file-layout
    private func createOpenFileButtonIfNeeded() -> EditorItem? {
        guard let details = document.details else { return nil }
        guard details.resolvedLayoutValue.isFileOrMedia else { return nil }
        
        let model = OpenFileBlockViewModel(
            info: .file(fileDetails: FileDetails(objectDetails: details)),
            documentId: document.objectId,
            spaceId: document.spaceId
        ) { [weak router] data in
            router?.showEditorScreen(data: data)
        }
        
        return EditorItem.block(model)
    }
    
    // temporary hack to hide block file for files
    // remove after https://linear.app/anytype/issue/IOS-3806/%5Bepic%5D-release-x-or-ios-or-file-layout
    private func removeBlockFileIfNeeded(_ items: [EditorItem]) -> [EditorItem] {
        guard let details = document.details else { return items }
        guard details.resolvedLayoutValue.isFileOrMedia else { return items }
        
        let index = items.firstIndex { item in
            if case let .block(block) = item {
                return block.info.isFile
            }
            return false
        }
        
        guard let index else { return items }
        
        var items = items
        items.remove(at: index)
        return items
    }
    
    func buildShimeringItem() -> EditorItem {
        let shimmeringViewModel = ShimmeringBlockViewModel()

        return .system(shimmeringViewModel)
    }

    func buildVirtualTrailingItem(blockId: String, session: some VirtualTrailingBlockSessionProtocol) -> EditorItem? {
        guard let info = infoContainer.get(id: blockId) else { return nil }
        let blockInformationProvider = BlockModelInfomationProvider(document: document, info: info)
        let viewModel = makeTextBlockViewModel(
            info: info,
            blockInformationProvider: blockInformationProvider,
            virtualBlockSession: session
        )
        return .block(viewModel)
    }

    private func makeTextBlockViewModel(
        info: BlockInformation,
        blockInformationProvider: BlockModelInfomationProvider,
        virtualBlockSession: (any VirtualTrailingBlockSessionProtocol)? = nil
    ) -> TextBlockViewModel {
        let textBlockActionHandler = TextBlockActionHandler(
            document: document,
            info: info,
            focusSubject: subjectsHolder.focusSubject(for: info.id),
            showObject: { [weak self] objectId in
                self?.router.showObject(objectId: objectId)
            },
            openURL: { [weak output] url in
                output?.openUrl(url)
            },
            onShowStyleMenu: { [weak self] blockInformation in
                Task { @MainActor [weak self] in
                    self?.editorPageBlocksStateManager.didSelectStyleSelection(infos: [blockInformation])
                }
            },
            onEnterSelectionMode: { [weak self] blockInformation in
                Task { @MainActor [weak self] in
                    self?.editorPageBlocksStateManager.didSelectEditingState(info: blockInformation)
                }

            },
            onSelectUndoRedo: { [weak self] in
                self?.output?.didUndoRedo()
            },
            onDeleteBlock: { [weak self] blockInformation in
                self?.handler.delete(blockIds: [blockInformation.id])
            },
            onIndentLeft: { [weak self] blockInformation in
                self?.indentLeft(blockInformation: blockInformation)
            },
            onIndentRight: { [weak self] blockInformation in
                self?.indentRight(blockInformation: blockInformation)
            },
            showTextIconPicker: { [weak router, weak document] in
                guard let router, let document else { return }
                router.showTextIconPicker(
                    contextId: document.objectId,
                    objectId: info.id
                )
            },
            showWaitingView: { [weak router] text in
                router?.showWaitingView(text: text)
            },
            hideWaitingView: {  [weak router] in
                router?.hideWaitingView()
            },
            showURLBookmarkPopup: { [weak router] parameters in
                router?.showLinkContextualMenu(inputParameters: parameters)
            },
            actionHandler: handler,
            pasteboardService: pasteboardService,
            markdownListener: markdownListener,
            collectionController: blockCollectionController,
            cursorManager: cursorManager,
            accessoryViewStateManager: accessoryStateManager,
            keyboardHandler: keyboardActionHandler,
            markupChanger: markupChanger,
            slashMenuActionHandler: slashMenuActionHandler,
            openLinkToObject: { [weak self] data in
                self?.output?.showLinkToObject(data: data)
            },
            virtualBlockSession: virtualBlockSession,
            rebindForkedBlock: { [weak forkRebinder] oldInfo, replacement in
                forkRebinder?.rebind(oldInfo: oldInfo, to: replacement) ?? false
            },
            rollbackForkedBlockRebind: { [weak forkRebinder] replacementId, oldId in
                forkRebinder?.rollbackFailedFork(replacementId: replacementId, oldId: oldId)
            },
            reconfigureLiveBlock: { [weak modelsHolder, weak blockCollectionController] blockId in
                guard let model = modelsHolder?.blocksMapping[blockId] else { return }
                blockCollectionController?.reconfigure(items: [.block(model)])
            }
        )
        let viewModel = TextBlockViewModel(
            document: document,
            blockInformationProvider: blockInformationProvider,
            actionHandler: textBlockActionHandler,
            cursorManager: cursorManager,
            rowIdentity: rowIdentityMap.rowId(for: info.id),
            collectionController: blockCollectionController
        )

        textBlockActionHandler.viewModel = viewModel

        return viewModel
    }
    
    private func build(_ ids: [String], ignoreCache: Bool) -> [any BlockViewModelProtocol] {
        ids.compactMap {
            let block = build(blockId: $0, ignoreCache: ignoreCache)
            return block
        }
    }
    
    func build(blockId: String, ignoreCache: Bool) -> (any BlockViewModelProtocol)? {
        // A just-forked block can still be requested under its replaced id (the replace
        // event has not applied yet); the fork chain resolves any stale id to the block
        // living on that row now — for the cache, the info lookup and the row identity.
        let blockId = rowIdentityMap.latestId(for: blockId)
        if !ignoreCache, let model = modelsHolder.blocksMapping[blockId] {
            return model
        }

        guard let info = infoContainer.get(id: blockId) else {
            return nil
        }
        
        let documentId = document.objectId
        let spaceId = document.spaceId
        let blockInformationProvider = BlockModelInfomationProvider(document: document, info: info)
        
        switch info.content {
        case let .text(content):
            switch content.contentType {
            case .code:
                return CodeBlockViewModel(
                    infoProvider: blockInformationProvider,
                    document: document,
                    becomeFirstResponder: { _ in },
                    handler: handler,
                    editorCollectionController: blockCollectionController,
                    showCodeSelection: { [weak self] info in
                        self?.output?.onSelectCodeLanguage(objectId: documentId, spaceId: spaceId, blockId: blockId)
                    }
                )
            default:
                return makeTextBlockViewModel(
                    info: info,
                    blockInformationProvider: blockInformationProvider
                )
            }
        case let .file(content):
            switch content.contentType {
            case .file, .none:
                return BlockFileViewModel(
                    informationProvider: blockInformationProvider,
                    documentId: documentId,
                    spaceId: spaceId,
                    showFilePicker: { [weak self] blockId in
                        self?.mediaBlockActionsProvider.openFilePicker(blockId: blockId)
                    },
                    onFileOpen: { [weak router] data in
                        router?.showEditorScreen(data: data)
                    }
                )
            case .image:
                return BlockImageViewModel(
                    documentId: documentId,
                    spaceId: spaceId,
                    blockInformationProvider: blockInformationProvider,
                    showIconPicker: { [weak self] blockId in
                        self?.mediaBlockActionsProvider.openImagePicker(blockId: blockId)
                    },
                    onImageOpen: { [weak router] data in
                        router?.showEditorScreen(data: data)
                    }
                )
            case .video:
                return VideoBlockViewModel(
                    informantionProvider: blockInformationProvider,
                    audioSessionService: audioSessionService,
                    showVideoPicker: { [weak self] blockId in
                        self?.mediaBlockActionsProvider.openVideoPicker(blockId: blockId)
                    }
                )
            case .audio:
                return AudioBlockViewModel(
                    documentId: documentId,
                    spaceId: spaceId,
                    informationProvider: blockInformationProvider,
                    audioSessionService: audioSessionService,
                    showAudioPicker: { [weak self] blockId in
                        self?.mediaBlockActionsProvider.openAudioPicker(blockId: blockId)
                    }
                )
            }
        case .divider:
            return DividerBlockViewModel(blockInformationProvider: blockInformationProvider)
        case let .bookmark(data):
            
            let details = document.detailsStorage.get(id: data.targetObjectID)
            
            if details?.isDeleted ?? false {
                return NonExistentBlockViewModel(info: info)
            }
            
            return BlockBookmarkViewModel(
                editorCollectionController: blockCollectionController,
                infoProvider: blockInformationProvider,
                document: document,
                showBookmarkBar: { [weak self] info in
                    self?.showBookmarkBar(info: info)
                },
                openUrl: { [weak self] url in
                    AnytypeAnalytics.instance().logBlockBookmarkOpenUrl()
                    self?.output?.openUrl(url.url)
                }
            )
        case .link:
            return BlockLinkViewModel(
                informationProvider: blockInformationProvider,
                document: document,
                blocksController: blockCollectionController,
                detailsService: detailsService,
                openLink: { [weak self] data in
                    self?.router.showEditorScreen(data: data)
                }
            )
        case .featuredRelations:
            return FeaturedPropertiesBlockViewModel(
                infoProvider: blockInformationProvider,
                document: document,
                collectionController: blockCollectionController,
                torahSession: torahSession
            ) { [weak self] relation in
                self?.handleFeaturedRelationTap(relation)
            }
        case let .relation(content):
            let relation = document.parsedProperties.all.first {
                $0.key == content.key
            }
            
            guard let relation = relation else {
                return nil
            }
            
            return PropertyBlockViewModel(
                blockInformationProvider: blockInformationProvider,
                relationProvider: PropertyProvider(
                    relation: relation,
                    relationPublisher: document.parsedPropertiesPublisher
                ),
                collectionController: blockCollectionController
            ) { [weak self] in
                self?.router.showRelationValueEditingView(key: relation.key)
            }
        case .tableOfContents:
            return TableOfContentsViewModel(
                info: info,
                document: document,
                onTap: { [weak self] blockId in
                    self?.blockCollectionController.scrollToTopBlock(blockId: blockId)
                },
                editorCollectionController: blockCollectionController
            )
        case .smartblock, .layout, .tableRow, .tableColumn, .widget,. chat: return nil
        case .table:
            return SimpleTableBlockViewModel(
                info: info,
                simpleTableDependenciesBuilder: simpleTableDependenciesBuilder,
                infoContainer: infoContainer,
                tableService: tableService,
                document: document,
                editorCollectionController: blockCollectionController,
                focusSubject: subjectsHolder.focusSubject(for: info.id)
            )
        case .dataView:
            return DataViewBlockViewModel(
                blockInformationProvider: BlockModelInfomationProvider(
                    document: document,
                    info: info
                ),
                document: document,
                reloadable: blockCollectionController,
                showFailureToast: { [weak self] message in
                    self?.output?.showFailureToast(message: message)
                },
                openSet: { [weak self] data in
                    self?.router.showEditorScreen(data: data)
                }
            )
        case let .embed(content):
            return EmbedBlockViewModel(
                info: info,
                blockContent: content,
                document: document,
                collectionController: blockCollectionController
            )
        case .unsupported:
            guard let parentId = info.configurationData.parentId,
                  let parent = document.infoContainer.get(id: parentId),
                  parent.content.type != .layout(.header)
            else {
                return nil
            }
            
            return UnsupportedBlockViewModel(info: info)
        }
    }
    
    private func handleFeaturedRelationTap(_ relation: Property) {
        if relation.key == BundledPropertyKey.type.rawValue && document.permissions.canChangeType {
            router.showTypes(
                selectedObjectId: document.details?.type,
                onSelect: { [weak self] type in self?.typeSelected(type, route: .featuredRelations) }
            )
        } else {
            router.showRelationValueEditingView(key: relation.key)
        }
    }

    private func typeSelected(_ type: ObjectType, route: ChangeObjectTypeRoute? = nil) {
        handler.scheduleMutationTask { [weak self] in
            guard let self else { return }
            try await handler.setObjectType(type: type)
            AnytypeAnalytics.instance().logChangeObjectType(type.analyticsType, route: route)
            
            guard let isSelectTemplate = document.details?.isSelectTemplate, isSelectTemplate else { return }
            try await handler.applyTemplate(objectId: document.objectId, templateId: type.defaultTemplateId)
        }
    }
    // MARK: - Actions

    private func showBookmarkBar(info: BlockInformation) {
        router.showBookmarkBar() { [weak self] url in
            self?.handler.scheduleMutationTask { [weak self] in
                try await self?.handler.fetch(url: url, blockId: info.id)
            }
        }
    }

    // MARK: - Indentation

    private func indentLeft(blockInformation: BlockInformation) {
        guard let parentId = blockInformation.configurationData.parentId,
              parentId != document.objectId,
              let parent = infoContainer.get(id: parentId) else {
            return
        }

        // Check grandparent can accept children (root document always can)
        if let grandparentId = parent.configurationData.parentId,
           grandparentId != document.objectId,
           let grandparent = infoContainer.get(id: grandparentId),
           !grandparent.content.type.canContainChildBlocks {
            return
        }

        handler.scheduleMutationTask { [self] in
            try await blockService.move(
                objectId: document.objectId,
                blockId: blockInformation.id,
                targetId: parentId,
                position: .bottom
            )
        }
    }

    private func indentRight(blockInformation: BlockInformation) {
        guard let parentId = blockInformation.configurationData.parentId,
              let parent = infoContainer.get(id: parentId) else {
            return
        }

        let siblings = parent.childrenIds
        guard let currentIndex = siblings.firstIndex(of: blockInformation.id),
              currentIndex > 0 else {
            return
        }

        let previousSiblingId = siblings[currentIndex - 1]

        guard let previousSibling = infoContainer.get(id: previousSiblingId),
              previousSibling.content.type.canContainChildBlocks else {
            return
        }

        handler.scheduleMutationTask { [self] in
            try await blockService.move(
                objectId: document.objectId,
                blockId: blockInformation.id,
                targetId: previousSiblingId,
                position: .inner
            )
        }
    }
}
