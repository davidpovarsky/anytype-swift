import SwiftUI
import Services

struct PropertyOptionSettingsConfiguration {
    let option: PropertyOptionParameters
    let mode: PropertyOptionSettingsMode
    let originalPropertyConfiguration: PropertyModuleConfiguration?

    init(option: PropertyOptionParameters, mode: PropertyOptionSettingsMode,
         originalPropertyConfiguration: PropertyModuleConfiguration? = nil) {
        self.option = option
        self.mode = mode
        self.originalPropertyConfiguration = originalPropertyConfiguration
    }
}

enum PropertyOptionSettingsMode {
    case create(CreateData)
    case edit
    
    var title: String {
        switch self {
        case .create: return Loc.Relation.View.Create.title
        case .edit: return Loc.Relation.View.Edit.title
        }
    }
    
    var buttonTitle: String {
        switch self {
        case .create: return Loc.create
        case .edit: return Loc.apply
        }
    }
    
    struct CreateData {
        let relationKey: String
        let spaceId: String
    }
}

struct PropertyOptionParameters {
    let id: String
    let text: String
    let color: Color
    
    init(id: String = UUID().uuidString, text: String?, color: Color?) {
        self.id = id
        self.text = text ?? ""
        self.color = color ?? MiddlewareColor.allCasesWithoutDefault.randomElement().map { Color.Dark.color(from: $0) } ?? Color.Dark.grey
    }
}
