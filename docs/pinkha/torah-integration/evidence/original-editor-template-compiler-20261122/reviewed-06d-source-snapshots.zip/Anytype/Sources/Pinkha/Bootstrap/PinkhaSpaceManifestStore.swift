import Foundation
import PinkhaKit
import Services
import AnytypeCore
import Logger
import Factory
import SwiftProtobuf
import ProtobufMessages

/// Canonical synced Anytype-backed manifest store.
/// Stores the PinkhaSpaceManifest as an internal hidden object within the Anytype Space.
/// Synchronizes across devices using Anytype's native CRDT sync engine without secondary local databases.
public final class PinkhaSpaceManifestStore: PinkhaSpaceManifestStoreProtocol, @unchecked Sendable {

    private static let log = EventLogger(category: "Pinkha")

    @Injected(\.searchMiddleService)
    private var searchMiddleService: any SearchMiddleServiceProtocol

    @Injected(\.objectActionsService)
    private var objectActionsService: any ObjectActionsServiceProtocol

    public init() {}

    /// The prepared editor supplies its captured account/source read lease.
    /// This enters the same canonical read body, never bootstrap or save.
    func loadOriginalEditorManifest(spaceId: String) async throws -> PinkhaSpaceManifest? {
        _ = try OriginalSearchMiddleServiceBinding.requireOriginal(searchMiddleService)
        return try await loadManifest(spaceId: spaceId)
    }

    public func discoverManifestObjectId(spaceId: String) async throws -> String? {
        // Heart derives uniqueKey from the tree header. Older Pinkha creation
        // supplied it as a detail, so also discover by the original stable name.
        // A name alone never establishes identity: validate the actual manifest.
        var candidates: [String: ObjectDetails] = [:]
        for key in [BundledPropertyKey.uniqueKey, .name] {
            let results = try await searchMiddleService.search(
                spaceId: spaceId,
                filters: [.with {
                    $0.relationKey = key.rawValue
                    $0.condition = .equal
                    $0.value = PinkhaSchemaRoles.manifestName.protobufValue
                }],
                keys: [BundledPropertyKey.id, .spaceId, .description].map(\.rawValue),
                limit: 0
            )
            for result in results { candidates[result.id] = result }
        }
        let valid = candidates.values.filter { details in
            guard details.spaceId == spaceId,
                  let raw = details.values[BundledPropertyKey.description.rawValue]?.stringValue,
                  let manifest = try? PinkhaSpaceManifest.fromJSONString(raw),
                  manifest.spaceId == spaceId else { return false }
            return manifest.manifestObjectId == nil || manifest.manifestObjectId == details.id
        }
        // Neither discovery nor an engine rebuild may delete synced manifests.
        // Ambiguity is a recoverable explicit error, not permission to pick one.
        guard valid.count <= 1 else { throw ManifestDiscoveryError.ambiguous }
        return valid.first?.id
    }

    private enum ManifestDiscoveryError: Error { case ambiguous }

    public func loadManifest(spaceId: String) async throws -> PinkhaSpaceManifest? {
        guard let objectId = try await discoverManifestObjectId(spaceId: spaceId) else {
            return nil
        }

        let objectShow = try await ClientCommands.objectShow(.with {
            $0.contextID = objectId
            $0.objectID = objectId
            $0.spaceID = spaceId
        }).invoke(qos: .userInitiated, ignoreLogErrors: .objectDeleted)

        guard let details = objectShow.objectView.details.first(where: { $0.id == objectId })?.details,
              let objectDetails = try? ObjectDetails(protobufStruct: details) else {
            return nil
        }

        guard let jsonString = objectDetails.values[BundledPropertyKey.description.rawValue]?.stringValue,
              !jsonString.isEmpty else {
            return nil
        }

        var manifest = try PinkhaSpaceManifest.fromJSONString(jsonString)
        manifest.manifestObjectId = objectId
        return manifest
    }

    public func saveManifest(_ manifest: PinkhaSpaceManifest) async throws -> PinkhaSpaceManifest {
        var updated = manifest
        let jsonString = try manifest.toJSONString()

        let targetObjectId: String?
        if let currentId = manifest.manifestObjectId {
            targetObjectId = currentId
        } else {
            targetObjectId = try await discoverManifestObjectId(spaceId: manifest.spaceId)
        }

        if let existingObjectId = targetObjectId {
            updated.manifestObjectId = existingObjectId
            let payloadJson = try updated.toJSONString()

            _ = try await ClientCommands.objectSetDetails(.with {
                $0.contextID = existingObjectId
                $0.details = [
                    Anytype_Model_Detail.with {
                        $0.key = BundledPropertyKey.description.rawValue
                        $0.value = payloadJson.protobufValue
                    },
                    Anytype_Model_Detail.with {
                        $0.key = BundledPropertyKey.lastUsedDate.rawValue
                        $0.value = Date().protobufValue
                    }
                ]
            }).invoke(qos: .userInitiated)

            return updated
        } else {
            // Create new internal Anytype object in Space
            let fields: [String: Google_Protobuf_Value] = [
                BundledPropertyKey.name.rawValue: PinkhaSchemaRoles.manifestName.protobufValue,
                BundledPropertyKey.uniqueKey.rawValue: PinkhaSchemaRoles.manifestUniqueKey.protobufValue,
                BundledPropertyKey.description.rawValue: jsonString.protobufValue,
                BundledPropertyKey.isHidden.rawValue: true.protobufValue,
                BundledPropertyKey.origin.rawValue: ObjectOrigin.none.rawValue.protobufValue
            ]

            let response = try await ClientCommands.objectCreate(.with {
                $0.details = Google_Protobuf_Struct(fields: fields)
                $0.spaceID = manifest.spaceId
                $0.objectTypeUniqueKey = ObjectTypeUniqueKey.page.value
            }).invoke(qos: .userInitiated)

            let objectDetails = try response.details.toDetails()
            let objectId = objectDetails.id
            updated.manifestObjectId = objectId

            // Update with the final JSON containing its own manifestObjectId
            let finalJson = try updated.toJSONString()
            _ = try await ClientCommands.objectSetDetails(.with {
                $0.contextID = objectId
                $0.details = [
                    Anytype_Model_Detail.with {
                        $0.key = BundledPropertyKey.description.rawValue
                        $0.value = finalJson.protobufValue
                    }
                ]
            }).invoke(qos: .userInitiated)

            return updated
        }
    }
}
