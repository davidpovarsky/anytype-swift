import Foundation
import Services
import AnytypeCore

protocol DocumentViewModelSetterProtocol: AnyObject {
    func objectViewUpdate(_ data: ObjectViewModel)
}

final class DocumentViewModelSetter: DocumentViewModelSetterProtocol {
    
    private let mentionTextUpdateHandler: any MentionTextUpdateHandlerProtocol
    
    private let detailsStorage: ObjectDetailsStorage
    private let restrictionsContainer: ObjectRestrictionsContainer
    private let infoContainer: any InfoContainerProtocol
    
    init(
        detailsStorage: ObjectDetailsStorage,
        restrictionsContainer: ObjectRestrictionsContainer,
        infoContainer: some InfoContainerProtocol,
        dependencies: DocumentViewModelSetterDependencies? = nil
    ) {
        self.mentionTextUpdateHandler = (dependencies ?? .original()).mentionTextUpdateHandler
        self.detailsStorage = detailsStorage
        self.restrictionsContainer = restrictionsContainer
        self.infoContainer = infoContainer
    }
    
    // MARK: - ObjectViewModelSetterProtocol
    
    func objectViewUpdate(_ data: ObjectViewModel) {
        guard data.rootID.isNotEmpty else {
            anytypeAssertionFailure("Empty root id")
            return
        }
        
        let parsedBlocks = data.blocks.compactMap {
            BlockInformationConverter.convert(block: $0)
        }
        
        let parsedDetails: [ObjectDetails] = data.details.compactMap {
            ObjectDetails(id: $0.id, values: $0.details.fields)
        }
        
        let rootDetails = parsedDetails.first { $0.id == data.rootID }
        
        buildBlocksTree(information: parsedBlocks, rootId: data.rootID, container: infoContainer, layout: rootDetails?.resolvedLayoutValue)
        
        parsedDetails.forEach { detailsStorage.add(details: $0) }
        
        
        let restrinctions = MiddlewareObjectRestrictionsConverter.convertObjectRestrictions(middlewareRestrictions: data.restrictions)
        
        restrictionsContainer.restrictions = restrinctions
        
        mentionTextUpdateHandler.updateMentionsTextsIfNeeded(
            objectId: data.rootID,
            infoContainer: infoContainer,
            detailsStorage: detailsStorage
        )
    }
    
    // MARK: - Private
    
    private func buildBlocksTree(information: [BlockInformation], rootId: String, container: any InfoContainerProtocol, layout: DetailsLayout?) {
        information.forEach { container.add($0) }
        _ = IndentationBuilder.build(container: container, id: rootId)
    }
}

/// Preserve the original mention updater while allowing an owned document
/// context to supply its actual updater without resolving a global factory.
struct DocumentViewModelSetterDependencies {
    let mentionTextUpdateHandler: any MentionTextUpdateHandlerProtocol

    static func original() -> Self {
        Self(mentionTextUpdateHandler: Container.shared.mentionTextUpdateHandler())
    }
}
