from pathlib import Path
import json
import shutil

ROOT = Path(__file__).resolve().parent
tree = json.loads((ROOT / 'TREE.json').read_text())['tree']
by = {entry['path']: entry for entry in tree}
receipt = json.loads((ROOT / 'TARGET_SOURCE_PRESERVATION.json').read_text())
out = ROOT / 'candidate/Tools/OriginalEditor'
shutil.copyfile(ROOT / 'base/Anytype.xcodeproj/project.pbxproj', out / 'original_project.pbxproj')
resolved = [item for item in tree if item['path'].endswith('Package.resolved')
            and item['path'].startswith('Anytype.xcodeproj/')]
assert len(resolved) == 1
helper_paths = ['LICENSE.md', 'Tools/Hanlin/prepare_sdk.py', 'Tools/Hanlin/source.json',
                'Tools/Hanlin/prepare_original_editor_heart.py', 'Tools/Hanlin/original_editor_profile.py',
                'Tools/Hanlin/original_editor_profile.json', 'Tools/PinkhaSimulatorGate/preflight.py',
                'Tools/PinkhaNativeDerived/build_custom_heart.py', 'Tools/PinkhaNativeDerived/package_evidence.py']
oracle = {
    'localization_path': 'Modules/Loc/Sources/Loc/Resources/UI.xcstrings',
    'font_path': 'Modules/DesignKit/Sources/DesignKit/Resources/Fonts/IBMPlexMono-Regular.ttf',
    'color_path': 'Modules/Assets/Sources/Assets/Resources/SystemColors.xcassets/DesignSystem/Text/primary.colorset/Contents.json',
}
for name in ['localization', 'font', 'color']:
    oracle[name + '_blob'] = by[oracle[name + '_path']]['sha']
oracle['localization_key'] = 'Cancel'
manifest = {
    'schema': 1, 'branch': 'codex/otzaria-original-editor-framework-reviewed-20261120',
    'base_application_source': 'b4ece8c2129124f6ec8ed00143e156b9d0e11383',
    'framework_target_id': receipt['framework_target_id'],
    'candidate_project_sha256': receipt['candidate_project_sha256'],
    'baseline_project_blob': receipt['original_project_blob'],
    'new_project_objects': receipt['new_objects'],
    'allowed_original_structural_objects': receipt['allowed_original_structural_objects'],
    'package_pin_count': 44, 'package_resolved_path': resolved[0]['path'],
    'package_resolved_blob': resolved[0]['sha'],
    'original_trees': {path: by[path]['sha'] for path in ['Anytype/Sources', 'Anytype/Resources', 'Modules']},
    'original_swift_sources': sum(entry['type'] == 'blob' and entry['path'].startswith('Anytype/Sources/')
                                  and entry['path'].endswith('.swift') for entry in tree),
    'bound_original_helpers': {path: by[path]['sha'] for path in helper_paths},
    'original_heart_installer_blob': by['Tools/PinkhaNativeDerived/install_verified_heart.py']['sha'],
    'resource_oracles': oracle,
    'scope': 'Same-toolchain iOS Simulator genuine framework import/link/resource prerequisite; no editable consumer or app runtime qualification',
}
(out / 'framework_profile.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
installer = (ROOT / 'base/Tools/PinkhaNativeDerived/install_verified_heart.py').read_text()
old = "                             'codex/otzaria-original-editor-owned43-apple-reviewed-20261120'],"
new = "                             'codex/otzaria-original-editor-owned43-apple-reviewed-20261120',\n                             'codex/otzaria-original-editor-framework-reviewed-20261120'],"
assert installer.count(old) == 1
target = ROOT / 'candidate/Tools/PinkhaNativeDerived/install_verified_heart.py'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(installer.replace(old, new, 1))
print(json.dumps({'sources': manifest['original_swift_sources'], 'pins': 44,
                  'original_trees': manifest['original_trees']}, indent=2))
