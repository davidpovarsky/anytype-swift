"""Author one additive real framework target while preserving the original app."""
from pathlib import Path
import copy
import hashlib
import json
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'candidate/Tools/OriginalEditor'))
from pbx_source import loads, render, object_text, append_array, require

BASE = ROOT / 'base/Anytype.xcodeproj/project.pbxproj'
CANDIDATE = ROOT / 'candidate/Anytype.xcodeproj/project.pbxproj'
APP = '0303ECFA22D8EDAA005C552B'
SOURCES = '3D69B4E82CAEA9CB003F5A91'
PRODUCTS = '0303ECFC22D8EDAA005C552B'
MAIN = '0303ECF222D8EDAA005C552B'


def identifier(name):
    return hashlib.sha256(('OtzariaOriginalEditor20261120:' + name).encode()).hexdigest()[:24].upper()


def main():
    original = BASE.read_text()
    project = loads(original)
    objects = project['objects']
    app = objects[APP]
    changed = original
    additions = {}

    def add(name, obj):
        key = identifier(name)
        require(key not in objects and key not in additions, 'New object ID collision')
        additions[key] = (name, obj)
        return key

    target_id = identifier('AnytypeOriginalEditor')
    product_id = add('AnytypeOriginalEditor.framework', {
        'isa': 'PBXFileReference', 'explicitFileType': 'wrapper.framework',
        'includeInIndex': '0', 'path': 'AnytypeOriginalEditor.framework', 'sourceTree': 'BUILT_PRODUCTS_DIR'})
    facade = add('AnytypeOriginalEditorModule.swift', {
        'isa': 'PBXFileReference', 'lastKnownFileType': 'sourcecode.swift',
        'path': 'AnytypeOriginalEditorModule.swift', 'sourceTree': '<group>'})
    group = add('OriginalEditorFramework', {'isa': 'PBXGroup', 'children': [facade],
        'path': 'OriginalEditorFramework', 'sourceTree': '<group>'})
    exception = add('OriginalEditorEntrypointException', {
        'isa': 'PBXFileSystemSynchronizedBuildFileExceptionSet',
        'membershipExceptions': ['ApplicationLayer/AppScene.swift'], 'target': target_id})
    dependency_map = {}
    for key in app['packageProductDependencies']:
        obj = copy.deepcopy(objects[key])
        dependency_map[key] = add('EditorPackage_' + obj['productName'], obj)
    original_framework = objects['0303ECF822D8EDAA005C552B']
    framework_files = []
    for key in original_framework['files']:
        obj = copy.deepcopy(objects[key])
        if 'productRef' in obj:
            obj['productRef'] = dependency_map[obj['productRef']]
        framework_files.append(add('EditorLink_' + key, obj))
    framework_phase = add('EditorFrameworks', {'isa': 'PBXFrameworksBuildPhase',
        'buildActionMask': '2147483647', 'files': framework_files, 'runOnlyForDeploymentPostprocessing': '0'})
    source_files = [add('EditorAssetConstants', copy.deepcopy(objects['74D9D0F42E5F31F500CA09E7'])),
                    add('EditorFacade', {'isa': 'PBXBuildFile', 'fileRef': facade})]
    source_phase = add('EditorSources', {'isa': 'PBXSourcesBuildPhase',
        'buildActionMask': '2147483647', 'files': source_files, 'runOnlyForDeploymentPostprocessing': '0'})
    resource_files = [add('EditorResource_' + key, copy.deepcopy(objects[key])) for key in
                      ['03A46A40231417D6009AC10C', '0303ED0522D8EDAD005C552B']]
    resource_phase = add('EditorResources', {'isa': 'PBXResourcesBuildPhase',
        'buildActionMask': '2147483647', 'files': resource_files, 'runOnlyForDeploymentPostprocessing': '0'})
    configs = []
    remove = {'ASSETCATALOG_COMPILER_APPICON_NAME', 'ASSETCATALOG_COMPILER_INCLUDE_ALL_APPICON_ASSETS',
              'BUILD_APP_URL_SCHEME', 'BUNDLE_NAME', 'CODE_SIGN_ENTITLEMENTS', 'GOOGLE_SERVICE_INFO_PLIST',
              'INFOPLIST_FILE', 'PROVISIONING_PROFILE_SPECIFIER', 'SENTRY_ENV', 'DEVELOPMENT_ASSET_PATHS'}
    for key in objects[app['buildConfigurationList']]['buildConfigurations']:
        config = copy.deepcopy(objects[key])
        settings = {key: value for key, value in config['buildSettings'].items() if key not in remove}
        settings.update({
            'PRODUCT_NAME': '$(TARGET_NAME)', 'PRODUCT_MODULE_NAME': 'AnytypeOriginalEditor',
            'PRODUCT_BUNDLE_IDENTIFIER': 'org.otzaria.anytype.original-editor',
            'MACH_O_TYPE': 'mh_dylib', 'DEFINES_MODULE': 'YES', 'GENERATE_INFOPLIST_FILE': 'YES',
            'BUILD_LIBRARY_FOR_DISTRIBUTION': 'NO', 'DEAD_CODE_STRIPPING': 'NO',
            'SKIP_INSTALL': 'NO', 'INSTALL_PATH': '$(LOCAL_LIBRARY_DIR)/Frameworks',
            'DYLIB_COMPATIBILITY_VERSION': '1', 'DYLIB_CURRENT_VERSION': '1',
            'CODE_SIGN_STYLE': 'Automatic', 'CODE_SIGN_IDENTITY': '-', 'DEVELOPMENT_TEAM': '',
            'PROVISIONING_PROFILE_SPECIFIER': '', 'ENABLE_PREVIEWS': 'NO',
            'LD_RUNPATH_SEARCH_PATHS': ['$(inherited)', '@loader_path/Frameworks', '@executable_path/Frameworks'],
            'SWIFT_INSTALL_OBJC_HEADER': 'YES', 'SWIFT_OBJC_INTERFACE_HEADER_NAME': 'AnytypeOriginalEditor-Swift.h',
        })
        config['buildSettings'] = settings
        configs.append(add('EditorConfig_' + config['name'], config))
    configuration_list = add('EditorConfigurations', {'isa': 'XCConfigurationList',
        'buildConfigurations': configs, 'defaultConfigurationIsVisible': '0', 'defaultConfigurationName': 'Debug-Anytype'})
    add('AnytypeOriginalEditor', {'isa': 'PBXNativeTarget', 'buildConfigurationList': configuration_list,
        'buildPhases': [source_phase, framework_phase, resource_phase], 'buildRules': [], 'dependencies': [],
        'fileSystemSynchronizedGroups': ['3D6977812CAE9ED0003F5A91', '3D6977912CAE9EEC003F5A91', SOURCES],
        'name': 'AnytypeOriginalEditor', 'packageProductDependencies': list(dependency_map.values()),
        'productName': 'AnytypeOriginalEditor', 'productReference': product_id,
        'productType': 'com.apple.product-type.framework'})
    source_text = object_text(changed, SOURCES)
    require('exceptions' not in source_text, 'Original sources gained an unreviewed exception')
    changed = changed.replace(source_text, source_text.replace('explicitFileTypes',
        'exceptions = (' + exception + ' /* OriginalEditorEntrypointException */, ); explicitFileTypes'), 1)
    changed = append_array(changed, MAIN, 'children', group, 'OriginalEditorFramework')
    changed = append_array(changed, PRODUCTS, 'children', product_id, 'AnytypeOriginalEditor.framework')
    changed = append_array(changed, project['rootObject'], 'targets', target_id, 'AnytypeOriginalEditor')
    for section in sorted({obj['isa'] for _, obj in additions.values()}):
        marker = '/* End ' + section + ' section */'
        require(changed.count(marker) == 1, 'Original project section changed: ' + section)
        blocks = ''.join('\t\t' + key + ' /* ' + name + ' */ = ' + render(obj, 2) + ';\n'
                         for key, (name, obj) in additions.items() if obj['isa'] == section)
        changed = changed.replace(marker, blocks + marker, 1)
    parsed = loads(changed)
    allowed = {SOURCES, MAIN, PRODUCTS, project['rootObject']}
    require(all(parsed['objects'][key] == value for key, value in objects.items() if key not in allowed),
            'An original app, package, target, phase or setting was changed')
    inverse = changed
    for key in additions:
        inverse = inverse.replace(object_text(inverse, key), '', 1)
    for key in allowed:
        inverse = inverse.replace(object_text(inverse, key), object_text(original, key), 1)
    require(inverse == original, 'Whole original project inverse differs')
    CANDIDATE.parent.mkdir(parents=True, exist_ok=True)
    CANDIDATE.write_text(changed)
    scheme = ET.Element('Scheme', LastUpgradeVersion='2700', version='1.3')
    build = ET.SubElement(scheme, 'BuildAction', parallelizeBuildables='YES', buildImplicitDependencies='YES')
    entries = ET.SubElement(build, 'BuildActionEntries')
    entry = ET.SubElement(entries, 'BuildActionEntry', buildForTesting='NO', buildForRunning='YES',
                          buildForProfiling='YES', buildForArchiving='YES', buildForAnalyzing='YES')
    ET.SubElement(entry, 'BuildableReference', BuildableIdentifier='primary', BlueprintIdentifier=target_id,
                  BuildableName='AnytypeOriginalEditor.framework', BlueprintName='AnytypeOriginalEditor',
                  ReferencedContainer='container:Anytype.xcodeproj')
    ET.SubElement(scheme, 'AnalyzeAction', buildConfiguration='Debug-Anytype')
    ET.SubElement(scheme, 'ArchiveAction', buildConfiguration='Release-Anytype', revealArchiveInOrganizer='YES')
    ET.indent(scheme, space='   ')
    scheme_path = CANDIDATE.parent / 'xcshareddata/xcschemes/AnytypeOriginalEditor.xcscheme'
    scheme_path.parent.mkdir(parents=True, exist_ok=True)
    scheme_path.write_bytes(b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(scheme) + b'\n')
    receipt = {'original_project_blob': hashlib.sha1(b'blob ' + str(len(original.encode())).encode() + b'\0' + original.encode()).hexdigest(),
               'candidate_project_sha256': hashlib.sha256(changed.encode()).hexdigest(),
               'original_objects': len(objects), 'new_objects': len(additions), 'allowed_original_structural_objects': sorted(allowed),
               'original_app_object_unchanged': True, 'whole_project_inverse_exact': True,
               'framework_target_id': target_id, 'original_package_products': len(dependency_map),
               'only_source_exception': 'Anytype/Sources/ApplicationLayer/AppScene.swift',
               'app_compile_run': 'NOT_RUN', 'framework_build_import_link_resources': 'NOT_RUN'}
    (ROOT / 'TARGET_SOURCE_PRESERVATION.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
