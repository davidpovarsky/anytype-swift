import gzip
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = next(path for path in HERE.parents if (path / 'Tools/OriginalEditor/framework_profile.json').is_file())
index = json.loads((HERE / 'PACKET_INDEX.json').read_text())
for row in index['payloads']:
    path = ROOT / row['path']
    assert path.is_file() and not path.is_symlink(), row['path']
    raw = path.read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == row['git_blob'], row['path']

def raw(name):
    return gzip.decompress((HERE / 'raw' / (name + '.gz')).read_bytes())

result = json.loads(raw('validation/final43/RESULT.json'))
assert result['returncode'] == 0 and result['qualified_local_controls'] and result['inputs_unchanged']
assert len(result['expected_cases']) == len(set(result['expected_cases'])) == 43
assert sorted(result['expected_cases']) == sorted(result['observed_passed_cases'])
before = json.loads(raw('validation/final43/INPUTS_BEFORE.json'))
assert before == json.loads(raw('validation/final43/INPUTS_AFTER.json'))
for path, observed in before.items():
    value = (ROOT / path).read_bytes()
    assert len(value) == observed['bytes'] and hashlib.sha256(value).hexdigest() == observed['sha256'], path
assert result['Apple_framework_build'] == result['external_consumer_runtime'] == result['Native_editor_UI'] == 'NOT_RUN'
sys.path.insert(0, str(ROOT / 'Tools/OriginalEditor'))
from framework_profile import read_manifest, verify_project
profile = read_manifest()
proof = verify_project((ROOT / 'Anytype.xcodeproj/project.pbxproj').read_bytes(),
                       (ROOT / 'Tools/OriginalEditor/original_project.pbxproj').read_bytes(), profile)
installer = (ROOT / 'Tools/PinkhaNativeDerived/install_verified_heart.py').read_bytes()
suffix = b",\n                             'codex/otzaria-original-editor-framework-reviewed-20261120'"
assert installer.count(suffix) == 1
original = installer.replace(suffix, b'', 1)
assert hashlib.sha1(b'blob ' + str(len(original)).encode() + b'\0' + original).hexdigest() == profile['original_heart_installer_blob']
print(json.dumps({'payloads_verified': len(index['payloads']), 'local_controls': 43,
                  'original_app_project_inverse': proof['whole_project_inverse_exact'],
                  'original_products': 44, 'original_package_pins': 44,
                  'Apple_framework_import_resources': 'NOT_RUN', 'native_editor_ui': 'NOT_RUN',
                  'workflow_activated': False}, sort_keys=True))
