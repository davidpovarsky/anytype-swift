#!/usr/bin/env python3
"""Verify exact source preservation and retained observations; run no test tools."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
V4 = 'codex/otzaria-original-editor-framework-v4-reviewed-20261120'
V5 = 'codex/otzaria-original-editor-framework-v5-reviewed-20261120'


def record(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def files(root):
    return {p.relative_to(root).as_posix(): p.read_bytes()
            for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}


def methods(source):
    return sorted(node.name for node in ast.walk(ast.parse(source))
                  if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'))


def verify():
    old, new = files(ROOT / 'baseline'), files(ROOT / 'candidate')
    authority = json.loads((ROOT / 'SOURCE_AUTHORITY.json').read_bytes())
    assert authority['source'] == '962d050eb36b2511616c771b08d92a78b64d2349'
    assert authority['tree'] == 'a11f06d5f4fdf0ad94e4e8e1d2914c0b480d3cb6'
    for row in authority['original_inputs']:
        actual = record(old[row['path']])
        assert actual['git_blob'] == row['canonical_git_blob'] and actual['bytes'] == row['bytes']
        assert actual['sha256'] == row['sha256']
    changed = sorted(p for p in set(old) | set(new) if old.get(p) != new.get(p))
    assert changed == sorted([
        '.github/workflows/pinkha-original-editor-framework.yml',
        'Tools/OriginalEditor/framework_profile.json', 'Tools/OriginalEditor/framework_profile.py',
        'Tools/OriginalEditor/test_framework.py', 'Tools/OriginalEditor/test_framework_duplicates.py',
        'Tools/OriginalEditor/test_framework_source_retention.py',
        'Tools/OriginalEditor/test_framework_temporary_paths.py',
        'Tools/PinkhaNativeDerived/install_verified_heart.py'])
    for p in ['.github/workflows/pinkha-original-editor-framework.yml', 'Tools/OriginalEditor/test_framework.py']:
        assert new[p].replace(V5.encode(), V4.encode()) == old[p]
    p = 'Tools/OriginalEditor/framework_profile.py'
    reversed_profile = new[p].decode().replace(V4, 'codex/otzaria-original-editor-framework-v3-reviewed-20261120')
    assert reversed_profile.replace(V5, V4).encode() == old[p]
    p = 'Tools/PinkhaNativeDerived/install_verified_heart.py'
    extra = (",\n                             '" + V5 + "'").encode()
    assert new[p].count(extra) == 1 and new[p].replace(extra, b'', 1) == old[p]
    p = 'Tools/OriginalEditor/framework_profile.json'
    a, b = json.loads(old[p]), json.loads(new[p])
    assert set(a) == set(b) and {k for k in a if a[k] != b[k]} == {'branch', 'original_heart_installer_blob'}
    assert b['branch'] == V5 and b['original_heart_installer_blob'] == record(old['Tools/PinkhaNativeDerived/install_verified_heart.py'])['git_blob']
    p = 'Tools/OriginalEditor/test_framework_source_retention.py'
    expected = old[p].replace(b"self.root = Path(self.temporary.name) / 'source'",
                              b"self.root = Path(self.temporary.name).resolve() / 'source'")
    assert new[p] == expected
    p = 'Tools/OriginalEditor/test_framework_duplicates.py'
    inverse = new[p]
    edits = [
        (b"self.first = (self.products / 'Lib.framework').resolve()", b"self.first = self.products / 'Lib.framework'"),
        (b"self.second = (self.products / 'PackageFrameworks/Lib.framework').resolve()", b"self.second = self.products / 'PackageFrameworks/Lib.framework'"),
        (b'        mutations = []\n', b''),
        (b"                mutations.append(self.second / 'Lib')\n", b''),
        (b"        self.assertEqual(mutations, [self.second / 'Lib'])\n", b''),
        (b"        self.assertEqual((self.second / 'Lib').read_bytes(), b'changed after admitted comparison')\n", b''),
        (b"                mutations.append(Path(target) / 'Lib')\n", b''),
        (b"        self.assertEqual(mutations, [(self.exported / 'Frameworks/Lib.framework/Lib').resolve()])\n", b''),
        (b"        self.assertEqual(mutations[0].read_bytes(), b'changed exported file')\n", b''),
    ]
    for after, before in edits:
        assert inverse.count(after) == (2 if after == b'        mutations = []\n' else 1)
        inverse = inverse.replace(after, before)
    assert inverse == old[p]
    original_ids = sorted(name for p, data in old.items() if p.startswith('Tools/OriginalEditor/test_')
                          for name in methods(data))
    current_ids = sorted(name for p, data in new.items() if p.startswith('Tools/OriginalEditor/test_')
                         for name in methods(data))
    assert len(original_ids) == len(set(original_ids)) == 96
    assert len(current_ids) == len(set(current_ids)) == 99 and set(original_ids) < set(current_ids)
    for p in ['Tools/OriginalEditor/framework_products.py', 'Tools/OriginalEditor/run_framework_acceptance.py',
              'Tools/OriginalEditor/test_framework_flow.py', 'Tools/OriginalEditor/Consumer/ConsumerApp.swift',
              'OriginalEditorFramework/AnytypeOriginalEditorModule.swift', 'Anytype.xcodeproj/project.pbxproj']:
        assert old[p] == new[p]
    runs = {}
    for name, count, passing, failures, errors, final in [
        ('frozen-v4-symlink-red', 96, 93, 2, 1, False),
        ('candidate-path-green', 99, 99, 0, 0, False),
        ('candidate-final-alias-green', 99, 99, 0, 0, True),
        ('candidate-final-native-path-green', 99, 99, 0, 0, True),
    ]:
        directory = ROOT / 'runs' / name
        result = json.loads((directory / 'RESULT.json').read_bytes())
        assert (result['executed'], result['passed'], result['failed'], result['errors']) == (count, passing, failures, errors)
        assert result['exit_code'] == (1 if failures or errors else 0)
        cases = json.loads((directory / 'CASES.json').read_bytes())
        assert len(cases) == len({r['method'] for r in cases}) == count
        assert set(original_ids) <= {r['method'] for r in cases}
        before = json.loads((directory / 'INPUTS_BEFORE.json').read_bytes())
        assert before == json.loads((directory / 'INPUTS_AFTER.json').read_bytes())
        assert result['stderr_sha256'] == record((directory / 'stderr.log').read_bytes())['sha256']
        assert result['stdout_sha256'] == record((directory / 'stdout.log').read_bytes())['sha256']
        if final:
            assert set(before) == set(new)
            for p, v in before.items():
                assert {k: record(new[p])[k] for k in v} == v
        if name == 'frozen-v4-symlink-red':
            assert {r['method'] for r in cases if r['status'] == 'FAIL'} == {
                'test_known_input_changed_during_copy_cannot_publish_success',
                'test_changed_materialized_output_cannot_publish_success'}
            assert {r['method'] for r in cases if r['status'] == 'ERROR'} == {
                'test_original_packager_retains_all_four_exact_raw_proofs_as_text'}
        runs[name] = result
    patch = ''.join(''.join(difflib.unified_diff(old.get(p, b'').decode().splitlines(keepends=True),
                    new.get(p, b'').decode().splitlines(keepends=True), fromfile='a/' + p, tofile='b/' + p))
                    for p in changed).encode()
    assert patch == (ROOT / 'CANDIDATE.patch').read_bytes()
    return {'status': 'PASS_SOURCE_PRESERVATION_ONLY', 'source': authority['source'],
            'changed_paths': [{ 'path': p, 'before': record(old[p]) if p in old else None,
                                'after': record(new[p]) if p in new else None } for p in changed],
            'original96_declarations_preserved': True, 'original54_body_preserved_except_branch_literal': True,
            'runtime_exporter_source_validator_driver_product_ABI_budgets_unchanged': True,
            'original_alias_reproduction': '93_PASS_2_FAIL_1_ERROR',
            'final_normal_path': '99_PASS', 'final_real_alias_path': '99_PASS',
            'actual_apple_v5': 'NOT_RUN', 'runs': runs}


if __name__ == '__main__':
    result = verify()
    (ROOT / 'PRESERVATION.json').write_bytes((json.dumps(result, indent=2, sort_keys=True) + '\n').encode())
    print(json.dumps({k: v for k, v in result.items() if k not in ['changed_paths', 'runs']}, indent=2))
