#!/usr/bin/env python3
"""Run actual Python controls with an owned real directory alias, no Apple claim."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def inputs(directory):
    return {p.relative_to(directory).as_posix(): {
        'bytes': len(data := p.read_bytes()), 'sha256': hashlib.sha256(data).hexdigest()}
        for p in sorted(directory.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('stage')
    parser.add_argument('--source', choices=['baseline', 'candidate'], required=True)
    parser.add_argument('--alias', action='store_true')
    args = parser.parse_args()
    output = ROOT / 'runs' / args.stage
    output.mkdir(parents=True, exist_ok=False)
    source = ROOT / args.source
    before = inputs(source)
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
           'FRAMEWORK_FLOW_EVIDENCE': str(output / 'flow')}
    if args.alias:
        real = output / 'actual-temporary-root'
        real.mkdir()
        alias = output / 'temporary-root-alias'
        alias.symlink_to(real, target_is_directory=True)
        env['TMPDIR'] = str(alias)
        assert alias != alias.resolve() and alias.samefile(real)
    command = [sys.executable, '-m', 'unittest', 'discover', '-s',
               str(source / 'Tools/OriginalEditor'), '-p', 'test_*.py', '-v']
    report = {'command': command, 'cwd': str(source), 'timeout_seconds': 300,
              'started_at': datetime.now(timezone.utc).isoformat(),
              'platform': 'Actual Linux Python; no Swift, Apple compiler, or native UI',
              'real_directory_alias': args.alias,
              'TMPDIR': env.get('TMPDIR')}
    (output / 'INPUTS_BEFORE.json').write_text(json.dumps(before, sort_keys=True, indent=2) + '\n')
    result = subprocess.run(command, cwd=source, env=env, capture_output=True, timeout=300)
    (output / 'stdout.log').write_bytes(result.stdout)
    (output / 'stderr.log').write_bytes(result.stderr)
    after = inputs(source)
    (output / 'INPUTS_AFTER.json').write_text(json.dumps(after, sort_keys=True, indent=2) + '\n')
    assert before == after, 'Actual source mutated during control execution'
    rows = re.findall(r'(?m)^(test_\S+) \(([^\n]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$',
                      result.stderr.decode())
    cases = [{'method': name, 'id': identity, 'status': status} for name, identity, status in rows]
    (output / 'CASES.json').write_text(json.dumps(cases, indent=2) + '\n')
    report.update(finished_at=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode,
                  executed=len(cases), passed=sum(c['status'] == 'ok' for c in cases),
                  failed=sum(c['status'] == 'FAIL' for c in cases),
                  errors=sum(c['status'] == 'ERROR' for c in cases),
                  source_inputs_unchanged=True,
                  stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
                  stdout_sha256=hashlib.sha256(result.stdout).hexdigest())
    (output / 'RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
