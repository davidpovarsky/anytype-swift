public struct PublicAPI { public init() {} public func publicMember() {} }
@_spi(Qualification) public struct QualificationAPI { public init() {} public func qualificationMember() {} }
public enum ModuleAPI { @_spi(Qualification) public static func begin() -> QualificationAPI { QualificationAPI() } }
