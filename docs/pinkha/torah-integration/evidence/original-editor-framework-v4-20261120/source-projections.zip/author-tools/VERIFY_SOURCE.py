#!/usr/bin/env python3
"""Source preservation only. Runs no controls, compiler or platform command."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
def record(raw): return {'bytes': len(raw), 'sha256': digest(raw), 'git_blob': blob(raw)}

def functions(path):
    source = path.read_text()
    lines = source.splitlines(keepends=True)
    return {node.name: ''.join(lines[node.lineno - 1:node.end_lineno])
            for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)}

def methods(path):
    return sorted(node.name for node in ast.walk(ast.parse(path.read_text()))
                  if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'))

def verify():
    base, candidate = ROOT / 'base', ROOT / 'candidate'
    authority = json.loads((ROOT / 'SOURCE_AUTHORITY.json').read_bytes())
    assert authority['source'] == 'a75443e4244762051cb0a99367188dc35645bfbf'
    for row in authority['source_inputs']:
        raw = (base / row['path']).read_bytes()
        assert record(raw) == {key: row[key] for key in ['bytes', 'sha256', 'git_blob']}
    changes, patch = [], ''
    for path in sorted(candidate.rglob('*')):
        if not path.is_file(): continue
        relative = path.relative_to(candidate).as_posix()
        old = (base / relative).read_bytes() if (base / relative).exists() else None
        new = path.read_bytes()
        if old == new: continue
        changes.append({'path': relative, 'before': None if old is None else record(old), 'after': record(new)})
        patch += ''.join(difflib.unified_diff([] if old is None else old.decode().splitlines(keepends=True),
                         new.decode().splitlines(keepends=True), fromfile='a/' + relative, tofile='b/' + relative))
    assert len(changes) == 9 and sum(c['before'] is None for c in changes) == 2
    assert not any(c['path'].startswith(('Anytype/', 'Modules/', 'OriginalEditorFramework/', 'Anytype.xcodeproj/'))
                   for c in changes)
    v3 = b'codex/otzaria-original-editor-framework-v3-reviewed-20261120'
    v4 = b'codex/otzaria-original-editor-framework-v4-reviewed-20261120'
    test_path = 'Tools/OriginalEditor/test_framework.py'
    assert (candidate / test_path).read_bytes().replace(v4, v3) == (base / test_path).read_bytes()
    flow_path = 'Tools/OriginalEditor/test_framework_flow.py'
    assert (candidate / flow_path).read_bytes() == (base / flow_path).read_bytes()
    original = methods(base / test_path) + methods(base / flow_path)
    added = methods(candidate / 'Tools/OriginalEditor/test_framework_duplicates.py') + methods(
        candidate / 'Tools/OriginalEditor/test_framework_source_retention.py')
    assert len(original) == 54 and len(added) == 42 and len(set(original + added)) == 96
    old_driver = functions(base / 'Tools/OriginalEditor/run_framework_acceptance.py')
    new_driver = functions(candidate / 'Tools/OriginalEditor/run_framework_acceptance.py')
    assert old_driver.keys() == new_driver.keys()
    assert [key for key in old_driver if old_driver[key] != new_driver[key]] == ['source_file_proof']
    old_products = functions(base / 'Tools/OriginalEditor/framework_products.py')
    new_products = functions(candidate / 'Tools/OriginalEditor/framework_products.py')
    assert [key for key in old_products if old_products[key] != new_products[key]] == ['export_products']
    assert set(new_products) - set(old_products) == {
        'framework_extended_attributes', 'framework_closure', 'select_framework_products'}
    installer = 'Tools/PinkhaNativeDerived/install_verified_heart.py'
    old_installer, new_installer = (base / installer).read_bytes(), (candidate / installer).read_bytes()
    suffix = b",\n                             '" + v4 + b"'"
    assert new_installer.count(suffix) == 1 and new_installer.replace(suffix, b'', 1) == old_installer
    manifest = 'Tools/OriginalEditor/framework_profile.json'
    old_profile, profile = json.loads((base / manifest).read_bytes()), json.loads((candidate / manifest).read_bytes())
    assert {key for key in old_profile if old_profile[key] != profile[key]} == {'branch', 'original_heart_installer_blob'}
    assert profile['original_heart_installer_blob'] == blob(old_installer)
    workflow = '.github/workflows/pinkha-original-editor-framework.yml'
    assert (candidate / workflow).read_bytes().replace(v4, v3) == (base / workflow).read_bytes()
    protected = ['Anytype.xcodeproj/project.pbxproj',
        'Anytype.xcodeproj/xcshareddata/xcschemes/AnytypeOriginalEditor.xcscheme',
        'OriginalEditorFramework/AnytypeOriginalEditorModule.swift',
        'Tools/OriginalEditor/Consumer/ConsumerApp.swift',
        'Tools/PinkhaNativeDerived/package_evidence.py', 'Tools/Hanlin/prepare_original_editor_heart.py',
        'Tools/Hanlin/prepare_sdk.py', 'Tools/PinkhaSimulatorGate/preflight.py']
    for path in protected: assert (base / path).read_bytes() == (candidate / path).read_bytes()
    for stage, total, passing in [('baseline-red', 85, 80), ('candidate-green', 85, 85),
                                   ('candidate-portable-green', 96, 96), ('candidate-final-green', 96, 96)]:
        cases = json.loads((ROOT / 'runs' / stage / 'CASES.json').read_bytes())
        assert len(cases) == total and sum(case['status'] == 'ok' for case in cases) == passing
        old_cases = {case['method']: case['status'] for case in cases if case['method'] in original}
        assert len(old_cases) == 54 and all(status == 'ok' for status in old_cases.values())
    red = (ROOT / 'runs/darwin-api-red-final/stderr.log').read_text()
    assert 'for name in sorted(os.listxattr(path, follow_symlinks=follow)):' in red
    assert 'AttributeError: Darwin CPython has no Linux os xattr API' in red
    final = json.loads((ROOT / 'runs/candidate-final-green/INPUTS_AFTER.json').read_bytes())
    for path, expected in final.items():
        raw = (candidate / path).read_bytes()
        assert len(raw) == expected['bytes'] and digest(raw) == expected['sha256']
    return {'status': 'PASS_EXACT_SOURCE_PRESERVATION', 'base_source': authority['source'],
            'changed_paths': changes, 'original_test_methods': original, 'new_test_methods': added,
            'original54_unchanged_except_installer_branch_literal': True,
            'original54_passed_all_full_attempts': True,
            'original_driver_unchanged_functions': sorted(set(old_driver) - {'source_file_proof'}),
            'protected_exact_files': protected, 'swift_or_apple_executions': 0,
            'source_or_sdk_or_compiler_flags_changed': False,
            'original_build_boot_runtime_budgets_unchanged': True}, patch

if __name__ == '__main__':
    proof, patch = verify()
    # Optional authoring outputs are metadata only; default prints the proof.
    import sys
    if '--record' in sys.argv:
        (ROOT / 'PRESERVATION.json').write_bytes((json.dumps(proof, indent=2, sort_keys=True) + '\n').encode())
        (ROOT / 'SOURCE_CHANGES.json').write_bytes((json.dumps(proof['changed_paths'], indent=2, sort_keys=True) + '\n').encode())
        (ROOT / 'CANDIDATE.patch').write_bytes(patch.encode())
    print(json.dumps(proof, indent=2, sort_keys=True))
