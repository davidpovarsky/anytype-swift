#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parent

def inputs(directory):
    return {p.relative_to(directory).as_posix(): {
        'bytes': len(raw := p.read_bytes()), 'sha256': hashlib.sha256(raw).hexdigest()}
        for p in sorted(directory.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}

def now(): return datetime.now(timezone.utc).isoformat()

for stage, source, arguments in [
    ('darwin-api-red-final', 'darwin-api-baseline-final', [
        '-m', 'unittest', 'test_framework_duplicates.KnownLibDuplicateControls.'
        'test_whole_exporter_darwin_path_does_not_require_linux_os_xattr', '-v']),
    ('candidate-final-green', 'candidate', [
        '-m', 'unittest', 'discover', '-s', str(root / 'candidate/Tools/OriginalEditor'), '-p', 'test_*.py', '-v'])
]:
    output = root / 'runs' / stage
    output.mkdir(parents=True, exist_ok=False)
    source_root = root / source
    before = inputs(source_root)
    cwd = source_root / 'Tools/OriginalEditor' if stage == 'darwin-api-red-final' else source_root
    command = [sys.executable, *arguments]
    receipt = {'command': command, 'cwd': str(cwd), 'started_at': now(), 'timeout_seconds': 300,
               'platform': 'Actual Linux Python, explicit Darwin libc and Apple tool doubles; no Swift/Apple execution'}
    (output / 'INPUTS_BEFORE.json').write_text(json.dumps(before, indent=2, sort_keys=True) + '\n')
    result = subprocess.run(command, cwd=cwd, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
                            'FRAMEWORK_FLOW_EVIDENCE': str(output / 'flow')}, capture_output=True, timeout=300)
    (output / 'stdout.log').write_bytes(result.stdout)
    (output / 'stderr.log').write_bytes(result.stderr)
    after = inputs(source_root)
    (output / 'INPUTS_AFTER.json').write_text(json.dumps(after, indent=2, sort_keys=True) + '\n')
    assert before == after, 'Tested source changed'
    rows = re.findall(r'(?m)^(test_\S+) \(([^\n]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', result.stderr.decode())
    cases = [{'method': method, 'id': identifier, 'status': status} for method, identifier, status in rows]
    (output / 'CASES.json').write_text(json.dumps(cases, indent=2) + '\n')
    receipt.update(finished_at=now(), exit_code=result.returncode, executed=len(cases),
                   passed=sum(c['status'] == 'ok' for c in cases), failed=sum(c['status'] == 'FAIL' for c in cases),
                   errors=sum(c['status'] == 'ERROR' for c in cases), source_inputs_unchanged=True,
                   stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
                   stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    (output / 'RESULT.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(stage, json.dumps(receipt), flush=True)
