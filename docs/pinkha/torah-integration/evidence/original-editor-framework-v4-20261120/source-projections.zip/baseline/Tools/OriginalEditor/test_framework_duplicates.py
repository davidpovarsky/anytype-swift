"""Whole-exporter controls for the two observed Lib locations; no Apple credit."""
import hashlib
import os
from pathlib import Path
import shutil
import stat
import unittest
from unittest.mock import patch

import framework_products as products_module
import test_framework as original_controls


class KnownLibDuplicateControls(unittest.TestCase):
    def setUp(self):
        original_controls.RealFilesystemExportControls.setUp(self)
        self.first = self.products / 'Lib.framework'
        self.second = self.products / 'PackageFrameworks/Lib.framework'
        self.first.mkdir()
        (self.first / 'Lib').write_bytes(b'EXPLICIT_SYNTHETIC_LIB_NOT_AN_APPLE_BINARY')
        (self.first / 'Lib').chmod(0o755)
        for name, data in [('Info.plist', b'synthetic info'),
                           ('Headers/Lib.h', b'synthetic header'),
                           ('Modules/module.modulemap', b'synthetic module'),
                           ('Resources/item.bin', b'synthetic resource'),
                           ('_CodeSignature/CodeResources', b'synthetic signature')]:
            path = self.first / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        self.second.parent.mkdir()
        shutil.copytree(self.first, self.second, symlinks=True)

    def export(self):
        return products_module.export_products(self.products, self.exported, self.producer)

    def denied(self):
        with self.assertRaises(ValueError):
            self.export()

    def test_exact_known_pair_preserves_complete_equal_inputs_and_exports_one_lib(self):
        value = self.export()
        self.assertEqual(value['frameworks'], ['AnytypeOriginalEditor.framework', 'Lib.framework'])
        proof, = value['verified_known_duplicates']
        self.assertEqual(proof['selected'], 'Lib.framework')
        self.assertEqual(set(proof['source_closures']), {'Lib.framework', 'PackageFrameworks/Lib.framework'})
        first, second = (proof['source_closures'][p] for p in ['Lib.framework', 'PackageFrameworks/Lib.framework'])
        self.assertEqual(first, second)
        self.assertIn('.', first)
        self.assertIn('_CodeSignature/CodeResources', first)
        self.assertEqual(first['Lib']['mode'], 0o755)
        self.assertEqual(first['Lib']['sha256'], hashlib.sha256((self.first / 'Lib').read_bytes()).hexdigest())
        self.assertEqual(proof['materialized_export_closure']['Lib']['sha256'], first['Lib']['sha256'])
        self.assertEqual((self.first / 'Lib').read_bytes(), (self.second / 'Lib').read_bytes())

    def test_different_binary_byte_fails_without_choosing_the_first(self):
        (self.second / 'Lib').write_bytes(b'DIFFERENT_SYNTHETIC_LIB')
        self.denied()

    def test_different_signature_byte_fails(self):
        (self.second / '_CodeSignature/CodeResources').write_bytes(b'different signature')
        self.denied()

    def test_missing_resource_fails(self):
        (self.second / 'Resources/item.bin').unlink()
        self.denied()

    def test_different_relative_filename_with_same_bytes_fails(self):
        (self.second / 'Resources/item.bin').rename(self.second / 'Resources/other.bin')
        self.denied()

    def test_additional_empty_directory_fails(self):
        (self.second / 'additional').mkdir()
        self.denied()

    def test_different_file_mode_fails(self):
        (self.second / 'Lib').chmod(0o644)
        self.denied()

    def test_different_directory_mode_fails(self):
        (self.second / 'Resources').chmod(0o700)
        self.denied()

    def test_different_extended_attribute_fails(self):
        os.setxattr(self.second / 'Lib', 'user.otzaria_export_fixture', b'changed')
        self.denied()

    def test_equal_internal_file_alias_is_materialized(self):
        for root in [self.first, self.second]:
            (root / 'LibraryAlias').symlink_to('Lib')
        value = self.export()
        proof, = value['verified_known_duplicates']
        self.assertEqual(proof['source_closures']['Lib.framework']['LibraryAlias']['link_target'], 'Lib')
        target = self.exported / 'Frameworks/Lib.framework/LibraryAlias'
        self.assertFalse(target.is_symlink())
        self.assertEqual(target.read_bytes(), (self.first / 'Lib').read_bytes())

    def test_equal_versioned_directory_aliases_preserve_all_resolved_members(self):
        for root in [self.first, self.second]:
            (root / 'Versions/A').mkdir(parents=True)
            (root / 'Versions/A/data').write_bytes(b'explicit versioned fixture')
            (root / 'Versions/Current').symlink_to('A', target_is_directory=True)
            (root / 'Current').symlink_to('Versions/Current', target_is_directory=True)
        value = self.export()
        proof, = value['verified_known_duplicates']
        self.assertIn('Current/data', proof['source_closures']['Lib.framework'])
        self.assertEqual((self.exported / 'Frameworks/Lib.framework/Current/data').read_bytes(),
                         b'explicit versioned fixture')

    def test_different_literal_symlink_target_fails_even_with_same_resolved_bytes(self):
        (self.first / 'Alias').symlink_to('Lib')
        (self.second / 'Alias').symlink_to('./Lib')
        self.denied()

    def test_product_alias_to_owned_but_other_framework_fails(self):
        for root in [self.first, self.second]:
            (root / 'Alias').symlink_to(self.products / 'AnytypeOriginalEditor.framework/AnytypeOriginalEditor')
        self.denied()

    def test_cyclic_internal_directory_alias_fails(self):
        for root in [self.first, self.second]:
            (root / 'Cycle').symlink_to('.', target_is_directory=True)
        self.denied()

    def test_broken_alias_fails(self):
        for root in [self.first, self.second]:
            (root / 'Broken').symlink_to('missing')
        self.denied()

    def test_special_fifo_fails_without_reading_it(self):
        for root in [self.first, self.second]:
            os.mkfifo(root / 'fifo')
        self.denied()

    def test_unexpected_third_lib_location_fails(self):
        shutil.copytree(self.first, self.products / 'Other/Lib.framework')
        self.denied()

    def test_same_pair_under_unreviewed_parent_fails(self):
        self.second.parent.rename(self.products / 'OtherPackageFrameworks')
        self.denied()

    def test_duplicate_original_editor_framework_still_fails(self):
        shutil.copytree(self.products / 'AnytypeOriginalEditor.framework',
                        self.products / 'PackageFrameworks/AnytypeOriginalEditor.framework')
        self.denied()

    def test_missing_original_editor_framework_still_fails(self):
        shutil.rmtree(self.products / 'AnytypeOriginalEditor.framework')
        self.denied()

    def test_root_framework_alias_is_not_an_independent_known_product(self):
        shutil.rmtree(self.second)
        self.second.symlink_to(self.first, target_is_directory=True)
        self.denied()

    def test_only_timestamps_may_differ(self):
        os.utime(self.second / 'Lib', (1, 1))
        self.assertEqual(self.export()['frameworks'], ['AnytypeOriginalEditor.framework', 'Lib.framework'])

    def test_known_input_changed_during_copy_cannot_publish_success(self):
        real = products_module.copy_product
        def changed(source, target, producer):
            real(source, target, producer)
            if Path(source) == self.first:
                (self.second / 'Lib').write_bytes(b'changed after admitted comparison')
        with patch.object(products_module, 'copy_product', changed):
            self.denied()

    def test_changed_materialized_output_cannot_publish_success(self):
        real = products_module.copy_product
        def changed(source, target, producer):
            real(source, target, producer)
            if Path(source) == self.first:
                (Path(target) / 'Lib').write_bytes(b'changed exported file')
        with patch.object(products_module, 'copy_product', changed):
            self.denied()


if __name__ == '__main__':
    unittest.main()
