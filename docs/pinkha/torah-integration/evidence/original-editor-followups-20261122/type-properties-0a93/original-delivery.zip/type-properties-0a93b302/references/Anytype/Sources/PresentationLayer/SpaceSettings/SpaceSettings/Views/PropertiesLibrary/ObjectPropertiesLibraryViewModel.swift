import SwiftUI
import Services
import AnytypeCore
import PinkhaKit


@MainActor
@Observable
final class ObjectPropertiesLibraryViewModel: PropertyInfoCoordinatorViewOutput {

    var userProperties: [PropertyDetails] = []
    var systemProperties: [PropertyDetails] = []
    var propertyInfo: PropertyInfoData?

    @ObservationIgnored
    @Injected(\.propertyDetailsStorage)
    private var propertyDetailsStorage: any PropertyDetailsStorageProtocol

    @ObservationIgnored
    @Injected(\.propertiesService)
    private var propertiesService: any PropertiesServiceProtocol

    @ObservationIgnored
    @Injected(\.dataviewService)
    private var dataviewService: any DataviewServiceProtocol

    let spaceId: String
    
    init(spaceId: String) {
        self.spaceId = spaceId
    }
    
    func startSubscriptions() async {
        NotificationCenter.default.addObserver(
            forName: PinkhaTorahPropertyPolicy.canonicalIdentityDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self else { return }
            let notificationSpaceId = notification.userInfo?["spaceId"] as? String
            if notificationSpaceId == nil || notificationSpaceId == self.spaceId {
                let rows = self.propertyDetailsStorage.relationsDetails(spaceId: self.spaceId)
                let visibleProperties = rows.filter {
                    !$0.isHidden &&
                    !PinkhaTorahPropertyPolicy.shared.isInternalProperty(propertyId: $0.id, key: $0.key, spaceId: self.spaceId)
                }
                self.systemProperties = visibleProperties.filter {
                    BundledPropertyKey.systemKeys.map(\.rawValue).contains($0.key)
                }
                self.userProperties = visibleProperties.filter {
                    !BundledPropertyKey.systemKeys.map(\.rawValue).contains($0.key)
                }
            }
        }

        for await rows in propertyDetailsStorage.relationsDetailsPublisher(spaceId: spaceId).values {
            let visibleProperties = rows.filter {
                !$0.isHidden &&
                !PinkhaTorahPropertyPolicy.shared.isInternalProperty(propertyId: $0.id, key: $0.key, spaceId: spaceId)
            }
            
            self.systemProperties = visibleProperties.filter {
                BundledPropertyKey.systemKeys.map(\.rawValue).contains($0.key)
            }
            self.userProperties = visibleProperties.filter {
                !BundledPropertyKey.systemKeys.map(\.rawValue).contains($0.key)
            }
        }
    }
    
    func onRowTap(_ row: PropertyDetails) {
        guard !PinkhaTorahPropertyPolicy.shared.isInternalProperty(propertyId: row.id, key: row.key, spaceId: spaceId) else { return }
        guard let supportedFormat = row.format.supportedFormat else {
            anytypeAssertionFailure("Unsupported format \(row.format)")
            return
        }
        let isNative = TorahNativePropertyDefinition.definition(for: row.key) != nil
        
        propertyInfo = PropertyInfoData(
            name: row.name,
            objectId: nil,
            spaceId: row.spaceId,
            target: .library,
            mode: .edit(relationId: row.id, format: supportedFormat, limitedObjectTypes: row.objectTypes.isEmpty ? nil : row.objectTypes),
            isReadOnly: isNative || row.isReadOnly
        )
    }
    
    func onNewPropertyTap() {
        propertyInfo = PropertyInfoData(
            name: "",
            objectId: nil,
            spaceId: spaceId,
            target: .library,
            mode: .create(format: .text),
            isReadOnly: false
        )
    }
    
    // MARK: - PropertyInfoCoordinatorViewOutput
    func didPressConfirm(_ relation: PropertyDetails) { }
}
