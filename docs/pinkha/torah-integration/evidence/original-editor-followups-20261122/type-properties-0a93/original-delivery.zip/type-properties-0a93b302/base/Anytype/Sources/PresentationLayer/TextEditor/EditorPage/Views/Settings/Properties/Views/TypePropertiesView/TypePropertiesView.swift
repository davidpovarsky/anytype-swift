import SwiftUI
import Services
import AnytypeCore


struct TypePropertiesView: View {

    @State private var model: TypePropertiesViewModel

    @State private var draggedRow: TypePropertiesRow?

    init(data: EditorTypeObject) {
        _model = State(initialValue: TypePropertiesViewModel(data: data))
    }

    init(document: some BaseDocumentProtocol) {
        _model = State(initialValue: TypePropertiesViewModel(document: document))
    }
    
    var body: some View {
        content
            .task { await model.setupSubscriptions() }
            .sheet(item: $model.relationsSearchData) { data in
                PropertyCreationView(data: data)
            }
            .sheet(item: $model.propertyData) {
                PropertyInfoCoordinatorView(data: $0, output: nil)
            }
            .anytypeSheet(isPresented: $model.showConflictingInfo) {
                ObjectPropertiesBottomAlert()
            }
            .snackbar(toastBarData: $model.toastBarData)
    }
    
    var content: some View {
        VStack(spacing: 0) {
            DragIndicator()
            navigationBar
            banner
            fieldsList
        }
    }
    
    private var navigationBar: some View {
        HStack {
            Spacer()
            AnytypeText(Loc.fields, style: .uxTitle1Semibold)
                .foregroundStyle(Color.Text.primary)
            Spacer()
        }
        .frame(height: 48)
        .padding(.horizontal, 16)
    }
    
    private var banner: some View {
        HStack(spacing: 0) {
            Spacer()
            AnytypeText(Loc.ObjectType.editingType, style: .caption1Medium)
            Spacer.fixedWidth(8)
            IconView(icon: model.document.details?.objectIconImage).frame(width: 18, height: 18)
            Spacer.fixedWidth(5)
            AnytypeText(model.document.details?.title ?? "", style: .caption1Medium)
            Spacer()
        }
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity)
        .background(Color.Shape.transparentSecondary)
    }
    
    private var fieldsList: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 0) {
                propertiesSection
                
                if model.conflictRelations.isNotEmpty {
                    localFieldsSection
                        .padding(.horizontal, 20)
                }
            }
        }
        
        .listStyle(.plain)
        .buttonStyle(BorderlessButtonStyle())
    }
    
    private var propertiesSection: some View {
        ForEach(model.relationRows) { row in
            propertyRowContent(row)
                .onDrop(of: [.text], delegate: TypePropertiesDropDelegate(
                    destinationRow: row,
                    document: model.document,
                    draggedRow: $draggedRow,
                    allRows: $model.relationRows)
                )
        }
    }

    @ViewBuilder
    private func propertyRowContent(_ row: TypePropertiesRow) -> some View {
        switch row {
        case .header(let header):
            headerRow(header).padding(.horizontal, 20)
        case .relation(let relation):
            propertyRow(relation)
                .divider()
        case .emptyRow:
            Rectangle().foregroundStyle(Color.clear).fixTappableArea().frame(height: 52)
        }
    }
    
    private func headerRow(_ data: TypePropertiesSectionRow) -> some View {
        ListSectionHeaderView(title: data.title, increasedTopPadding: true) {
            if model.canEditPropertiesList && data.canCreateRelations {
                Button(action: {
                    model.onAddRelationTap(section: data)
                }, label: {
                    IconView(asset: .X24.plus).frame(width: 24, height: 24)
                })
                .accessibilityLabel(Loc.addProperty)
                .accessibilityIdentifier("torah-type-add-property")
            }
        }
    }
    
    private func propertyRow(_ data: TypePropertiesRelationRow) -> some View {
        HStack(spacing: 0) {
            Button {
                model.onRelationTap(data)
            } label: {
                Image(asset: data.relation.iconAsset)
                    .foregroundStyle(Color.Control.secondary)
                Spacer.fixedWidth(10)
                AnytypeText(data.relation.name, style: .uxBodyRegular)
                
                Spacer()
            }.disabled(!model.canInspectRelation(data))
            
            if model.canEditPropertiesList && model.isRelationHidden(data) {
                Button {
                    model.onRelationReveal(data)
                } label: {
                    AnytypeText(Loc.show, style: .caption1Medium)
                        .foregroundStyle(Color.Text.secondary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.Shape.tertiary)
                        .clipShape(.rect(cornerRadius: 4))
                }
                .accessibilityIdentifier("torah-type-property-show-\(data.relation.key)")
                .padding(.trailing, 8)
            }

            if model.canEditPropertiesList && data.canDrag {
                MoveIndicator()
            }
        }
        .frame(height: 52)
        .contentShape([.dragPreview], RoundedRectangle(cornerRadius: 4, style: .continuous))
        
        .padding(.horizontal, 20)
        .contextMenu {
            if model.canEditPropertiesList {
                if model.isRelationHidden(data) {
                    Button(Loc.show) {
                        model.onRelationReveal(data)
                    }
                } else {
                    Button(Loc.hide) {
                        model.onRelationHide(data)
                    }
                }
                if model.canRemoveRelation(data) {
                    Button(Loc.remove, role: .destructive) {
                        model.onRelationRemove(data)
                    }
                }
            }
        }
        
        .if(model.canEditPropertiesList && data.canDrag) {
            $0.onDrag {
                draggedRow = .relation(data)
                return NSItemProvider()
            } preview: {
                EmptyView()
            }
        }
    }
    
    // MARK: - Local fields
    private var localFieldsSection: some View {
        VStack(spacing: 0) {
            Button(action: {
                model.onConflictingInfoTap()
            }, label: {
                ListSectionHeaderView(title: Loc.Fields.foundInObjects, increasedTopPadding: true) {
                    Image(systemName: "questionmark.circle.fill").foregroundStyle(Color.Control.secondary)
                        .frame(width: 18, height: 18)
                }
            })
            
            ForEach(model.conflictRelations) {
                localFieldRow($0)
            }
        }
    }
    
    private func localFieldRow(_ data: PropertyDetails) -> some View {
        HStack(spacing: 0) {
            Menu {
                Button(Loc.Fields.addToType) { model.onAddConflictRelation(data) }
            } label: {
                Image(asset: data.format.iconAsset)
                    .foregroundStyle(Color.Control.secondary)
                Spacer.fixedWidth(10)
                AnytypeText(data.name, style: .uxBodyRegular)
                
                Spacer()
        
                MoreIndicator()
            }
        }
        .frame(height: 52)
    }
}
