Frozen TypeProperties source packet, base bbd11635598a77d98e7ffcb336fafee9a75eba10
Patch SHA256 0a93b302ace640edef150621211cbf46aaacf4e641c942cd6caf1236d1fb4094
The seven changed preimages/outputs, unchanged property-scope reference, exact final manifest, source/syntax receipts, prior one-line-delta lineage, reviews and original source references are retained.
No tests or compiler invocations were repeated for packaging. Syntax-only evidence does not establish Apple semantic/Native acceptance.
Check PACKAGE_CONTENTS.json and CANDIDATE_INPUTS.json before integration. Apply the patch only to verified Git preimages in an isolated worktree; do not copy outputs over arbitrary newer source.
audit_candidate.py is retained as historical verification source and writes candidate/patch/receipt files if run. Do not execute it in this immutable packet; copy to an isolated scratch directory first.
