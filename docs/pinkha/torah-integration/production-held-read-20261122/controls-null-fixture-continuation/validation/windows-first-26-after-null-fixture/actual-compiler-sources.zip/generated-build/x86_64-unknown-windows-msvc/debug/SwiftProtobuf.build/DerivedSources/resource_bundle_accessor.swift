import Foundation

extension Foundation.Bundle {
    static nonisolated let module: Bundle = {
        let mainPath = Bundle.main.bundleURL.appendingPathComponent("SwiftProtobuf_SwiftProtobuf.resources").path
        let buildPath = "C:\\Users\\DAVID\\AppData\\Local\\Temp\\ohr-20261122\\b\\x86_64-unknown-windows-msvc\\debug\\SwiftProtobuf_SwiftProtobuf.resources"

        let preferredBundle = Bundle(path: mainPath)

        guard let bundle = preferredBundle ?? Bundle(path: buildPath) else {
            // Users can write a function called fatalError themselves, we should be resilient against that.
            Swift.fatalError("could not load resource bundle: from \(mainPath) or \(buildPath)")
        }

        return bundle
    }()
}