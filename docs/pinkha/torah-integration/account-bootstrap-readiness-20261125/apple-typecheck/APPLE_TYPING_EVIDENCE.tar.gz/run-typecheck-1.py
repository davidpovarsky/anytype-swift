from pathlib import Path
import os,json,hashlib,shutil,subprocess,time,signal,resource,shlex,sys
base=Path('/Users/m1/builds/anytype-account-bootstrap-f8a3984-20261125')
attempt=base/'attempt-1';attempt.mkdir(mode=0o700)
evidence=attempt/'evidence';evidence.mkdir(mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=base/'SOURCE_INPUTS.json'
assert sha(manifest)=='0b28003e5d404b556ef39f0e173cb80574932178f8847a4148fce9d6057a605e'
m=json.loads(manifest.read_text())
assert m['source_commit']=='f8a3984aaeb927dd60668db6f187459db0051a9c'
def write(name,value):
 with (evidence/name).open('x') as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
def free():return shutil.disk_usage('/System/Volumes/Data').free
def size(path):return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())
reserve=128*1024**2;other=5*1024**3
cache=Path('/Users/m1/builds/anytype-annotation-exchange-20261125/module-cache')
before_cache=size(cache)
result={'status':'ADMISSION_PENDING','source_commit':m['source_commit'],'source_manifest_sha256':sha(manifest),'primary':'OriginalEditorFramework/AnytypeOriginalEditorAccountSession.swift','complete_source_count':len(m['files']),'public_contract_requirements':260,'debug_only_requirements':22,'sdk_product_built':False,'runtime_tests_executed':0,'route':'actual Apple simulator full-context single-primary typecheck','target':'arm64-apple-ios27.0-simulator','own_remaining_bytes':reserve,'other_phase_remaining_bytes':other,'free_before':free(),'reused_owned_module_cache':str(cache),'cache_bytes_before':before_cache}
write('ADMISSION.json',result)
if result['free_before']<other+reserve:
 result['status']='BLOCKED_BEFORE_COMPILER';write('RESULT.json',result);print(json.dumps(result));sys.exit(2)
old=json.loads((base/'original-command.json').read_text())
old=old if isinstance(old,list) else old.get('argv',old.get('command'))
assert '-typecheck' in old and '-o' not in old and '-emit-module-path' not in old
oldprimary=[];kept=[];oldlist=None;i=0
while i<len(old):
 if old[i]=='-primary-file':oldprimary.append(old[i+1]);i+=2;continue
 if old[i]=='-filelist':oldlist=Path(old[i+1]);i+=2;continue
 kept.append(old[i]);i+=1
assert oldlist is not None
context=[]
for line in oldlist.read_text().splitlines():
 values=shlex.split(line);assert len(values)==1;context.append(values[0])
assert set(context+oldprimary)=={x['original_path'] for x in m['files']}
assert len(context)+len(oldprimary)==len(m['files'])
mapping={};inputs={}
for row in m['files']:
 original=Path(row['original_path'])
 assert sha(original)==row['original_sha256'],str(original)
 current=base/'source'/row['replacement'] if 'replacement' in row else original
 expected=row.get('current_sha256',row['original_sha256'])
 assert sha(current)==expected,str(current)
 mapping[str(original)]=str(current);inputs[str(current)]=expected
primaryrow=[x for x in m['files'] if x.get('repo_path')==m['primary_repo_path']]
assert len(primaryrow)==1
primary=mapping[primaryrow[0]['original_path']]
context=[mapping[p] for p in context+oldprimary if mapping[p]!=primary]
assert len(context)==len(inputs)-1 and len(set(context))==len(context)
filelist=attempt/'context.SwiftFileList';filelist.write_text('\n'.join(context)+'\n')
assert kept[kept.index('-module-cache-path')+1]==str(cache)
command=kept+['-primary-file',primary,'-filelist',str(filelist)]
write('command.json',command);write('ACTUAL_SOURCE_MANIFEST.json',inputs)
version=subprocess.check_output([command[0],'-version'],text=True,stderr=subprocess.STDOUT)
(evidence/'compiler-version.txt').write_text(version)
census=subprocess.check_output(['ps','-axo','pid,ppid,rss,comm'],text=True)
(evidence/'process-census-before.txt').write_text(census)
started=time.monotonic();minimum=free();stop=''
with (evidence/'stdout.log').open('xb') as out,(evidence/'stderr.log').open('xb') as err:
 proc=subprocess.Popen(command,cwd=base,stdout=out,stderr=err,start_new_session=True)
 write('PROCESS.json',{'pid':proc.pid,'process_group':proc.pid})
 while proc.poll() is None:
  current=free();minimum=min(minimum,current)
  if current<other or time.monotonic()-started>150:
   stop='phase_growth_budget_exhausted' if current<other else 'bounded_compiler_deadline'
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   break
  time.sleep(0.2)
 code=proc.wait()
result.update(exit=code,elapsed_seconds=round(time.monotonic()-started,3),minimum_sampled_free_bytes=minimum,free_after=free(),child_peak_rss_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,stop_reason=stop,changed_during_compile=[p for p,h in inputs.items() if sha(Path(p))!=h],donor_input_changed=[x['original_path'] for x in m['files'] if sha(Path(x['original_path']))!=x['original_sha256']],cache_bytes_after=size(cache),owned_candidate_bytes=size(base),stderr_sha256=sha(evidence/'stderr.log'),stdout_sha256=sha(evidence/'stdout.log'))
result['status']='PASS' if code==0 and not stop and not result['changed_during_compile'] and not result['donor_input_changed'] else 'FAIL'
write('RESULT.json',result)
print(json.dumps({'result':result,'stderr_tail':(evidence/'stderr.log').read_text()[-10000:]}))
sys.exit(0 if result['status']=='PASS' else 1)
