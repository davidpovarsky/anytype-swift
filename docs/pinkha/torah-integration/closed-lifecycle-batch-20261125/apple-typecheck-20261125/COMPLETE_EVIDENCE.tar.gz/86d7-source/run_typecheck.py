import pathlib,json,hashlib,tarfile,shutil,subprocess,os,time,signal,resource,sys
root=pathlib.Path("/Users/m1/builds/anytype-lifecycle-batch-86d738c6-20261125")
source=root/"source";evidence=root/"attempt-1";evidence.mkdir(mode=0o700,exist_ok=False)
manifest_path=root/"transfer/SOURCE_INPUTS.json";manifest_bytes=manifest_path.read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest()=="8ef5cba1d6abf61f21d66b9edd28306be7d7c238acdc129158cdb178e92e1d80"
manifest=json.loads(manifest_bytes);archive=root/"transfer/SOURCE.tar.gz"
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest["archive_sha256"]
assert source.is_dir() and not source.is_symlink()
expected={x["path"]:x for x in manifest["files"]}
with tarfile.open(archive,"r:gz") as tf:
 members=tf.getmembers()
 assert len(members)==len(expected) and set(x.name for x in members)==set(expected)
 for member in members:
  rel=pathlib.PurePosixPath(member.name);assert member.isfile()and not rel.is_absolute()and".."not in rel.parts
  data=tf.extractfile(member).read();item=expected[member.name]
  assert len(data)==item["bytes"]and hashlib.sha256(data).hexdigest()==item["sha256"]
  dest=source/member.name;assert dest.is_file() and not dest.is_symlink() and dest.read_bytes()==data
prior=pathlib.Path("/Users/m1/builds/anytype-annotation-exchange-20261125/revision-evidence-3-ssh")
old_root=pathlib.Path("/Users/m1/builds/anytype-annotation-exchange-20261125")
donor=pathlib.Path("/Users/m1/builds/anytype-34b8a7c5ddb3-sdk")
old_manifest=json.loads((prior/"SOURCE_MANIFEST.json").read_text())
context=[];generated=[];seen=set()
for raw in (prior/"context.SwiftFileList").read_text().splitlines():
 p=pathlib.Path(raw)
 if p.is_relative_to(old_root):rel=str(p.relative_to(old_root))
 elif p.is_relative_to(donor):rel=str(p.relative_to(donor))
 else:raise ValueError("unknown retained source root")
 if rel in expected:p=source/rel
 b=p.read_bytes()
 if rel in manifest["current_git_source_blobs"]:
  assert hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==manifest["current_git_source_blobs"][rel],rel
 elif rel.endswith("/DerivedSources/GeneratedAssetSymbols.swift"):
  assert hashlib.sha256(b).hexdigest()==old_manifest[raw];generated.append(str(p))
 else:raise ValueError("unbound current source "+rel)
 assert str(p)not in seen;seen.add(str(p));context.append(str(p))
for rel in sorted(expected):
 p=str(source/rel)
 if p not in seen:context.append(p);seen.add(p)
assert len(context)==2281,(len(context),"unexpected complete source closure")
primaries=[str(source/rel)for rel in sorted(expected)]
assert all(p in context for p in primaries)
(evidence/"context-complete.SwiftFileList").write_text("\n".join(context)+"\n")
(evidence/"context.SwiftFileList").write_text("\n".join(context)+"\n")
hashes={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()for p in context}
(evidence/"SOURCE_MANIFEST.json").write_text(json.dumps(hashes,sort_keys=True,indent=2)+"\n")
cmd=json.loads((prior/"command.json").read_text());args=[cmd[0]];i=1
while i<len(cmd):
 if cmd[i]in["-primary-file","-filelist"]:i+=2;continue
 args.append(cmd[i]);i+=1
for p in primaries:args+=["-primary-file",p]
args+=["-filelist",str(evidence/"context.SwiftFileList")]
(evidence/"command.json").write_text(json.dumps(args,indent=2)+"\n")
cache=pathlib.Path(args[args.index("-module-cache-path")+1])
def tree_bytes(p):return sum(x.stat().st_size for x in p.rglob("*")if x.is_file()and not x.is_symlink())
before=shutil.disk_usage(root).free;cache_before=tree_bytes(cache)
admission={"free_before":before,"estimated_own_remaining_bytes":1024**3,"external_remaining_bytes":int(3.125*1024**3),"os_margin_bytes":2*1024**3,"reuse_owned_compatible_module_cache":str(cache),"cache_bytes_before":cache_before}
(evidence/"ADMISSION.json").write_text(json.dumps(admission,indent=2)+"\n")
assert before>=int(6.125*1024**3),("storage phase no longer fits",before)
(evidence/"memory-before.txt").write_text(subprocess.run(["vm_stat"],capture_output=True,text=True).stdout)
start=time.monotonic();minimum=before;reason="";peak=0
with (evidence/"stdout.log").open("wb")as out,(evidence/"stderr.log").open("wb")as err:
 p=subprocess.Popen(args,cwd=donor,stdout=out,stderr=err,start_new_session=True)
 while p.poll()is None:
  free=shutil.disk_usage(root).free;minimum=min(minimum,free)
  if free<int(5.125*1024**3):reason="external_plus_os_reserve_no_longer_fits"
  if time.monotonic()-start>240:reason="compile_timeout"
  if reason:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.5)
 p.wait()
changed=[x for x,h in hashes.items()if hashlib.sha256(pathlib.Path(x).read_bytes()).hexdigest()!=h]
result={"status":"PASSED_REAL_IOS_COMPLETE_CONTEXT_PRIMARY_TYPECHECK"if p.returncode==0 and not reason and not changed else"FAILED_REAL_IOS_COMPLETE_CONTEXT_PRIMARY_TYPECHECK","exit":p.returncode,"stop_reason":reason,"elapsed_seconds":round(time.monotonic()-start,3),"primary_files":len(primaries),"complete_source_count":len(context),"generated_retained_sources":generated,"source_checkpoint":manifest["source_checkpoint"],"source_manifest_sha256":hashlib.sha256((evidence/"SOURCE_MANIFEST.json").read_bytes()).hexdigest(),"changed_during_compile":changed,"target":"arm64-apple-ios27.0-simulator","source_and_native_runtime_tests":0,"sdk_product_built":False,"route":"pinned Oracle ubuntu SSH scaleway-mac","minimum_sampled_free_bytes":minimum,"free_after":shutil.disk_usage(root).free,"child_peak_rss_bytes":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"owned_candidate_bytes":tree_bytes(root),"reused_owned_module_cache_growth_bytes":tree_bytes(cache)-cache_before,"stdout_sha256":hashlib.sha256((evidence/"stdout.log").read_bytes()).hexdigest(),"stderr_sha256":hashlib.sha256((evidence/"stderr.log").read_bytes()).hexdigest()}
(evidence/"RESULT.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
print(json.dumps(result));sys.exit(0 if result["status"].startswith("PASSED")else 1)
