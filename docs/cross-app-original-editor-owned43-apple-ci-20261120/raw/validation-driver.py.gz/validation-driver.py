
from pathlib import Path
import subprocess,sys,os,json,hashlib,ast,re,time,datetime,traceback
root=Path(r"C:\Users\DAVID\Code\anytype-original-editor-owned43-ci-20261120")
build=root/"build"/"owned43-apple-ci-20261120"
base="0a3e80ce2b286ffe2caa7537bf12e3d1d423b25e"
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(["git","-C",str(root),*args])
def write(path,obj): path.write_bytes((json.dumps(obj,indent=2,sort_keys=True)+"\n").encode())
tracked=git("ls-files","-z").decode().split("\0")
inputs=[p for p in tracked if p.startswith("Tools/Hanlin/") and Path(p).suffix in (".py",".json")]
inputs+=["Tools/PinkhaNativeDerived/install_verified_heart.py","Tools/PinkhaNativeDerived/build_custom_heart.py",".github/workflows/pinkha-original-editor.yml"]
manifest=json.loads((root/"Tools/Hanlin/original_editor_profile.json").read_bytes())
inputs+= [i["path"] for i in manifest["suites"].values()]
inputs=sorted(set(inputs))
before={p:sha((root/p).read_bytes()) for p in inputs}
write(build/"INPUTS_BEFORE.json",before)
result={"started_utc":stamp(),"platform":sys.platform,"python":sys.version,"source_head":git("rev-parse","HEAD").decode().strip(),"application_base":base,"status":"RUNNING","commands":[],"inputs":len(inputs)}
def run(name,argv,timeout=120,env=None):
 start=time.monotonic()
 p=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=timeout)
 (build/(name+".stdout")).write_bytes(p.stdout)
 (build/(name+".stderr")).write_bytes(p.stderr)
 row={"name":name,"argv":argv,"exit_code":p.returncode,"duration_seconds":round(time.monotonic()-start,3),"stdout_sha256":sha(p.stdout),"stderr_sha256":sha(p.stderr)}
 result["commands"].append(row)
 return p,row
try:
 files=sorted(p for p in inputs if re.fullmatch(r"Tools/Hanlin/test_run_host.*\.py",p))
 def declarations(s,p):
  tree=ast.parse(s)
  return sorted(p+":"+c.name+"."+f.name for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name.startswith("test_"))
 old_ids=sorted(x for p in files for x in declarations(git("show",base+":"+p).decode(),p))
 new_ids=sorted(x for p in files for x in declarations((root/p).read_text(encoding="utf-8"),p))
 assert old_ids==new_ids and len(new_ids)==74,(len(old_ids),len(new_ids))
 result["host_method_inventory"]={"declared":74,"same_exact_ids_as_parent":True,"ids":new_ids}
 p,row=run("host-controls74",[sys.executable,"-B","-m","unittest","discover","-s","Tools/Hanlin","-p","test_run_host*.py","-v"])
 output=p.stdout.decode("utf-8",errors="replace")+p.stderr.decode("utf-8",errors="replace")
 records=[]
 for line in output.splitlines():
  m=re.match(r"^(test_\w+) \((.+)\) \.\.\. (.+)$",line)
  if m: records.append({"method":m.group(1),"owner":m.group(2),"result":m.group(3)})
 passed=sum(x["result"]=="ok" for x in records)
 skipped=[x for x in records if x["result"].startswith("skipped")]
 errors=[x for x in records if x["result"]!="ok" and not x["result"].startswith("skipped")]
 result["host_controls"]={"exit_code":p.returncode,"registered":74,"reported":len(records),"passed":passed,"skipped":skipped,"failures_or_errors":errors,"records":records}
 write(build/"HOST_CONTROLS74.json",result["host_controls"])
 assert p.returncode==0 and len(records)==74 and passed==72 and len(skipped)==2 and not errors,result["host_controls"]
 assert all("POSIX" in x["result"] or "posix" in x["result"] for x in skipped),skipped
 old=(build/"before/Tools/PinkhaNativeDerived/install_verified_heart.py").read_text()
 current=(root/"Tools/PinkhaNativeDerived/install_verified_heart.py").read_text()
 newbranch="codex/otzaria-original-editor-owned43-apple-reviewed-20261120"
 expectedaddition="                             'codex/otzaria-original-editor-owned-apple-v2-reviewed-20261120',\n                             '"+newbranch+"'],"
 expectedold="                             'codex/otzaria-original-editor-owned-apple-v2-reviewed-20261120'],"
 assert current.replace(expectedaddition,expectedold)==old
 def choices(source):
  tree=ast.parse(source)
  for n in ast.walk(tree):
   if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=="add_argument" and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=="--expected-app-branch":
    return ast.literal_eval(next(k.value for k in n.keywords if k.arg=="choices"))
  raise AssertionError("choices missing")
 oldchoices=choices(old);newchoices=choices(current)
 assert newchoices==oldchoices+[newbranch]
 env=dict(os.environ);env["PYTHONPATH"]=str(root/"Tools/PinkhaNativeDerived");env["PYTHONDONTWRITEBYTECODE"]="1"
 missing=build/"deliberately-absent-inventory.json"
 assert not missing.exists()
 common=["--archive",str(build/"absent-framework.tar.gz"),"--inventory",str(missing),"--patch",str(build/"absent.patch"),"--app-source",str(root),"--source-run-id","44203168617","--evidence",str(build/"never-created-install-evidence")]
 parse=[]
 bp,br=run("installer-baseline-rejects43",[sys.executable,"-B",str(build/"before/Tools/PinkhaNativeDerived/install_verified_heart.py"),*common,"--expected-app-branch",newbranch],30,env)
 txt=bp.stderr.decode(errors="replace")
 assert bp.returncode==2 and "invalid choice" in txt and "FileNotFoundError" not in txt
 parse.append({"name":br["name"],"pass":True,"observed":"argparse rejection before inventory IO","exit_code":bp.returncode})
 for i,branch in enumerate(newchoices):
  p,r=run("installer-current-accepted-branch-%02d"%i,[sys.executable,"-B",str(root/"Tools/PinkhaNativeDerived/install_verified_heart.py"),*common,"--expected-app-branch",branch],30,env)
  txt=p.stderr.decode(errors="replace")
  assert p.returncode==1 and "FileNotFoundError" in txt and missing.name in txt and "invalid choice" not in txt,(branch,txt)
  parse.append({"name":r["name"],"branch":branch,"pass":True,"observed":"accepted by original argparse; deliberately absent inventory stopped all installation IO","exit_code":p.returncode})
 p,r=run("installer-current-rejects-unreviewed",[sys.executable,"-B",str(root/"Tools/PinkhaNativeDerived/install_verified_heart.py"),*common,"--expected-app-branch","codex/otzaria-unreviewed-control"],30,env)
 assert p.returncode==2 and "invalid choice" in p.stderr.decode(errors="replace") and "FileNotFoundError" not in p.stderr.decode(errors="replace")
 parse.append({"name":r["name"],"pass":True,"observed":"unreviewed branch rejected before inventory IO","exit_code":p.returncode})
 assert not (build/"never-created-install-evidence").exists()
 result["installer_parser"]={"checks":len(parse),"passed":len(parse),"old_choices":oldchoices,"new_choices":newchoices,"original_eight_preserved":True,"installer_body_exact_inverse":True,"records":parse,"actual_framework_installations":0}
 write(build/"INSTALLER_PARSER.json",result["installer_parser"])
 sys.path.insert(0,str(root/"Tools/Hanlin"))
 import original_editor_profile as profile
 methods,testfiles=profile.expected_methods(root)
 assert len(methods)==43 and len(testfiles)==7
 result["selection"]={"exact_methods":sorted(methods),"count":len(methods),"files":testfiles,"head_application_trees_verified":True,"ui_executed":0}
 write(build/"DECLARATIONS43.json",result["selection"])
 result["status"]="WINDOWS_PYTHON_CONTROLS_PASS_APPLE_NOT_RUN"
except BaseException:
 result["status"]="FAILED"
 result["exception"]=traceback.format_exc()
finally:
 after={p:sha((root/p).read_bytes()) for p in inputs}
 write(build/"INPUTS_AFTER.json",after)
 result["source_inputs_unchanged"]=after==before
 result["finished_utc"]=stamp()
 write(build/"VALIDATION_RESULT.json",result)
 print(json.dumps({"status":result["status"],"host_controls":{k:v for k,v in result.get("host_controls",{}).items() if k not in ("records",)},"parser_checks":result.get("installer_parser",{}).get("checks"),"inputs":len(inputs),"source_inputs_unchanged":after==before,"duration_seconds":sum(x["duration_seconds"] for x in result["commands"]),"finished_utc":result["finished_utc"],"exception":result.get("exception")},ensure_ascii=False))
 if result["status"]=="FAILED" or after!=before: sys.exit(1)
