# Original editor CI43: actual Linux host controls

The unchanged 74 Python host controls passed on Linux at 14:25:31 UTC on 2026-11-20: **74 passed, zero failures, zero errors, zero skips**. The two original POSIX process-group controls actually executed. This is supplementary host-controller evidence; no Apple build, XCTest, Native UI, embedded-editor, or live-write outcome is claimed.

## Exact scope and source

The executed CI source is 48a64236b209b4121d93e2e688caa74a43280eed, with documentation checkout fe580295ed3c323195cb1d4a6927e21ec5fad9e0; its application source is 0a3e80ce2b286ffe2caa7537bf12e3d1d423b25e. This does not alter any frozen Apple branch. The earlier Windows result remains 72 passes plus two original POSIX skips.

A bounded export copied canonical Git blobs, the genuine HEAD commit and all original directory-tree objects. Linux initialized a local Git repository from those real objects and restored the complete original index. Its 1,286,810-byte index was byte-identical to the original Windows source index, SHA256 379405d4be269ec6e1fbcb3cf30dd7380ab1f2a1a2cbfec61e0141870b049251. No synthetic commit, Git-command wrapper or network source fallback was used. Application blobs outside the selected source closure were not materialized; this is not a full clean application checkout or an application compilation.

The final 26-file closure includes the genuine indirect dependency Tools/PinkhaNativeDerived/build_native_ipa.py, Git blob cb509ecc637ffb669569bfafd7471ba924a5c851, SHA256 c9e35a228779ae761d36cef204a32148ffdd3a338c9ede11dde6df4ebee21055. All 26 actual input files matched their canonical Git blobs and retained their hashes after execution. The original 74 declared method IDs were identical across attempts. Tests, skip guards, production code and time bounds were unchanged.

## Failed attempts retained

1. The initial Windows git-archive preparation yielded CRLF working projections. Canonical-blob verification rejected it before transfer or tests. The exact archive, diagnosis and receipt remain sealed.
2. The single-use Sentinel transfer returned HTTP 403 with no archive content. The same owned 893,317-byte ZIP was subsequently transferred as 28 bounded MCP reads, with every chunk and the final SHA256 verified. No alternate source was fetched.
3. Linux attempt 1 executed all 74 controls, with 73 passes, one error and zero skips. Both POSIX controls already passed. The one error was an incomplete 25-file export: an unchanged test reads the original Tools/PinkhaNativeDerived/build_native_ipa.py, then uses its original local fallback if that file is absent. The missing file was added from the same exact Git commit; no test or source correction was made.
4. Linux attempt 2 reran the same original command against the corrected 26-file closure and passed all 74. Attempt 1 is preserved as a failure and its 25-file input claim is not rewritten.

The POSIX controls exercise successful and failed child commands with their receipts, and signal cancellation that flushes partial output and terminates only the owned child process group. They do not establish macOS or iOS behavior; Apple CI remains a separate source-bound gate.

## Evidence format

RESULT.json is the compact review record. RAW_FILES.json maps every original Linux receipt, runner, command output and input inventory to lossless gzip bytes in raw/; identical byte streams are deduplicated by SHA256 while all original logical paths remain listed. Both complete per-case unittest logs and both exact runner scripts are retained. MANIFEST.json seals every durable file except itself. The original canonical transfer ZIP and Windows export-preparation records are additionally retained under export/.

The real runtime was Linux 6.18.57 x86_64/glibc 2.41 and Python 3.12.14. No Swift compiler, SDK, Heart binary, source writer, application engine or user data was used or modified by this supplementary run.
