#!/usr/bin/env python3
"""Complete final Files authority34 with32 retained unit events and2 new SDK events.

The original attempt4 receipt remains FAIL after a fragmented measurement-output
parse. Pin and requalify that exact public source/log/closed-command chain, join
only the same Package/Test output fragments, and run only the two never-started
fresh SDK methods. No retained account, private export, Any CLI, unit rerun or
measurement rerun is part of this continuation.
"""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import shlex
import signal
import stat
import sys
import time

MIB = 1024**2
GIB = 1024**3
HERE = Path('/mnt/development/projects/evidence/pinkha-final-files-authority-source-20261127-attempt1')
CONTINUATION_SOURCE = Path('/mnt/development/projects/evidence/pinkha-final-files-authority-completion-source-20261127-attempt2')
PARENT = Path('/mnt/development/projects/evidence/pinkha-w1-fresh-files-open-20261127')
PRIOR = PARENT/'attempt4'
PRIOR_RECEIPT_SHA = '173fdab404efc5340035151022946ae2324543cb7f10889fc47257efa79f24df'
PRIOR_UNIT_LOG_SHA = '5755748de4ee2bb1477dba8f1c8ad2218202258bc53d97ca997e124a653f9313'
PRIOR_METADATA_LOG_SHA = '865117f0fe0f842b406e0a216c4f9c249a7a2df9b66e478067066f5ef3485c1d'
PRIOR_SOURCE_SHA = 'c70cea6f04851ccbbb6b312a4e760bfd3659351927439ec9632b71f81dbe3b82'
ORIGINAL_QUALIFIER_SHA = '92fd3781063138f11055631db09ec39a3e519b65a0d44bcab4284cdceae1872c'
BASE = Path('/var/lib/pinkha-c-filesv2-20261126/readguard-native1')
BASE_RECEIPT_SHA = 'e26587d911cec570f9215db8bc424f9faa7fe2d09c4354f71cdb772e6fafd394'
BASE_MANIFEST_SHA = 'aa43f853a28c2cd0e125b70cdcc01b05a4748f0c25541f5ed86cea511e6b8dd1'
BASE_SOURCE = BASE/'source/.runtime-artifacts/sdk-source'
CANDIDATE_SHA = '71c0b47b5aea45a9ab0a2498f56361b0b7239fab183e37af7bb365dfb9b2ee81'
PATCH_SHA = '9088b91cd098124b68d794185898aaf29d829a0e1b44ad3e8e06c914f4bb0350'
METADATA_SHA = 'd2fa0dd59b0826918631c71b6d1b5b2561599897b438077bdf53cc3b34f38af8'
CACHE_EFFECT_SHA = 'eb0b1fa3c432a56d0767ae856043aa32b39bcde694133e432b25b34087f86a22'
FRESH_INVERSE_SHA = '31fc741523900913eccce7df053cfb5e4c1f22e917371ba60d7abdc229ae75bc'
FORMAT_SHA = 'b54b2e7b5c7c79a797cc41a48fbfc4ae56b6f32a199b7a42a91c4195b7d81528'
FRESH_RECEIPT = PARENT/'attempt2/result.json'
FRESH_RECEIPT_SHA = '4eb696473d3cc199f935f826944a03681e0decd16047039579aba9718fc2ff35'
SIGNED_RECEIPT = Path('/mnt/development/projects/evidence/pinkha-w1-files-readguard-synthetic-20261127/attempt1/result.json')
SIGNED_RECEIPT_SHA = '68964e6db8802065ba69edad5614ec52cde3603b14f9628d65d808aa76563766'
BASELINE_RECEIPT = Path('/var/lib/pinkha-c-filesv2-20261126/current-authority-http-20261127/attempt1/result.json')
BASELINE_RECEIPT_SHA = '7efa899783f5cabb54b2693dca0a22a9571d499ef4b9838749dfb8e677784099'
FRESH_FIXTURE_SHA = 'b7d91dd885239f0b5c7cad99d22985affd3d20cc554b9f097487ce2be6dfc76b'
FINAL_FRESH_FIXTURE_SHA = '31759517cd3f033e0c44f53b3938af0faf6db4f75efe53c5df7fd2d67fb88409'
MEASUREMENT_FIXTURE_SHA = 'bcbfbe42b9fabf0d63fdb852343fffa6c2e2800b8e84ec5e9e1423a290c2fcbe'
MEASUREMENT_CONTENT_SHA = '9b586ad8ac9a1e0a79d2cab4ff1f9d2671ed3d0434d8e068eebcb09330171ca9'
READER_PATCH_SHA = '874220977c12a789d77acbd7a86fa4889693a5196c32ef52effac20207dcc32f'
OWNED = HERE/'owned_swift_commands.py'
OWNED_SHA = 'f9de18c0fdc879ff916ba34e9afa0da9d6b91444eebfa1e5a8d6a50d3523ca56'
OWNED_PROOF = Path('/mnt/development/projects/evidence/pinkha-e-engine-retained-root-relocation-20261127/swift-lifecycle-controls1/result.json')
OWNED_PROOF_SHA = '040ffa3fcf93094369e24928732aeba9eb10fdb673db76ab7540a887748aa27d'
OFFLINE = Path('/mnt/development/projects/worktrees/anytype-w1-functional-migration-20261127/Tools/AnyEngineValidation/native_source_preservation/linux_outbound_denial.py')
OFFLINE_SHA = '6eaca8b9602f9c1c7fce4b8a176759ad1a10577c0ee74eddb3264992976e86b1'
SECCOMP = Path('/usr/lib/aarch64-linux-gnu/libseccomp.so.2.5.5')
SECCOMP_SHA = '3d128123b494ca9e88f3c237b0912397145af1754e86ea99f460af6857441f19'
CACHE = Path('/var/lib/pinkha-root-t2-linux-20261126/go-cache')
CACHE_TARGET = Path('/mnt/development/projects/caches/pinkha-w1-t2-go-cache-20261127')
ROOT_FLOOR, DEV_FLOOR = 2*GIB, 512*MIB
ROOT_RESERVE, DEV_RESERVE = 32*MIB, 512*MIB
OWNED_CAP, CACHE_GROWTH_CAP, LOG_CAP = 384*MIB, 128*MIB, 8*MIB
UNIT_PACKAGE = 'github.com/anyproto/any-sync-sdk/internal/files/readguard'
SDK_PACKAGE = 'github.com/anyproto/any-sync-sdk'
UNIT_METHODS = ('TestMetadataValueGuardAdmitsCurrentReaderAndGuest', 'TestMetadataValueGuardRefusesRemovedLookupAndMasksFailedRead', 'TestMetadataValueGuardDiscardsAwaitedResultWithoutHoldingACL', 'TestMetadataValueGuardRejectsSignedABAAndAccountRetirement', 'TestStatusEventGuardRefusesQueuedRemovedOrCancelledEvents', 'TestStatusEventGuardAlreadyAdmittedCallbackMayFinish', 'TestStatusEventGuardQuiescesWithoutWaitingAndPreservesDeclinedClose', 'TestCacheEffectAdmitsCurrentReaderAndGuest', 'TestCacheEffectRefusesRemovedBeforePreparation', 'TestCacheEffectDiscardsChangedPreparation', 'TestCacheEffectPreservesAdmittedOutcome', 'TestCacheEffectInlineNoopRequiresCurrentAuthority', 'TestCacheEffectPreservesUnchangedPreparationError', 'TestReadGuardFreshCachedStreamMeasurement64MiB')
UNIT_SUBCASES = {'TestCacheEffectAdmitsCurrentReaderAndGuest': ('reader', 'guest'), 'TestCacheEffectDiscardsChangedPreparation': ('signed-removal-and-read-error', 'account-retired', 'space-retired', 'cancelled'), 'TestCacheEffectInlineNoopRequiresCurrentAuthority': ('current', 'removed-during-preparation'), 'TestCacheEffectPreservesAdmittedOutcome': ('success', 'original-error-after-effect'), 'TestMetadataValueGuardAdmitsCurrentReaderAndGuest': ('reader', 'guest'), 'TestMetadataValueGuardRefusesRemovedLookupAndMasksFailedRead': ('removed-before-lookup', 'removed-during-failed-read'), 'TestMetadataValueGuardRejectsSignedABAAndAccountRetirement': ('signed-remove-restore', 'account-retired'), 'TestStatusEventGuardRefusesQueuedRemovedOrCancelledEvents': ('signed-removal', 'unsubscribe')}
FRESH_METHODS = ('TestFilesMetadataFreshGetListStatusAndStatsStopAtSignedRemoval', 'TestFilesCacheEffectsFreshReaderAdmissionAndSignedRemoval')
MEASUREMENT_METHOD = 'TestReadGuardFreshCachedStreamMeasurement64MiB'


def physical(path, directory=False):
    assert path.is_absolute() and path.resolve()==path and not path.is_symlink(), 'physical input path required'
    info = path.lstat()
    assert stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    return info


def frozen(path, maximum=4*MIB):
    before = physical(path)
    assert before.st_size<=maximum
    fd = os.open(path, os.O_RDONLY|os.O_NOFOLLOW|os.O_NOATIME)
    with os.fdopen(fd, 'rb') as stream:
        assert os.fstat(stream.fileno())==before
        data = stream.read(maximum+1)
        assert os.fstat(stream.fileno())==before
    assert path.lstat()==before and len(data)==before.st_size
    return data


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write_new(path, data, mode=0o600):
    fd = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())


def inventory(root, check=lambda: None):
    physical(root, True)
    found = {}; stack = [root]
    while stack:
        check()
        directory = stack.pop()
        fd = os.open(directory, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_NOATIME)
        try:
            with os.scandir(fd) as entries: names = sorted(entry.name for entry in entries)
        finally: os.close(fd)
        for name in names:
            check()
            path = directory/name; info = path.lstat()
            assert not stat.S_ISLNK(info.st_mode)
            if stat.S_ISDIR(info.st_mode): stack.append(path)
            else:
                assert stat.S_ISREG(info.st_mode)
                found[path.relative_to(root).as_posix()] = identity(frozen(path))
        assert len(found)<=800 and len(stack)<=800
    return found


def parse_package_log(raw, package, expected_names):
    """Join only this exact test's ordered Go Output fragments before JSON decode."""
    events = []
    measurement_output = []
    for line in raw.splitlines():
        event = json.loads(line)
        assert isinstance(event, dict) and event.get('Package') == package
        if event.get('Action') == 'output' and event.get('Test') == MEASUREMENT_METHOD:
            assert package == UNIT_PACKAGE and isinstance(event['Output'], str)
            measurement_output.append(event['Output'])
        if event.get('Action') in ('run', 'pass', 'fail', 'skip'):
            events.append({key:event[key] for key in ('Action','Package','Test','Elapsed') if key in event})
    wanted = Counter({(package,name):1 for name in expected_names})
    for action in ('run', 'pass'):
        observed = Counter((event['Package'],event['Test']) for event in events if event['Action']==action and 'Test' in event)
        assert observed == wanted, 'only the fixed package methods/subcases may run and pass'
    assert not any(event['Action'] in ('fail','skip') for event in events)
    assert Counter(event['Package'] for event in events if event['Action']=='pass' and 'Test' not in event)==Counter({package:1})
    joined = ''.join(measurement_output)
    assert len(joined.encode()) <= 65536, 'bounded same-test output reconstruction'
    marker = 'READGUARD_CACHED_MEASUREMENT '
    measurements = []
    if package == UNIT_PACKAGE:
        assert joined.endswith('\n') and joined.count(marker)==1, 'one complete original measurement line'
        lines = [line for line in joined.splitlines() if marker in line]
        assert len(lines)==1
        measurements.append(json.loads(lines[0].split(marker,1)[1]))
    else:
        assert not measurement_output, 'fresh package cannot supply a reused measurement'
    return events, measurements, [len(value.encode()) for value in measurement_output]


def main():
    if sys.flags.optimize:
        raise RuntimeError('qualification requires assertions enabled')
    sys.dont_write_bytecode = True
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert os.geteuid()==0 and os.uname().nodename=='torah-social'
    assert args.output.parent==PARENT and re.fullmatch(r'attempt[1-9][0-9]{0,2}', args.output.name) and int(args.output.name[7:])>=5
    os.umask(0o077)
    physical(PARENT, True)
    output = args.output
    output.mkdir(mode=0o700, exist_ok=False)
    receipt = output/'result.json'
    write_new(receipt, b'{}\n')  # Reserved before try/finally; never overwrite an old receipt.
    source = output/'sdk-source'
    began = time.monotonic()
    serial = 0
    admitted = {}
    base_expected = None
    source_expected = None
    prior_expected = None
    cache_before = None
    result = {'protocol': 'pinkha-final-files-authority-completion-v1', 'status': 'RUNNING',
              'baseNativeReceiptSHA256': BASE_RECEIPT_SHA, 'baseFullSourceManifestSHA256': BASE_MANIFEST_SHA,
              'finalCandidateSHA256': CANDIDATE_SHA, 'finalPatchSHA256': PATCH_SHA,
              'sourceOnlyMetadata16Precursor': METADATA_SHA, 'sourceOnlyCache17Precursor': CACHE_EFFECT_SHA,
              'reusedContentOnlyHTTP14SHA256': BASELINE_RECEIPT_SHA,
              'retainedPrivateInputs': 0, 'retainedAccountOpens': 0, 'privateRecordExports': 0,
              'nativeCLIServers': 0, 'originalRoleMutations': 0, 'replayedPriorTestMethods': 0, 'separateMetadata16OrCache17OrPerformance1Executed': False,
              'processes': [], 'events': [], 'newEvents': [], 'reusedEvents': [], 'reusedProcesses': [],
              'errors': [], 'completionErrors': [], 'priorUnitMethodsReexecuted': 0,
              'priorMeasurementReexecuted': False, 'historicalProcessIDsProbed': False,
              'resourcePolicy': {'rootFloorBytes': ROOT_FLOOR, 'developmentFloorBytes': DEV_FLOOR,
                'rootAdmissionReserveBytes': ROOT_RESERVE, 'developmentAdmissionReserveBytes': DEV_RESERVE,
                'ownedOutputCapBytes': OWNED_CAP, 'observedSharedCacheGrowthCapBytes': CACHE_GROWTH_CAP,
                'logCapBytes': LOG_CAP, 'controllerSeconds': 420, 'finalizationSeconds': 60,
                'requiredOuterTimeoutSeconds': 480, 'workers': 2, 'goMemoryLimit': '1GiB',
                'allocationBasis': 'Reuse actual attempt4 source735 and32 unit/measurement events without rerun. Recreate the exact public source copy and run only two new6MiB SDK fixtures plus tiny inline row. Original owned384MiB and observed cache128MiB caps remain unchanged. No cache deletion or relocation.'}}

    def save_json(path, value):
        nonlocal serial
        assert path.is_relative_to(output)
        serial += 1
        stage = path.with_name(path.name+'.next-'+str(serial))
        write_new(stage, (json.dumps(value, sort_keys=True, indent=2)+'\n').encode())
        os.replace(stage, path)
        fd = os.open(path.parent, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        try: os.fsync(fd)
        finally: os.close(fd)

    def save():
        result['seconds'] = time.monotonic()-began
        save_json(receipt, result)

    def save_command(path, value):
        assert path.parent == output/'final-fresh'
        assert path.name in ('started.json', 'result.json')
        save_json(path, value)
        save()

    def pin(path, sha, maximum=4*MIB):
        data = frozen(path, maximum)
        assert identity(data)['sha256']==sha
        admitted[str(path)] = {'identity': identity(data), 'maximum': maximum}
        return data

    def capacity(admission=False, bounded=True):
        values = {'root': shutil.disk_usage('/').free, 'development': shutil.disk_usage('/mnt/development').free}
        for name, floor, reserve in [('root',ROOT_FLOOR,ROOT_RESERVE), ('development',DEV_FLOOR,DEV_RESERVE)]:
            result.setdefault('minimumFreeBytes', {})[name] = min(values[name], result.get('minimumFreeBytes', {}).get(name, values[name]))
            assert values[name]>=floor+(reserve if admission else 0), name+' unchanged capacity gate'
        if bounded:
            assert time.monotonic()-began<420 and not (output/'abort').exists(), 'finite final Files qualifier'
        return values

    def allocated(root, mutable=False):
        used, entries = 0, 0
        started = time.monotonic()
        for directory, dirs, files in os.walk(root, followlinks=False):
            for name in dirs:
                path = Path(directory)/name
                try: info = path.lstat()
                except FileNotFoundError:
                    if mutable: continue
                    raise
                assert stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode)
                used += info.st_blocks*512
            for name in files:
                path = Path(directory)/name
                try: info = path.lstat()
                except FileNotFoundError:
                    if mutable or path.is_relative_to(output/'go-tmp'): continue
                    raise
                assert stat.S_ISREG(info.st_mode)
                used += max(info.st_size, info.st_blocks*512)
                if path.is_relative_to(output) and name=='original.log': assert info.st_size<=LOG_CAP
                entries += 1
            assert entries<=30000 and time.monotonic()-started<8
        return used

    def allocation():
        used = allocated(output)
        assert used<=OWNED_CAP, 'owned source/products/fresh data/log/temp cap'
        result['peakOwnedBytes'] = max(used, result.get('peakOwnedBytes', 0))
        if cache_before is not None:
            growth = max(0, allocated(CACHE_TARGET, True)-cache_before)
            result['peakObservedSharedCacheGrowthBytes'] = max(growth, result.get('peakObservedSharedCacheGrowthBytes',0))
            assert growth<=CACHE_GROWTH_CAP, 'measured shared compiler cache growth cap'

    def observe():
        try:
            capacity()
            allocation()
            return None
        except BaseException as error:
            return type(error).__name__+': '+str(error)

    def interrupted(number, _frame):
        raise RuntimeError('final Files qualifier interrupted by signal '+str(number))

    for number in (signal.SIGTERM, signal.SIGINT): signal.signal(number, interrupted)
    signal.pthread_sigmask(signal.SIG_UNBLOCK, {signal.SIGTERM, signal.SIGINT})
    try:
        own = Path(__file__).absolute()
        assert own.parent == CONTINUATION_SOURCE and own.resolve() == own
        pin(HERE/'qualify_final_files_authority.py', ORIGINAL_QUALIFIER_SHA)
        admitted[str(own)] = {'identity': identity(frozen(own)), 'maximum': 4*MIB}
        result['controller'] = admitted[str(own)]['identity']
        pin(OWNED, OWNED_SHA)
        lifecycle = json.loads(pin(OWNED_PROOF, OWNED_PROOF_SHA))
        assert lifecycle['status']=='PASS_FIVE_ACTUAL_OWNED_PROCESS_LIFECYCLE_CONTROLS'
        assert lifecycle['helperSHA256']==OWNED_SHA and lifecycle['allOwnedGroupsPositivelyAbsent']
        assert len(lifecycle['methods'])==5 and all(row['status']=='PASS' for row in lifecycle['methods'])
        spec = importlib.util.spec_from_file_location('final_files_authority_owned', OWNED)
        owned = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(owned)
        result['reusedOwnershipReceiptSHA256'] = OWNED_PROOF_SHA
        result['initialFreeBytes'] = capacity(True)
        available = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
        assert available>=3*GIB
        result['memAvailableBefore'] = available
        assert CACHE.is_symlink() and CACHE.resolve()==CACHE_TARGET
        physical(CACHE_TARGET, True)
        assert CACHE_TARGET.stat().st_dev==output.stat().st_dev
        cache_before = allocated(CACHE_TARGET, True)
        result['sharedCacheAllocationBefore'] = cache_before
        producer = json.loads(pin(BASE/'result.json', BASE_RECEIPT_SHA))
        assert producer['protocol']=='pinkha-files-readguard-native-qualified-v1'
        assert producer['status']=='PASS_NATIVE_BUILD_AND_FRESH_FILES_OPEN2'
        assert producer['allOwnedGroupsPositivelyAbsent'] and producer['errors']==producer['completionErrors']==[]
        assert producer['sourceManifestSHA256']==BASE_MANIFEST_SHA and producer['sourceFiles']==1607
        assert producer['sdkReadguardPatchSHA256']==READER_PATCH_SHA and producer['sourceUnchanged']
        fresh = json.loads(pin(FRESH_RECEIPT, FRESH_RECEIPT_SHA))
        assert fresh['status']=='PASS_FRESH_SYNTHETIC_ACTUAL_FILES_OPEN2'
        assert fresh['actualMethods']['totalRuns']==fresh['actualMethods']['totalPasses']==2 and fresh['actualMethods']['skips']==0
        assert fresh['sourceUnchanged'] and fresh['allOwnedGroupsPositivelyAbsent'] and fresh['errors']==fresh['completionErrors']==[]
        assert fresh['fixtureSource']['sha256']==FRESH_FIXTURE_SHA and fresh['goToolchain']==producer['goToolchain']
        signed = json.loads(pin(SIGNED_RECEIPT, SIGNED_RECEIPT_SHA, 8*MIB))
        assert signed['status']=='PASS_SYNTHETIC_SIGNED_ACL_LIFETIME21_ONLY_NOT_NATIVE_ACCEPTANCE'
        assert signed['actualMethods']['totalRuns']==signed['actualMethods']['totalPasses']==35 and signed['actualMethods']['skips']==0
        assert signed['allOwnedGroupsPositivelyAbsent'] and signed['errors']==signed['completionErrors']==[]
        baseline = json.loads(pin(BASELINE_RECEIPT, BASELINE_RECEIPT_SHA, 8*MIB))
        assert baseline['status']=='PASS_ORIGINAL_CURRENT_AUTHORITY_HTTP14_ONLY'
        assert baseline['allOwnedGroupsPositivelyAbsent'] and baseline['errors']==baseline['completionErrors']==[]
        result['reusedActualReceipts'] = {'signed35':SIGNED_RECEIPT_SHA, 'freshFilesOpen2':FRESH_RECEIPT_SHA,
                                         'contentOnlyHTTP14':BASELINE_RECEIPT_SHA, 'baseProducer':BASE_RECEIPT_SHA}
        prior = json.loads(pin(PRIOR/'result.json', PRIOR_RECEIPT_SHA))
        assert prior['protocol']=='pinkha-final-files-authority-synthetic-v1' and prior['status']=='FAIL_FINAL_FILES_AUTHORITY34'
        assert prior['controller']=={'bytes':32627,'sha256':ORIGINAL_QUALIFIER_SHA}
        assert prior['errors']==[{'type':'JSONDecodeError','message':'Expecting value: line 1 column 941 (char 940)'}]
        assert prior['completionErrors']==[] and prior['allOwnedGroupsPositivelyAbsent'] is True
        assert prior['sourceUnchanged'] and prior['qualifiedPublicSDKBaseUnchanged'] and prior['usedPublicInputsUnchanged']
        assert prior['sourceManifestSHA256']==PRIOR_SOURCE_SHA and prior['sdkSourceFiles']==735
        assert prior['finalCandidateSHA256']==CANDIDATE_SHA and prior['finalPatchSHA256']==PATCH_SHA
        assert prior['reusedActualReceipts']==result['reusedActualReceipts'] and prior['goToolchain']==producer['goToolchain']
        assert len(prior['processes'])==2 and len({row['pid'] for row in prior['processes']})==2
        assert all(row['exitCode']==0 and row['processGroupAbsent'] is True and not row['forcedCleanup'] and row['cleanupErrors']==[] and row['signals']==[] for row in prior['processes'])
        assert prior['processes'][0]['logSHA256']==PRIOR_METADATA_LOG_SHA and prior['processes'][1]['logSHA256']==PRIOR_UNIT_LOG_SHA
        assert prior['events']==[] and not (PRIOR/'final-fresh').exists(), 'original fresh package never started'
        prior_expected = json.loads(pin(PRIOR/'source-before.json', PRIOR_SOURCE_SHA))
        assert len(prior_expected)==735 and inventory(PRIOR/'sdk-source',capacity)==prior_expected
        result['reusedProcesses']=prior['processes']
        result['reusedAllOwnedGroupsPositivelyAbsent']=True
        result['continuationOf']={'receipt':str(PRIOR/'result.json'),'sha256':PRIOR_RECEIPT_SHA,
            'status':prior['status'],'unitLog':str(PRIOR/'final-units/original.log'),
            'unitLogSHA256':PRIOR_UNIT_LOG_SHA,'originalControllerSHA256':ORIGINAL_QUALIFIER_SHA}
        full = json.loads(pin(BASE/'source-manifest.json', BASE_MANIFEST_SHA))['files']
        prefix = '.runtime-artifacts/sdk-source/'
        base_expected = {name.removeprefix(prefix): value for name,value in full.items() if name.startswith(prefix)}
        assert len(full)==1607 and len(base_expected)==726
        assert base_expected['files_readguard_fresh_linux_test.go']==fresh['fixtureSource']
        assert inventory(BASE_SOURCE)==base_expected
        candidate = json.loads(pin(HERE/'manifest.json', CANDIDATE_SHA))
        pin(HERE/'sdk-final-files-authority.patch', PATCH_SHA)
        assert candidate['baseFullSourceManifestSHA256']==BASE_MANIFEST_SHA and candidate['patch']['sha256']==PATCH_SHA
        assert candidate['previousFreshFixtureSHA256']==FRESH_FIXTURE_SHA and candidate['unchangedReadGuardPatchSHA256']==READER_PATCH_SHA
        assert candidate['newFreshFixtureSHA256']==FINAL_FRESH_FIXTURE_SHA
        assert len(candidate['changes'])==13 and candidate['candidateSDKFileCount']==735 and candidate['candidateSourceFileCount']==1616
        assert candidate['plannedRunPassEvents']==34 and candidate['selectedUnitParents']==list(UNIT_METHODS)
        assert candidate['selectedUnitSubcases']=={parent:list(children) for parent,children in UNIT_SUBCASES.items()}
        assert candidate['selectedFreshSDKParents']==list(FRESH_METHODS)
        metadata_layer=json.loads(pin(HERE/'metadata16-manifest.json',METADATA_SHA))
        cache_layer=json.loads(pin(HERE/'cache17-manifest.json',CACHE_EFFECT_SHA))
        inverse=json.loads(pin(HERE/'FRESH_STARTUP_SOURCE_SUCCESSOR.json',FRESH_INVERSE_SHA))
        formatting=json.loads(pin(HERE/'canonical-formatting.json',FORMAT_SHA))
        assert inverse['exactInverseRestoresPrevious'] is True and inverse['previousSHA256']==FRESH_FIXTURE_SHA
        assert inverse['currentSHA256']==FINAL_FRESH_FIXTURE_SHA and inverse['defaultSetupHooks']==[None,None]
        assert formatting['status']=='SOURCE_FORMATTED_ONLY_NOT_COMPILED_OR_TESTED'
        assert formatting['formatterSHA256']=='3ca5e23c92e957338205edb7c8a19a0c4f211b2cf606e21171925f3001d12825'
        assert len(metadata_layer['changes'])==8 and len(cache_layer['changes'])==6
        composed={name:{key:value[key] for key in ('bytes','sha256')} for name,value in metadata_layer['changes'].items()}
        for name,value in cache_layer['changes'].items():
            layer_before_image=composed.get(name,base_expected.get(name))
            assert (None if layer_before_image is None else layer_before_image['sha256'])==value['beforeSHA256']
            composed[name]={key:value[key] for key in ('bytes','sha256')}
        measurement_name='internal/files/readguard/readguard_cached_stream_measurement_test.go'
        assert measurement_name not in composed and measurement_name not in base_expected
        composed[measurement_name]={'bytes':7667,'sha256':MEASUREMENT_FIXTURE_SHA}
        assert {name:{key:value[key] for key in ('bytes','sha256')} for name,value in candidate['changes'].items()}==composed
        assert candidate['layers'][0]['manifestSHA256']==METADATA_SHA and candidate['layers'][1]['manifestSHA256']==CACHE_EFFECT_SHA
        assert candidate['layers'][2]['fixtureSHA256']==MEASUREMENT_FIXTURE_SHA
        assert candidate['defaultFreshFixtureInverseProofSHA256']==FRESH_INVERSE_SHA and candidate['canonicalFormattingSHA256']==FORMAT_SHA
        result['sourceComposition']={'baseSDKFiles':726,'metadataOnlySDKFiles':731,'cacheEffectSDKFiles':734,
            'finalSDKFiles':735,'finalFullAnySourceFiles':1616,'changedPaths':13,
            'metadata16PrecursorExecuted':False,'cache17PrecursorExecuted':False,
            'standaloneMeasurementPrecursorExecuted':False,'defaultFreshConstructorExactInverse':inverse}
        source.mkdir(mode=0o700)
        for index,(name,wanted) in enumerate(sorted(base_expected.items())):
            if index%64==0: capacity()
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and str(relative)==name and '..' not in relative.parts
            raw = frozen(BASE_SOURCE/name)
            assert identity(raw)==wanted
            target = source/name
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            write_new(target, raw, 0o644)
        expected = dict(base_expected)
        assert inventory(source)==expected
        for name,change in candidate['changes'].items():
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and str(relative)==name and '..' not in relative.parts
            previous = expected.get(name)
            assert (None if previous is None else previous['sha256'])==change['beforeSHA256']
            raw = pin(HERE/'overlay'/name, change['sha256'])
            assert len(raw)==change['bytes']
            target = source/name
            target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            if previous is not None:
                assert identity(frozen(target))==previous
                target.unlink()  # Only the just-created public SDK working copy.
            write_new(target, raw, 0o644)
            expected[name] = identity(raw)
        source_expected = expected
        assert len(expected)==735 and expected==prior_expected and inventory(source)==expected
        write_new(output/'source-before.json', (json.dumps(expected, sort_keys=True, indent=2)+'\n').encode())
        result['sourceManifestSHA256'] = identity(frozen(output/'source-before.json'))['sha256']
        result['sdkSourceFiles'] = len(expected)
        pin(OFFLINE, OFFLINE_SHA, 65536)
        pin(SECCOMP, SECCOMP_SHA)
        result['OSPolicy'] = {'helperSHA256':OFFLINE_SHA,'librarySHA256':SECCOMP_SHA,
                             'installedBeforeSDKInitialization':True,'liveTCPAndUDPRequireEPERM':True}
        temporary = output/'go-tmp'
        temporary.mkdir(mode=0o700)
        fixtures = output/'fixtures'
        fixtures.mkdir(mode=0o700)
        env = {key:value for key,value in os.environ.items() if not key.startswith(('ANY_','PINKHA_','PYTHON'))}
        env.update(GOTOOLCHAIN='local',GOMAXPROCS='2',GOMEMLIMIT='1GiB',GOCACHE=str(CACHE),
                   GOMODCACHE='/root/go/pkg/mod',GOTMPDIR=str(temporary),TMPDIR=str(temporary),
                   CGO_ENABLED='1',GOWORK='off',GOFLAGS='-mod=readonly',GOPROXY='off',GOSUMDB='off',
                   PINKHA_FRESH_FILES_FIXTURE_ROOT=str(fixtures))
        known_go = producer['goToolchain']
        driver = Path(known_go['driver']['path'])
        assert identity(pin(driver,known_go['driver']['sha256'],128*MIB))=={key:known_go['driver'][key] for key in ('bytes','sha256')}
        for row in known_go['tools'].values():
            assert identity(pin(Path(row['path']),row['sha256'],128*MIB))=={key:row[key] for key in ('bytes','sha256')}
        python = Path(sys.executable).resolve(strict=True)
        raw_python = frozen(python,32*MIB)
        admitted[str(python)] = {'identity':identity(raw_python),'maximum':32*MIB}
        result['OSExecPython'] = {'path':str(python),**identity(raw_python)}
        metadata_raw = pin(PRIOR/'toolchain/original.log',PRIOR_METADATA_LOG_SHA,65536)
        assert json.loads(metadata_raw)==known_go['metadata']
        assert prior['OSExecPython']==result['OSExecPython'] and prior['OSPolicy']==result['OSPolicy']
        for key in ('GOTOOLCHAIN','GOMAXPROCS','GOMEMLIMIT','GOCACHE','GOMODCACHE','CGO_ENABLED','GOWORK','GOFLAGS','GOPROXY','GOSUMDB'):
            assert prior['environment'][key]==env[key], 'same admitted toolchain environment'
        result['reusedToolchainMetadata']={'path':str(PRIOR/'toolchain/original.log'),**identity(metadata_raw)}
        result['goToolchain'] = known_go
        result['environment'] = {key:env[key] for key in ('GOTOOLCHAIN','GOMAXPROCS','GOMEMLIMIT','GOCACHE','GOMODCACHE','GOTMPDIR','TMPDIR','CGO_ENABLED','GOWORK','GOFLAGS','GOPROXY','GOSUMDB','PINKHA_FRESH_FILES_FIXTURE_ROOT')}
        exec_prefix = shlex.join([str(python),'-B',str(OFFLINE),'--exec'])

        def run_events(directory, package, methods, expected_names, command_timeout, test_timeout):
            assert inventory(source)==source_expected, 'exact public source before each new selected package'
            argv = [str(driver),'test','-json','-count=1','-p=2','-parallel=1','-timeout='+test_timeout,'-exec',exec_prefix,
                    '-run','^('+'|'.join(sorted(methods))+')$',package]
            failure = None
            try:
                _, command = owned.run(output/directory,argv,source,env,command_timeout,observe,save_command,
                    lambda path:identity(frozen(path,LOG_CAP))['sha256'],result['processes'])
            except BaseException as error:
                failure = error
            path = output/directory/'original.log'
            if not path.is_file():
                if failure is not None: raise failure
                raise AssertionError('missing actual new-method log')
            raw = frozen(path,LOG_CAP)
            result.setdefault('rawLogs',{})[directory] = {'path':str(path),**identity(raw)}
            save()
            if failure is not None: raise failure
            events, measurements, chunks = parse_package_log(raw, package, expected_names)
            assert measurements==[] and chunks==[], 'only the new fresh package executes here'
            result['newEvents'].extend(events)
            result['events'].extend(events)
            save()
            assert command['exitCode']==0 and command['processGroupAbsent'] and not command['forcedCleanup'] and not command['cleanupErrors']

        names = list(UNIT_METHODS)+[parent+'/'+child for parent,children in UNIT_SUBCASES.items() for child in children]
        assert len(UNIT_METHODS)==14 and len(names)==32 and len(FRESH_METHODS)==2
        expected_unit_argv=[str(driver),'test','-json','-count=1','-p=2','-parallel=1','-timeout=45s','-exec',exec_prefix,
            '-run','^('+'|'.join(sorted(UNIT_METHODS))+')$',UNIT_PACKAGE]
        assert prior['processes'][1]['argv']==expected_unit_argv
        assert prior['processes'][0]['argv']==[str(driver),'env','-json','GOVERSION','GOROOT','GOTOOLDIR','GOHOSTOS','GOHOSTARCH','GOOS','GOARCH']
        assert all(row['cwd']==str(PRIOR/'sdk-source') for row in prior['processes'])
        unit_raw=pin(PRIOR/'final-units/original.log',PRIOR_UNIT_LOG_SHA,LOG_CAP)
        reused_events, measurements, chunks=parse_package_log(unit_raw,UNIT_PACKAGE,names)
        assert chunks==[57,1024,69,65], 'exact retained fragmented measurement stream'
        result['reusedEvents']=reused_events
        result['events'].extend(reused_events)
        result['observedCachedMeasurements']=measurements
        result['reusedUnitLog']={'path':str(PRIOR/'final-units/original.log'),**identity(unit_raw),
            'measurementOutputChunkBytes':chunks,'samePackageAndTestReassembled':True}
        result['executionAccounting']={'aggregateRequiredRuns':34,'aggregateRequiredPasses':34,'reusedUnitRuns':32,
            'reusedUnitPasses':32,'newFreshRunsRequired':2,'newFreshPassesRequired':2,
            'historicalClosedGroups':2,'newOwnedGroupsRequired':1,'unitOrMeasurementReruns':0}
        save()
        run_events('final-fresh',SDK_PACKAGE,FRESH_METHODS,FRESH_METHODS,240,'90s')
        assert sorted(path.name for path in fixtures.iterdir())==sorted(FRESH_METHODS)
        assert inventory(source,capacity)==source_expected and inventory(BASE_SOURCE,capacity)==base_expected
        assert len(result['observedCachedMeasurements'])==1
        measured=result['observedCachedMeasurements'][0]
        assert measured['protocol']=='pinkha-fresh-cached-stream-measurement-v1'
        assert measured['order']==['original-unwrapped-memory-reader','current-signed-lifetime-guard']
        assert measured['nativeSDKOrStorageThroughput'] is False and measured['throughputAcceptanceThreshold'] is False
        assert measured['retainedAccountInputs']==0 and len(measured['measurements'])==2
        for position,value in enumerate(measured['measurements']):
            assert value['path']==measured['order'][position]
            assert value['bytes']==64*MIB and value['sha256']==MEASUREMENT_CONTENT_SHA and value['reads']==1024
            assert value['largestInnerRequest']==value['callerBufferBytes']==64*1024
            assert type(value['elapsedNanoseconds']) is int and 0<value['elapsedNanoseconds']<10*10**9
            assert type(value['processTotalAllocatedBytes']) is int and value['processTotalAllocatedBytes']>=0
            assert type(value['processAllocationCount']) is int and value['processAllocationCount']>=0
            assert math.isclose(value['mibPerSecond'],64*10**9/value['elapsedNanoseconds'],rel_tol=1e-12)
        original,current=measured['measurements']
        assert math.isclose(measured['elapsedRatioGuardToOriginal'],current['elapsedNanoseconds']/original['elapsedNanoseconds'],rel_tol=1e-12)
        assert measured['allocationDeltaGuardMinusOriginalBytes']==current['processTotalAllocatedBytes']-original['processTotalAllocatedBytes']
        result['newActualMethods']={'freshSDKParents':2,'totalRuns':2,'totalPasses':2,'skips':0}
        result['eventsRepresentAggregateOnly']=True
        result['actualMethods'] = {'unitParents':14,'unitSubcases':18,'freshSDKParents':2,
                                  'totalRuns':34,'totalPasses':34,'skips':0,'oldMethodsRerun':0}
        result['actualScopes']={'metadataAuthority':{'runs':16,'passes':16},
            'cacheEffectAuthority':{'runs':17,'passes':17,'freshRemovedMemberDenials':9,
                'positiveFullOffloadEviction':False,'positiveInlineOffload':True,'priorQueuedJobsCancelled':False},
            'cachedStreamMeasurement':{'runs':1,'passes':1,'measurement':measured,
                'throughputAcceptanceThreshold':False,'nativeSDKOrStorageThroughput':False}}
        result['actualFreshSDKOSDenialVerified'] = True
        result['status'] = 'PASS_FINAL_FILES_AUTHORITY34_WITH_REUSED_UNIT32_AND_NEW_FRESH2'
    except BaseException as error:
        result['status'] = 'FAIL_FINAL_FILES_AUTHORITY34_COMPLETION'
        result['errors'].append({'type':type(error).__name__,'message':str(error)})
    finally:
        for number in (signal.SIGTERM,signal.SIGINT): signal.signal(number,signal.SIG_IGN)
        result['allOwnedGroupsPositivelyAbsent'] = all(row.get('processGroupAbsent') for row in result['processes'])
        final_deadline = time.monotonic()+60
        def final_guard():
            assert time.monotonic()<final_deadline, 'bounded final Files source verification'
            capacity(bounded=False)
        try:
            for name,wanted in admitted.items():
                final_guard()
                assert identity(frozen(Path(name),wanted['maximum']))==wanted['identity']
            result['usedPublicInputsUnchanged'] = True
            if source_expected is not None:
                assert inventory(source,final_guard)==source_expected
                result['sourceUnchanged'] = True
            if base_expected is not None:
                assert inventory(BASE_SOURCE,final_guard)==base_expected
                result['qualifiedPublicSDKBaseUnchanged'] = True
            if prior_expected is not None:
                assert inventory(PRIOR/'sdk-source',final_guard)==prior_expected
                result['originalAttempt4PublicSourceUnchanged']=True
            if result['status'].startswith('PASS_'):
                assert len(result['processes'])==1 and result['allOwnedGroupsPositivelyAbsent']
                assert all(row['exitCode']==0 and not row['forcedCleanup'] and not row['cleanupErrors'] for row in result['processes'])
            allocation()
            result['freeAfter'] = capacity(bounded=False)
            assert time.monotonic()<final_deadline
        except BaseException as error:
            result['status'] = 'FAIL_FINAL_FILES_AUTHORITY34_COMPLETION'
            result['completionErrors'].append({'type':type(error).__name__,'message':str(error)})
        save()
    print(json.dumps({'status':result['status'],'result':str(receipt),'sha256':identity(frozen(receipt,8*MIB))['sha256']}))
    return 0 if result['status'].startswith('PASS_') else 1


if __name__=='__main__':
    raise SystemExit(main())


